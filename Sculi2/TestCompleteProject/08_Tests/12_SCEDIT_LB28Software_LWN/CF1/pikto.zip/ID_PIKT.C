/****************************************************************************/
/*                                                                          */
/*                          LIEBHERR                                        */
/*                         LCD Monitor                                      */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*              Copyright 1998, Liebherr Werk Nenzing GmbH                  */
/*                         ALL RIGHTS RESERVED                              */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* MODUL:          id_pikt.c                                                */
/*                                                                          */
/*--------------------------------------------------------------------------*/
/*                                                                          */
/* Header entry for monitor initialisation file "mon_pikt.s"                */
/* this corresponds with the version of class "Monitor Piktogramme"         */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/* HISTORY:                                                                 */
/* 01.09.1998  Grebenz T.                                                   */
/*             Initial version                                              */
/* 25.09.1998  Rajek M.                                                     */
/*             changed to workmanager compatible version number             */
/* 20.02.2001  Schapler / Flatscher                                         */
/*             Erweiterung der Piktogramme und �nderung der Versionsnummer  */
/* 23.05.2001  Schapler                                                     */
/*             Erweiterung der Piktogramme und �nderung der Versionsnummer  */
/* 26.02.2002  Schreiber                                                    */
/*             Erweiterung der Piktogramme und �nderung der Versionsnummer  */
/* 23.07.2002  Schapler                                                     */
/*             Erweiterung der Piktogramme und �nderung der Versionsnummer  */
/* 18.08.2002  Flatscher                                                    */
/*             Erweiterung der Piktogramme und �nderung der Versionsnummer  */
/*                                                                          */
/* 19.09.2006  Schapler                                                     */
/*             Erweiterung der Piktogramme und �nderung der Versionsnummer  */
/* 06.11.2006  Flatscher                                                    */
/*             Erweiterung der Piktogramme und �nderung der Versionsnummer  */
/* 06.11.2006  Schapler                                                     */
/*             Erweiterung der Piktogramme und �nderung der Versionsnummer  */
/*                                                                          */
/* 18.05.2010  Schapler                                                     */
/*             Erweiterung der Piktogramme und �nderung der Versionsnummer  */
/*                                                                          */
/****************************************************************************/
#pragma ORDER	

/* definition of version_number (avoid preceeding zeros!):                  */
const unsigned long far version_number = 124;			/* Byte 0..3        */




