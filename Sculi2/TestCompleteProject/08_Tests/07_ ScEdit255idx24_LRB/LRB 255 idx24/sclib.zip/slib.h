/**********************************************************************/
/*      M o d u l e                     SLib                          */
/**********************************************************************/


/**********************************************************************/
/*
Date		Autor	reason/changes
-----------------------------------------------------------------------
12.12.95	snd		Inline-Funktionen SEL_x, MIN2_x und MAX2_x durch defines ersetzt;
12.12.95	snd		String functions LEN, LEFT, RIGHT, MID, CONCAT_S2, CONCAT_S, 
					INSERT, DELETE, REPLACE, FIND deleted
12.12.95	snd		lreal-Funktionen deleted
16.01.96	snd		cast-operators of sel_xxx deleted
24.01.96    fer     Klammerung ABS,SEL,MAX2,MIN2,MUX2,MUL_TIME_USINT 
14.02.96	snd		Blank zwischen xx und  ( entfernt: 
					#define max2_xx (,  sel_xx (, mux_xx (
            		Klammerung DIV_TIME_xx, Klammerung trigon. Fkt. xx_real 
27.09.96	rak		TRUNC_REAL identisch mit TRUNC_REAL_INT eingef�gt
					wurde durch Softing 2.02.07 notwendig
15.12.97	rak		Library Version included
02.09.98	snd		Library updated to Version 2.000
08.12.1999	rak		Library changed to DiabData compatibility
24.05.2001	rak		time functions changed to reentrant versions
					run time error checking for ln, log, sqrt (only if set in standard.h)
27.11.2001	rak		modulo functions added
04.04.2005	rak		implemented EXPT function
*/
/**********************************************************************/

/*!	\file	slib.h
	\brief	IEC1131 standard library header
 
*/

#ifndef SLIB_H
#define SLIB_H

/*--- Library Version String -----------------------------------------------*/
#ifdef RELEASE
 #if RELEASE==1
  #define SLIB_VERSION_STRING	"4.300"
 #else
  #define SLIB_VERSION_STRING	"4.999"
 #endif
#else
 #define SLIB_VERSION_STRING	"4.999"
#endif


/*>>>>> include data types: <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
#include "sc_datatyps.h"

#include "math.h"
#include "standard.h"
#include "msg_stack.h"

/*--- subgroup "slib" ------------------------------------------------------*/
#define ERR_LIB_RTEC_LN							0x61000001		/*!< run time error checker, negative or equal operand on ln \ingroup message_code_slib */
#define ERR_LIB_RTEC_LOG						0x61000002		/*!< run time error checker, negative or equal operand on log \ingroup message_code_slib */
#define ERR_LIB_RTEC_DIV0						0x61000003		/*!< run time error checker, division by zero \ingroup message_code_slib */
#define ERR_LIB_RTEC_SQRT_NEG					0x61000004		/*!< run time error checker, negative operand to square root \ingroup message_code_slib */
#define ERR_LIB_RTEC_MUX_INDEX					0x61000005		/*!< run time error checker, multiplexer index above limit \ingroup message_code_slib */
#define ERR_LIB_RTEC_MOD0						0x61000006		/*!< run time error checker, modulo by zero \ingroup message_code_slib */
#define ERR_LIB_RTEC_ASIN_LOW					0x61000007		/*!< run time error checker, operand below -1 on asin \ingroup message_code_slib */
#define ERR_LIB_RTEC_ASIN_HI					0x61000008		/*!< run time error checker, operand above +1 on asin \ingroup message_code_slib */
#define ERR_LIB_RTEC_ACOS_LOW					0x61000009		/*!< run time error checker, operand below -1 on acos \ingroup message_code_slib */
#define ERR_LIB_RTEC_ACOS_HI					0x6100000A		/*!< run time error checker, operand above +1 on acos \ingroup message_code_slib */

/*
~~ IEC 1131-3 Standard library for SoftControl (SLIB)
~~
~~
~~ Files
~~
~~ The following 26 files are part of SLIB:
~~
~~ SCLIB.H      Include file    Master
~~ SCLIB.C      C file          Master
~~ SCLCONVE.H    Include file    Conversion functions
~~ SCLCONVE.C    C file          Conversion functions
~~ SCLNUMER.H    Include file    Numeric functions
~~ SCLARITH.H    Include file    Arithmetic functions
~~ SCLARITH.C    C file          Arithmetic functions
~~ SCLSHIFT.H    Include file    Bit shift functions
~~ SCLSHIFT.C    C file          Bit shift functions
~~ SCLBOOL.H     Include file    Boolean functions
~~ SCLBOOL.C     C file          Boolean functions
~~ SCLSELEC.H    Include file    Selection functions
~~ SCLSELEC.C    C file          Selection functions
~~ SCLCOMPA.H    Include file    Comparison functions
~~ SCLCOMPA.C    C file          Comparison functions
~~ SCLSTRNG.H    Include file    String functions
~~ SCLSTRNG.C    C file          String functions
~~ SCLTIME.H     Include file    Time and date functions
~~ SCLBISTA.H    Include file    Bistable functions
~~ SCLBISTA.C    C file          Bistable functions
~~ SCLEDGE.H     Include file    Edge detection functions
~~ SCLEDGE.C     C file          Edge detection functions
~~ SCLCOUNT.H    Include file    Counter functions
~~ SCLCOUNT.C    C file          Counter functions
~~ SCLTIMER.H    Include file    Timer functions
~~ SCLTIMER.C    C file          Timer functions
~~
~~ C code files corresponding to the following include files do not
~~ exist since all public functions of these modules are implemented
~~ as inline:
~~
~~ 1) SCLNUMER.H
~~ 2) SCLTIME.H
~~
~~
~~ All SCLIB functions with an arbitrary number of parameters
~~ (called "extensible functions" by IEC 1131-3) are additionally
~~ implemented in a non extensible version with only two arguments
~~ for efficient use by the SoftControl C code generator.
~~ All these functions have an additional digit "2" in their name
~~ (for example "ADD2_UINT").
~~
~~
~~ Sources
~~
~~ For compatibility with the SoftControl C code generator
~~ names of public SCLIB functions are completely written in uppercase
~~ letters (for example "REPLACE").
~~
~~ All include files and C files of SCLIB are compliant
~~ with the ANSI-C language standard with the following exceptions:
~~
~~ 1) use of inline keyword in function definitions
~~    (may be turned off with the "INLINE" constant in SCLIB.H)
~~
~~
~~ Technical documentation
~~
~~ Technical documentation is embedded within the header files.
~~ Lines containing technical documentation are marked with "~~"
~~ for easy and consistent maintenance and automated extraction.
~~ All public prototypes are marked as technical documentation.
~~ A cross reference of public functions and possible runtime errors
~~ is marked as technical documentation.
~~
~~
~~ Nonconformance issues
~~
~~ SCLIB is not comformant with the full IEC 1131-3 standard
~~ in the following aspects:
~~
~~ 1) the IEC 64 bit base types LINT, ULINT and LWORD
~~    are not supported
~~
~~ 2) the string function "CONCAT" is named "CONCAT_S2" for 
~~    two arguments and  "CONCAT_S" for var args. 
~~    and the time function "CONCAT" is named "CONCAT"
~~    for clear distinction.
~~
~~
~~ Fatal error handling
~~
~~ Violations of semantics of the SCLIB interface by a client call
~~ (for example illegal parameter values) are optionally detected.
~~ In case of a detected fatal error a centalized but private fatal
~~ error handler (defined in SCLIB.C) is activated. This handler
~~ terminates the client program with an error code.
~~ Detection of fatal errors is controlled by the constant
~~ FATAL_CHECK in SCLIB.H.
~~
~~
~~ Runtime error handling
~~
~~ Errors during runtime (for example divide by zero) are optionally
~~ detected and passed to a client exception handler if such a handler
~~ is installed at runtime with a client call to the
~~ EXCEPTION_REGISTER function declared in SCLIB.H.
~~ If no client runtime error handler is installed or upon return from
~~ an installed client exception handler the active SCLIB function
~~ delivers a default return value.
~~ Detection of runtime errors is controlled by the constant
~~ RUNTIME_CHECK in SCLIB.H.
*/

/*>>>>> conditional compilation switches <<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
/* #define FATAL_CHECK */
/* #define RUNTIME_CHECK */



/* if you do want inline, define INLINE whith __inline  
 * NOTE: ANSI-c requires "__"inline, but that depends on 
 * the compiler, ccc68k eats only inline whitout __ 
 * but microsoft visual c++, which defines _MSV_VER, needs __ , ok ? 
 * NOTE: if you don't want inlining, you must define 
 * INLINE with static to avoid multiple definitions
 */

#ifdef _lint
#define INLINE static __inline  
#else
#define INLINE static inline  
#endif

/* Error detection constants */
#define FATAL_EXIT_CODE -89


/* system error function for runtime error checking ------------------------*/
void slib_error(errorcode_t errorcode, msg_add_info_t add_errorcode);

void slib_init(void);

/**********************************************************************/
#ifndef SCLCONVE_H
#define SCLCONVE_H


/* IEC 1131-3 Standard library (table 22, No.1) Type conversion functions */   /*~~*/

/*>>>>> Public inline functions <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
#if 0	/* excluded 02.09.98 snd */
#define TO_BOOL(Operand) ((SC_BOOL)( (Operand)?(1):(0) ))
#define BOOL_TO_SINT(Operand) ((SC_SINT)( (Operand)?(1):(0) ))
#define BOOL_TO_INT(Operand) ((SC_INT)( (Operand)?(1):(0) ))
#define BOOL_TO_DINT(Operand) ((SC_DINT)( (Operand)?(1):(0) ))
#define BOOL_TO_USINT(Operand) ((SC_USINT)( (Operand)?(1):(0) ))
#define BOOL_TO_UINT(Operand) ((SC_UINT)( (Operand)?(1):(0) ))
#define BOOL_TO_UDINT(Operand) ((SC_UDINT)( (Operand)?(1):(0) ))
#define BOOL_TO_BYTE(Operand) ((SC_BYTE)( (Operand)?(1):(0) ))
#define BOOL_TO_WORD(Operand) ((SC_WORD)( (Operand)?(1):(0) ))
#define BOOL_TO_DWORD(Operand) ((SC_DWORD)( (Operand)?(1):(0) ))
#define BOOL_TO_REAL(Operand) ((SC_REAL)( (Operand)?(1):(0) ))

#define SINT_TO_BOOL(Operand) ((SC_BOOL)( (Operand)?(1):(0) ))
#define INT_TO_BOOL(Operand) ((SC_BOOL)( (Operand)?(1):(0) ))
#define DINT_TO_BOOL(Operand) ((SC_BOOL)( (Operand)?(1):(0) ))
#define USINT_TO_BOOL(Operand) ((SC_BOOL)( (Operand)?(1):(0) ))
#define UINT_TO_BOOL(Operand) ((SC_BOOL)( (Operand)?(1):(0) ))
#define UDINT_TO_BOOL(Operand) ((SC_BOOL)( (Operand)?(1):(0) ))
#define BYTE_TO_BOOL(Operand) ((SC_BOOL)( (Operand)?(1):(0) ))
#define WORD_TO_BOOL(Operand) ((SC_BOOL)( (Operand)?(1):(0) ))
#define DWORD_TO_BOOL(Operand) ((SC_BOOL)( (Operand)?(1):(0) ))
/*
#define REAL_TO_BOOL(Operand) ((SC_REAL)( (Operand)?(1):(0) )) 12.07.95, snd
*/
#endif


/*--- USINT-conversions ----------------------*/
#define TO_USINT(Operand) ((SC_USINT)(Operand))
#define USINT_TO_UINT(Operand) ((SC_UINT)(Operand))
#define USINT_TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define USINT_TO_SINT(Operand) ((SC_SINT)(Operand))
#define USINT_TO_INT(Operand) ((SC_INT)(Operand))
#define USINT_TO_DINT(Operand) ((SC_DINT)(Operand))
#define USINT_TO_REAL(Operand) ((SC_REAL)(Operand))
#define USINT_TO_BYTE(Operand) ((SC_BYTE)(Operand))
#define USINT_TO_WORD(Operand) ((SC_WORD)(Operand))
#define USINT_TO_DWORD(Operand) ((SC_DWORD)(Operand))
#if 0	/* excluded 02.09.98 snd */
#define USINT_TO_DT(Operand) ((SC_DT)(Operand))
#define USINT_TO_DATE(Operand) ((SC_DATE)(Operand))
#endif
/*
INLINE SC_TOD USINT_TO_TOD (SC_USINT Operand)
{
    return 1000 * (SC_TOD) Operand;
}

INLINE SC_TIME USINT_TO_TIME (SC_USINT Operand)
{
    return 1000 * (SC_TIME) Operand;
}
*/


/*--- UINT-conversions ----------------------*/
#define TO_UINT(Operand) ((SC_UINT)(Operand))
#define UINT_TO_USINT(Operand) ((SC_USINT)(Operand))
#define UINT_TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define UINT_TO_SINT(Operand) ((SC_SINT)(Operand))
#define UINT_TO_INT(Operand) ((SC_INT)(Operand))
#define UINT_TO_DINT(Operand) ((SC_DINT)(Operand))
#define UINT_TO_REAL(Operand) ((SC_REAL)(Operand))
#define UINT_TO_BYTE(Operand) ((SC_BYTE)(Operand))
#define UINT_TO_WORD(Operand) ((SC_WORD)(Operand))
#define UINT_TO_DWORD(Operand) ((SC_DWORD)(Operand))
#if 0	/* excluded 02.09.98 snd */
#define UINT_TO_DT(Operand) ((SC_DT)(Operand))
#define UINT_TO_DATE(Operand) ((SC_DATE)(Operand))
#endif
/*
INLINE SC_TOD UINT_TO_TOD (SC_UINT Operand)
{
    return 1000 * (SC_TOD) Operand;
}


INLINE SC_TIME UINT_TO_TIME (SC_UINT Operand)
{
    return 1000 * (SC_TIME) Operand;
}
*/


/*--- UDINT-conversions ----------------------*/
#define TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define UDINT_TO_USINT(Operand) ((SC_USINT)(Operand))
#define UDINT_TO_UINT(Operand) ((SC_UINT)(Operand))
#define UDINT_TO_SINT(Operand) ((SC_SINT)(Operand))
#define UDINT_TO_INT(Operand) ((SC_INT)(Operand))
#define UDINT_TO_DINT(Operand) ((SC_DINT)(Operand))
#define UDINT_TO_REAL(Operand) ((SC_REAL)(Operand))
#define UDINT_TO_BYTE(Operand) ((SC_BYTE)(Operand))
#define UDINT_TO_WORD(Operand) ((SC_WORD)(Operand))
#define UDINT_TO_DWORD(Operand) ((SC_DWORD)(Operand))
#define UDINT_TO_DT(Operand) ((SC_DT)(Operand))
#define UDINT_TO_DATE(Operand) ((SC_DATE)(Operand))

/*
INLINE SC_TOD UDINT_TO_TOD (SC_UDINT Operand)
{
    return 1000 * (SC_TOD) Operand;
}
*/

#define UDINT_TO_TIME(Operand) ((SC_TIME)(Operand))
#define UDINT_TO_TOD(Operand) ((SC_TOD)(Operand))	/* inserted 02.09.98 snd */


/*--- SINT-conversions ----------------------*/
#define TO_SINT(Operand) ((SC_SINT)(Operand))
#define SINT_TO_USINT(Operand) ((SC_USINT)(Operand))
#define SINT_TO_UINT(Operand) ((SC_UINT)(Operand))
#define SINT_TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define SINT_TO_INT(Operand) ((SC_INT)(Operand))
#define SINT_TO_DINT(Operand) ((SC_DINT)(Operand))
#define SINT_TO_REAL(Operand) ((SC_REAL)(Operand))
#define SINT_TO_BYTE(Operand) ((SC_BYTE)(Operand))
#define SINT_TO_WORD(Operand) ((SC_WORD)(Operand))
#define SINT_TO_DWORD(Operand) ((SC_DWORD)(Operand))
#if 0	/* excluded 02.09.98 snd */
#define SINT_TO_DT(Operand) ((SC_DT)(Operand))
#define SINT_TO_DATE(Operand) ((SC_DATE)(Operand))
#endif
/*
INLINE SC_TOD SINT_TO_TOD (SC_SINT Operand)
{
    return 1000 * (SC_TOD) Operand;
}

INLINE SC_TIME SINT_TO_TIME (SC_SINT Operand)
{
    return 1000 * (SC_TIME) Operand;
}
*/


/*--- INT-conversions ----------------------*/
#define TO_INT(Operand) ((SC_INT)(Operand))
#define INT_TO_USINT(Operand) ((SC_USINT)(Operand))
#define INT_TO_UINT(Operand) ((SC_UINT)(Operand))
#define INT_TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define INT_TO_SINT(Operand) ((SC_SINT)(Operand))
#define INT_TO_DINT(Operand) ((SC_DINT)(Operand))
#define INT_TO_REAL(Operand) ((SC_REAL)(Operand))
#define INT_TO_BYTE(Operand) ((SC_BYTE)(Operand))
#define INT_TO_WORD(Operand) ((SC_WORD)(Operand))
#define INT_TO_DWORD(Operand) ((SC_DWORD)(Operand))
#if 0	/* excluded 02.09.98 snd */
#define INT_TO_DT(Operand) ((SC_DT)(Operand))
#define INT_TO_DATE(Operand) ((SC_DATE)(Operand))
#endif
/*
INLINE SC_TOD INT_TO_TOD (SC_INT Operand)
{
    return 1000 * (SC_TOD) Operand;
}

INLINE SC_TIME INT_TO_TIME (SC_INT Operand)
{
    return 1000 * (SC_TIME) Operand;
}
*/


/*--- DINT-conversions ----------------------*/
#define TO_DINT(Operand) ((SC_DINT)(Operand))
#define DINT_TO_USINT(Operand) ((SC_USINT)(Operand))
#define DINT_TO_UINT(Operand) ((SC_UINT)(Operand))
#define DINT_TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define DINT_TO_SINT(Operand) ((SC_SINT)(Operand))
#define DINT_TO_INT(Operand) ((SC_INT)(Operand))
#define DINT_TO_REAL(Operand) ((SC_REAL)(Operand))
#define DINT_TO_BYTE(Operand) ((SC_BYTE)(Operand))
#define DINT_TO_WORD(Operand) ((SC_WORD)(Operand))
#define DINT_TO_DWORD(Operand) ((SC_DWORD)(Operand))

#if 0	/* excluded 02.09.98 snd */
#define DINT_TO_DT(Operand) ((SC_DT)(Operand))
#define DINT_TO_DATE(Operand) ((SC_DATE)(Operand))
#endif

#if 0	/* excluded 02.09.98 snd */
INLINE SC_TOD DINT_TO_TOD (SC_DINT Operand)
{
    return 1000 * (SC_TOD) Operand;
}
#endif

/* function DINT_TO_TIME changed 02.09.98 snd */
#define DINT_TO_TIME(Operand) ((SC_TIME)(Operand))
#if 0
INLINE SC_TIME DINT_TO_TIME (SC_DINT Operand)
{
    return 1000 * (SC_TIME) Operand;
}
#endif


/*--- REAL-conversions ----------------------*/
INLINE SC_USINT REAL_TO_USINT (SC_REAL Operand)
{

    Operand += (SC_REAL) 0.5;

    return (SC_USINT) Operand;
}


INLINE SC_UINT REAL_TO_UINT (SC_REAL Operand)
{

    Operand += (SC_REAL) 0.5;

    return (SC_UINT) Operand;
}


INLINE SC_UDINT REAL_TO_UDINT (SC_REAL Operand)
{

    Operand += (SC_REAL) 0.5;

    return (SC_UDINT) Operand;
}


INLINE SC_SINT REAL_TO_SINT (SC_REAL Operand)
{
    if (Operand >= 0)
        Operand += (SC_REAL) 0.5;
    else
        Operand -= (SC_REAL) 0.5;

    return (SC_SINT) Operand;
}


INLINE SC_INT REAL_TO_INT (SC_REAL Operand)
{
    if (Operand >= 0)
        Operand += (SC_REAL) 0.5;
    else
        Operand -= (SC_REAL) 0.5;


    return (SC_INT) Operand;
}


INLINE SC_DINT REAL_TO_DINT (SC_REAL Operand)
{
    if (Operand >= 0)
        Operand += (SC_REAL) 0.5;
    else
        Operand -= (SC_REAL) 0.5;


    return (SC_DINT) Operand;
}



INLINE SC_BYTE REAL_TO_BYTE (SC_REAL Operand)
{

    Operand += (SC_REAL) 0.5;

    return (SC_BYTE) Operand;
}


INLINE SC_WORD REAL_TO_WORD (SC_REAL Operand)
{

    Operand += (SC_REAL) 0.5;

    return (SC_WORD) Operand;
}


INLINE SC_DWORD REAL_TO_DWORD (SC_REAL Operand)
{

    Operand += (SC_REAL) 0.5;


    return (SC_DWORD) Operand;
}


#if 0 /* functions excluded 02.09.98 snd */
INLINE SC_DT REAL_TO_DT (SC_REAL Operand)
{

    Operand += (SC_REAL) 0.5;

    return (SC_DT) Operand;
}

INLINE SC_DATE REAL_TO_DATE (SC_REAL Operand)
{

    Operand += (SC_REAL) 0.5;

    return (SC_DATE) Operand;
}


INLINE SC_TOD REAL_TO_TOD (SC_REAL Operand)
{
    if (Operand >= 0)
        Operand += (SC_REAL) 0.0005;
    else
        Operand -= (SC_REAL) 0.0005;

    return (SC_TOD) (Operand * 1000);
}
#endif

INLINE SC_TIME REAL_TO_TIME (SC_REAL Operand)
{
    if (Operand >= 0)
        Operand += (SC_REAL) 0.5;		/* changed 0.00005 to 0.5 02.09.98 snd */
    else
        Operand -= (SC_REAL) 0.5;		/* changed 0.00005 to 0.5 02.09.98 snd */

    return (SC_TIME) (Operand); /* changed (Operand * 1000) to (Operand) 02.09.98 snd */
}
#define TO_REAL(Operand) ((SC_REAL)(Operand))




/*--- BYTE-conversions ----------------------*/
#define TO_BYTE(Operand) ((SC_BYTE)(Operand))
#define BYTE_TO_USINT(Operand) ((SC_USINT)(Operand))
#define BYTE_TO_UINT(Operand) ((SC_UINT)(Operand))
#define BYTE_TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define BYTE_TO_SINT(Operand) ((SC_SINT)(Operand))
#define BYTE_TO_INT(Operand) ((SC_INT)(Operand))
#define BYTE_TO_DINT(Operand) ((SC_DINT)(Operand))
#define BYTE_TO_REAL(Operand) ((SC_REAL)(Operand))
#define BYTE_TO_WORD(Operand) ((SC_WORD)(Operand))
#define BYTE_TO_DWORD(Operand) ((SC_DWORD)(Operand))

#if 0	/* excluded 02.09.98 snd */
#define BYTE_TO_DT(Operand) ((SC_DT)(Operand))
#define BYTE_TO_DATE(Operand) ((SC_DATE)(Operand))
#endif
/*
INLINE SC_TOD BYTE_TO_TOD (SC_BYTE Operand)
{
    return 1000 * (SC_TOD) Operand;
}

INLINE SC_TIME BYTE_TO_TIME (SC_BYTE Operand)
{
    return 1000 * (SC_TIME) Operand;
}
*/

/*--- WORD-conversions ----------------------*/
#define TO_WORD(Operand) ((SC_WORD)(Operand))
#define WORD_TO_USINT(Operand) ((SC_USINT)(Operand))
#define WORD_TO_UINT(Operand) ((SC_UINT)(Operand))
#define WORD_TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define WORD_TO_SINT(Operand) ((SC_SINT)(Operand))
#define WORD_TO_INT(Operand) ((SC_INT)(Operand))
#define WORD_TO_DINT(Operand) ((SC_DINT)(Operand))
#define WORD_TO_REAL(Operand) ((SC_REAL)(Operand))
#define WORD_TO_BYTE(Operand) ((SC_BYTE)(Operand))
#define WORD_TO_DWORD(Operand) ((SC_DWORD)(Operand))
#if 0	/* excluded 02.09.98 snd */
#define WORD_TO_DT(Operand) ((SC_DT)(Operand))
#define WORD_TO_DATE(Operand) ((SC_DATE)(Operand))
#endif
/*
INLINE SC_TOD WORD_TO_TOD (SC_WORD Operand)
{
    return 1000 * (SC_TOD) Operand;
}

INLINE SC_TIME WORD_TO_TIME (SC_WORD Operand)
{
    return 1000 * (SC_TIME) Operand;
}
*/

/*--- DWORD-conversions ----------------------*/
#define TO_DWORD(Operand) ((SC_DWORD)(Operand))
#define DWORD_TO_USINT(Operand) ((SC_USINT)(Operand))
#define DWORD_TO_UINT(Operand) ((SC_UINT)(Operand))
#define DWORD_TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define DWORD_TO_SINT(Operand) ((SC_SINT)(Operand))
#define DWORD_TO_INT(Operand) ((SC_INT)(Operand))
#define DWORD_TO_DINT(Operand) ((SC_DINT)(Operand))
#define DWORD_TO_REAL(Operand) ((SC_REAL)(Operand))
#define DWORD_TO_BYTE(Operand) ((SC_BYTE)(Operand))
#define DWORD_TO_WORD(Operand) ((SC_WORD)(Operand))
#define DWORD_TO_TIME(Operand) ((SC_TIME)(Operand))	/* included 02.09.98 snd */
#define DWORD_TO_DT(Operand) ((SC_DT)(Operand))
#define DWORD_TO_DATE(Operand) ((SC_DATE)(Operand))
#define DWORD_TO_TOD(Operand) ((SC_TOD)(Operand))	/* included 02.09.98 snd */

/*
INLINE SC_TOD DWORD_TO_TOD (SC_DWORD Operand)
{
    return 1000 * (SC_TOD) Operand;
}

INLINE SC_TIME DWORD_TO_TIME (SC_DWORD Operand)
{
    return 1000 * (SC_TIME) Operand;
}
*/


/*--- DT-conversions ----------------------*/
/*
INLINE SC_TOD DT_TO_TOD (SC_DT Operand)
{
    return Operand * 1000;
}
*/
#define DT_TO_DATE(Operand) ((SC_DATE)(Operand))

/* dt_to_xx functions inserted 02.09.98 */
#define DT_TO_DWORD(Operand) ((SC_DWORD)(Operand))
#define DT_TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define DT_TO_TOD(Operand) ((SC_TOD)(Operand))
#define TO_DT(Operand) ((SC_DT)(Operand))




/*--- TIME-conversions ----------------------*/
#define TO_TIME(Operand) ((SC_TIME)(Operand)) 		/* Eingefuegt snd 29.04.96	*/
#define TIME_TO_UDINT(Operand) ((SC_UDINT)(Operand)) 	/* Eingefuegt snd 09.05.95	*/
#define TIME_TO_REAL(Operand) ((SC_REAL)(Operand)) 		/* Eingefuegt snd 21.08.95	*/

/* time_to_xx funtions inserted 02.09.98 snd */
#define TIME_TO_DWORD(Operand) ((SC_DWORD)(Operand)) 		/* Eingefuegt snd 21.08.95	*/
#define TIME_TO_DINT(Operand) ((SC_DINT)(Operand)) 		/* Eingefuegt snd 21.08.95	*/

INLINE SC_DATE TIME_TO_DATE (SC_TIME Operand)
{
    return (SC_DATE)(Operand / 1000);
}

INLINE SC_TOD TIME_TO_TOD (SC_TIME Operand)
{
    return (SC_TOD)(Operand / 1000);
}

INLINE SC_DT TIME_TO_DT (SC_TIME Operand)
{
    return (SC_DT)(Operand / 1000);
}



/*--- TOD-conversions ----------------------*/
/* inserted 02.09.98 snd */
INLINE SC_TIME TOD_TO_TIME (SC_TOD Operand)
{
struct tm tblock;

	localtime_r( &Operand, &tblock );
	return (SC_TIME)(1000*(tblock.tm_hour * 3600 + tblock.tm_min * 60 + tblock.tm_sec));
}

#define TOD_TO_DWORD(Operand) ((SC_DWORD)(Operand))
#define TOD_TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define TOD_TO_DATE(Operand) ((SC_DATE)(Operand)) 
#define TOD_TO_DT(Operand) ((SC_DT)(Operand)) 	
#define TO_TOD(Operand) ((SC_TOD)(Operand)) 	



/*--- DATE-conversions ----------------------*/
/* inserted 02.09.98 snd */
#define DATE_TO_DWORD(Operand) ((SC_DWORD)(Operand))
#define DATE_TO_UDINT(Operand) ((SC_UDINT)(Operand))
#define TO_DATE(Operand) ((SC_DATE)(Operand))
#define DATE_TO_TOD(Operand) ((SC_TOD)(Operand))
#define DATE_TO_DT(Operand) ((SC_DT)(Operand))



/* IEC 1131-3 Standard library (table 22, No.2) Type conversion functions */   /*~~*/
/*--- Truncate functions --------------------*/
#define TRUNC_TO_USINT_REAL(Operand) ((SC_USINT)(Operand)) 
#define TRUNC_TO_UINT_REAL(Operand) ((SC_UINT)(Operand)) 
#define TRUNC_TO_UDINT_REAL(Operand) ((SC_UDINT)(Operand)) 
#define TRUNC_TO_SINT_REAL(Operand) ((SC_SINT)(Operand)) 
#define TRUNC_TO_INT_REAL(Operand) ((SC_INT)(Operand)) 
#define TRUNC_TO_DINT_REAL(Operand) ((SC_DINT)(Operand)) 

#define TRUNC_REAL(Operand) ((SC_INT)(Operand)) 




/* IEC 1131-3 Standard library (table 22, No.3+4) Type conversion functions */   /*~~*/
#if 0 /* functions excluded 02.09.98 snd */
/*>>>>> Public function prototypes <<<<<<<<<<<<<<<<<<<<<<<<<<<~~*/
SC_USINT BYTE_BCD_TO_USINT (SC_BYTE Operand);               /*~~*/
SC_UINT WORD_BCD_TO_UINT   (SC_WORD Operand);               /*~~*/
SC_UDINT DWORD_BCD_TO_UDINT (SC_DWORD Operand);             /*~~*/
                            /*~~*/
SC_BYTE USINT_TO_BCD_BYTE (SC_USINT Operand);               /*~~*/
SC_WORD UINT_TO_BCD_WORD (SC_UINT Operand);                 /*~~*/
SC_DWORD UDINT_TO_BCD_DWORD (SC_UDINT Operand);             /*~~*/
#endif


#endif




/**********************************************************************/
#ifndef SCLNUMER_H
#define SCLNUMER_H

/* IEC 1131-3 Standard library (table 23) functions of one numeric variable */   /*~~*/

/* function ABS_USINT and ABS_UDINT inserted 02.09.98 snd */ 
#define ABS_SINT(Operand) ((Operand >= 0) ? Operand : -Operand)
#define ABS_USINT(Operand) (Operand)
#define ABS_INT(Operand) ((Operand >= 0) ? Operand : -Operand)
#define ABS_UINT(Operand) (Operand)			/* function changed (return unsigned type directly) 02.09.98 snd */
#define ABS_DINT(Operand) ((Operand >= 0) ? Operand : -Operand)
#define ABS_UDINT(Operand) (Operand)
#define ABS_REAL(Operand) ((Operand >= 0) ? Operand : -Operand)


#if SC_RT_ERRCHECK
INLINE SC_REAL SQRT_REAL(SC_REAL Operand)
{
if(Operand<0)
	{
	slib_error(ERR_LIB_RTEC_SQRT_NEG, *(msg_add_info_t*)(&Operand));
	return 0;
	}
else
	return ((SC_REAL) sqrt ((double)Operand));
}

INLINE SC_REAL LN_REAL(SC_REAL Operand)
{
if(Operand<=0)
	{
	slib_error(ERR_LIB_RTEC_LN, *(msg_add_info_t*)(&Operand));
	return 0;
	}
else
	return (SC_REAL) log ((double)Operand);
}

INLINE SC_REAL LOG_REAL(SC_REAL Operand)
{
if(Operand<=0)
	{
	slib_error(ERR_LIB_RTEC_LOG, *(msg_add_info_t*)(&Operand));
	return 0;
	}
else
	return ((SC_REAL) log10 ((double)Operand));
}

INLINE SC_REAL ASIN_REAL(SC_REAL Operand)
{
if(Operand<((SC_REAL)-1.0))
	{
	slib_error(ERR_LIB_RTEC_ASIN_LOW, *(msg_add_info_t*)(&Operand));
	return -90.0;
	}
if(Operand>((SC_REAL)1.0))
	{
	slib_error(ERR_LIB_RTEC_ASIN_HI, *(msg_add_info_t*)(&Operand));
	return 90.0;
	}
return (SC_REAL)asin ((double)Operand);
}

INLINE SC_REAL ACOS_REAL(SC_REAL Operand)
{
if(Operand<((SC_REAL)-1.0))
	{
	slib_error(ERR_LIB_RTEC_ACOS_LOW, *(msg_add_info_t*)(&Operand));
	return 180.0;
	}
if(Operand>((SC_REAL)1.0))
	{
	slib_error(ERR_LIB_RTEC_ACOS_HI, *(msg_add_info_t*)(&Operand));
	return 0.0;
	}
return (SC_REAL)acos ((double)Operand);
}
#else	/* #if SC_RT_ERRCHECK */
/* casting of "Operand" to double inserted 08.09.98 snd */
#define SQRT_REAL(Operand)  ((SC_REAL) sqrt ((double)Operand))

#define LN_REAL(Operand)    ((SC_REAL) log ((double)Operand))
#define LOG_REAL(Operand)   ((SC_REAL) log10 ((double)Operand))
#define ASIN_REAL(Operand)   ((SC_REAL) asin ((double)Operand))
#define ACOS_REAL(Operand)   ((SC_REAL) acos ((double)Operand))
#endif	/* #if SC_RT_ERRCHECK */

#define EXP_REAL(Operand)   ((SC_REAL) exp ((double)Operand))
#define EXPT_REAL_REAL(Operand1, Operand2)   ((SC_REAL) pow ((double)Operand1, (double)Operand2))
#define EXPT_LREAL_REAL(Operand1, Operand2)   ((SC_REAL) pow ((double)Operand1, (double)Operand2))
#define EXPT_REAL_LREAL(Operand1, Operand2)   ((SC_REAL) pow ((double)Operand1, (double)Operand2))
#define EXPT_LREAL_LREAL(Operand1, Operand2)   ((SC_REAL) pow ((double)Operand1, (double)Operand2))
#define SIN_REAL(Operand)   ((SC_REAL) sin ((double)Operand))
#define COS_REAL(Operand)   ((SC_REAL) cos ((double)Operand))
#define TAN_REAL(Operand)   ((SC_REAL) tan ((double)Operand))
#define ATAN_REAL(Operand)   ((SC_REAL) atan ((double)Operand))
#define ATAN2_REAL(Operand1, Operand2)   ((SC_REAL) atan2 ((double)Operand1, (double)Operand2))

#endif



/**********************************************************************/
#ifndef SCLARITH_H
#define SCLARITH_H

/* IEC 1131-3 Standard library (table 24) standard arithmetic functions */   /*~~*/

/* casting of "Operand" to double inserted 08.09.98 snd */

/* function inserted 08.09.98 snd */
#define EXP_REAL_USINT(Operand1,Operand2)   ((SC_REAL) pow ((double)Operand1, (double)Operand2))

#define EXP_REAL_UINT(Operand1,Operand2)   ((SC_REAL) pow ((double)Operand1, (double)Operand2))
#define EXP_REAL_UDINT(Operand1,Operand2)   ((SC_REAL) pow ((double)Operand1, (double)Operand2))
#define EXP_REAL_SINT(Operand1,Operand2)   ((SC_REAL) pow ((double)Operand1, (double)Operand2))
#define EXP_REAL_INT(Operand1,Operand2)   ((SC_REAL) pow ((double)Operand1, (double)Operand2))
#define EXP_REAL_DINT(Operand1,Operand2)   ((SC_REAL) pow ((double)Operand1, (double)Operand2))
#define EXP_REAL_REAL(Operand1,Operand2)   ((SC_REAL) pow ((double)Operand1, (double)Operand2))


/* modulo-functions */ 
/* inserted 27.11.2001 Rajek M. */
INLINE SC_USINT MOD_USINT(SC_USINT Operand1, SC_USINT Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_B);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_UINT MOD_UINT(SC_UINT Operand1, SC_UINT Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_W);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_UDINT MOD_UDINT(SC_UDINT Operand1, SC_UDINT Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_D);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_SINT MOD_SINT(SC_SINT Operand1, SC_SINT Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_S);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_INT MOD_INT(SC_INT Operand1, SC_INT Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_I);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_DINT MOD_DINT(SC_DINT Operand1, SC_DINT Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_T);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_BYTE MOD_BYTE(SC_BYTE Operand1, SC_BYTE Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_B);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_WORD MOD_WORD(SC_WORD Operand1, SC_WORD Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_W);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_DWORD MOD_DWORD(SC_DWORD Operand1, SC_DWORD Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_D);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_REAL MOD_REAL(SC_REAL Operand1, SC_REAL Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_R);
		return 0;
		}
	return fmod(Operand1, Operand2);
}

INLINE SC_TIME MOD_TIME(SC_TIME Operand1, SC_TIME Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_D);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_DT MOD_DT(SC_DT Operand1, SC_DT Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_DT);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_TOD MOD_TOD(SC_TOD Operand1, SC_TOD Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_TOD);
		return 0;
		}
	return Operand1 % Operand2;
}

INLINE SC_DATE MOD_DATE(SC_DATE Operand1, SC_DATE Operand2)
{
	if(Operand2==0)
		{
		slib_error(ERR_LIB_RTEC_MOD0 , (msg_add_info_t)IEC_SIZE_DATE);
		return 0;
		}
	return Operand1 % Operand2;
}

#endif


/**********************************************************************/
#ifndef SCLSHIFT_H
#define SCLSHIFT_H

/* IEC 1131-3 Standard library (table 25) standard bit-shift functions */   /*~~*/

/*>>>>> Public function prototypes <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<~~*/
  							  /*~~*/
SC_BYTE ROR_BYTE (SC_BYTE Operand, SC_USINT RotateCount);   /*~~*/
SC_WORD ROR_WORD (SC_WORD Operand, SC_USINT RotateCount);   /*~~*/
SC_DWORD ROR_DWORD (SC_DWORD Operand, SC_USINT RotateCount);/*~~*/
							  /*~~*/
SC_BYTE ROL_BYTE (SC_BYTE Operand, SC_USINT RotateCount);   /*~~*/
SC_WORD ROL_WORD (SC_WORD Operand, SC_USINT RotateCount);   /*~~*/
SC_DWORD ROL_DWORD (SC_DWORD Operand, SC_USINT RotateCount);/*~~*/



/*>>>>>	Public inline functions <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

INLINE SC_BYTE SHL_BYTE (SC_BYTE Operand, SC_USINT ShiftCount)
{
    return Operand << ShiftCount;
}


INLINE SC_WORD SHL_WORD (SC_WORD Operand, SC_USINT ShiftCount)
{
    return Operand << ShiftCount;
}


INLINE SC_DWORD SHL_DWORD (SC_DWORD Operand, SC_USINT ShiftCount)
{
    return Operand << ShiftCount;
}


INLINE SC_BYTE SHR_BYTE (SC_BYTE Operand, SC_USINT ShiftCount)
{
    return Operand >> ShiftCount;
}


INLINE SC_WORD SHR_WORD (SC_WORD Operand, SC_USINT ShiftCount)
{
    return Operand >> ShiftCount;
}


INLINE SC_DWORD SHR_DWORD (SC_DWORD Operand, SC_USINT ShiftCount)
{
    return Operand >> ShiftCount;
}


#endif



/**********************************************************************/
#ifndef SCLBOOL_H
#define SCLBOOL_H

/* IEC 1131-3 Standard library (table 26) standard Boolean functions */   /*~~*/

#define NOT_BOOL(Operand) ((SC_BOOL)(1&~Operand))
#define NOT_BYTE(Operand) ((SC_BYTE)(~Operand))
#define NOT_WORD(Operand) ((SC_WORD)(~Operand))
#define NOT_DWORD(Operand) ((SC_DWORD)(~Operand))


#endif




/**********************************************************************/
#ifndef SCLSELEC_H
#define SCLSELEC_H

/* IEC 1131-3 Standard library (table 27) standard Selection functions */   /*~~*/

/*>>>>> Public function prototypes <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<~~*/
								  /*~~*/
								  /*~~*/
SC_USINT MAX_USINT (SC_USINT OperandCount,                  /*~~*/
    SC_USINT Operand1, SC_USINT Operand2, ...);                   /*~~*/
SC_UINT MAX_UINT (SC_USINT OperandCount,                    /*~~*/
    SC_UINT Operand1, SC_UINT Operand2, ...);                     /*~~*/
SC_UDINT MAX_UDINT (SC_USINT OperandCount,                  /*~~*/
    SC_UDINT Operand1, SC_UDINT Operand2, ...);                   /*~~*/
SC_SINT MAX_SINT (SC_USINT OperandCount,                    /*~~*/
    SC_SINT Operand1, SC_SINT Operand2, ...);                     /*~~*/
SC_INT MAX_INT (SC_USINT OperandCount,                      /*~~*/
    SC_INT Operand1, SC_INT Operand2, ...);                       /*~~*/
SC_DINT MAX_DINT (SC_USINT OperandCount,                    /*~~*/
    SC_DINT Operand1, SC_DINT Operand2, ...);                     /*~~*/
SC_BYTE MAX_BYTE (SC_USINT OperandCount,                    /*~~*/
    SC_BYTE Operand1, SC_BYTE Operand2, ...);                     /*~~*/
SC_WORD MAX_WORD (SC_USINT OperandCount,                    /*~~*/
    SC_WORD Operand1, SC_WORD Operand2, ...);                     /*~~*/
SC_DWORD MAX_DWORD (SC_USINT OperandCount,                  /*~~*/
    SC_DWORD Operand1, SC_DWORD Operand2, ...);                   /*~~*/
SC_REAL MAX_REAL (SC_USINT OperandCount,                    /*~~*/
    SC_REAL Operand1, SC_REAL Operand2, ...);                     /*~~*/
SC_DT MAX_DT (SC_USINT OperandCount,                      /*~~*/
    SC_DT Operand1, SC_DT Operand2, ...);                       /*~~*/
SC_DATE MAX_DATE (SC_USINT OperandCount,                    /*~~*/
    SC_DATE Operand1, SC_DATE Operand2, ...);                     /*~~*/
SC_TIME MAX_TIME (SC_USINT OperandCount,                    /*~~*/
    SC_TIME Operand1, SC_TIME Operand2, ...);                     /*~~*/
SC_TOD MAX_TOD (SC_USINT OperandCount,                      /*~~*/
    SC_TOD Operand1, SC_TOD Operand2, ...);                       /*~~*/
								  /*~~*/
SC_USINT MIN_USINT (SC_USINT OperandCount,                  /*~~*/
    SC_USINT Operand1, SC_USINT Operand2, ...);                   /*~~*/
SC_UINT MIN_UINT (SC_USINT OperandCount,                    /*~~*/
    SC_UINT Operand1, SC_UINT Operand2, ...);                     /*~~*/
SC_UDINT MIN_UDINT (SC_USINT OperandCount,                  /*~~*/
    SC_UDINT Operand1, SC_UDINT Operand2, ...);                   /*~~*/
SC_SINT MIN_SINT (SC_USINT OperandCount,                    /*~~*/
    SC_SINT Operand1, SC_SINT Operand2, ...);                     /*~~*/
SC_INT MIN_INT (SC_USINT OperandCount,                      /*~~*/
    SC_INT Operand1, SC_INT Operand2, ...);                       /*~~*/
SC_DINT MIN_DINT (SC_USINT OperandCount,                    /*~~*/
    SC_DINT Operand1, SC_DINT Operand2, ...);                     /*~~*/
SC_BYTE MIN_BYTE (SC_USINT OperandCount,                    /*~~*/
    SC_BYTE Operand1, SC_BYTE Operand2, ...);                     /*~~*/
SC_WORD MIN_WORD (SC_USINT OperandCount,                    /*~~*/
    SC_WORD Operand1, SC_WORD Operand2, ...);                     /*~~*/
SC_DWORD MIN_DWORD (SC_USINT OperandCount,                  /*~~*/
    SC_DWORD Operand1, SC_DWORD Operand2, ...);                   /*~~*/
SC_REAL MIN_REAL (SC_USINT OperandCount,                    /*~~*/
    SC_REAL Operand1, SC_REAL Operand2, ...);                     /*~~*/
SC_DT MIN_DT (SC_USINT OperandCount,                      /*~~*/
    SC_DT Operand1, SC_DT Operand2, ...);                       /*~~*/
SC_DATE MIN_DATE (SC_USINT OperandCount,                    /*~~*/
    SC_DATE Operand1, SC_DATE Operand2, ...);                     /*~~*/
SC_TIME MIN_TIME (SC_USINT OperandCount,                    /*~~*/
    SC_TIME Operand1, SC_TIME Operand2, ...);                     /*~~*/
SC_TOD MIN_TOD (SC_USINT OperandCount,                      /*~~*/
    SC_TOD Operand1, SC_TOD Operand2, ...);                       /*~~*/
								  /*~~*/
								  /*~~*/

#if(0)	/* not working because of compiler problems (see Lint Warning 579) */
SC_SINT MUX_SINT (SC_UINT Selector, SC_USINT OperandCount, /*~~*/
    SC_SINT Operand0, SC_SINT Operand1, ...);                     /*~~*/
SC_USINT MUX_USINT                                          /*~~*/
    (SC_UINT Selector, SC_USINT OperandCount,                    /*~~*/
    SC_USINT Operand0, SC_USINT Operand1, ...);                   /*~~*/
SC_INT MUX_INT (SC_UINT Selector, SC_USINT OperandCount,   /*~~*/
    SC_INT Operand0, SC_INT Operand1, ...);                       /*~~*/
SC_UINT MUX_UINT (SC_UINT Selector, SC_USINT OperandCount, /*~~*/
    SC_UINT Operand0, SC_UINT Operand1, ...);                     /*~~*/
SC_REAL MUX_REAL (SC_UINT Selector, SC_USINT OperandCount, /*~~*/
    SC_REAL Operand0, SC_REAL Operand1, ...);                     /*~~*/
SC_BYTE MUX_BYTE (SC_UINT Selector, SC_USINT OperandCount, /*~~*/
    SC_BYTE Operand0, SC_BYTE Operand1, ...);                     /*~~*/
SC_WORD MUX_WORD (SC_UINT Selector, SC_USINT OperandCount, /*~~*/
    SC_WORD Operand0, SC_WORD Operand1, ...);                     /*~~*/
#endif

SC_UDINT MUX_UDINT                                          /*~~*/
    (SC_UINT Selector, SC_USINT OperandCount,                    /*~~*/
    SC_UDINT Operand0, SC_UDINT Operand1, ...);                   /*~~*/
SC_DINT MUX_DINT (SC_UINT Selector, SC_USINT OperandCount, /*~~*/
    SC_DINT Operand0, SC_DINT Operand1, ...);                     /*~~*/
SC_DWORD MUX_DWORD                                          /*~~*/
    (SC_UINT Selector, SC_USINT OperandCount,                    /*~~*/
    SC_DWORD Operand0, SC_DWORD Operand1, ...);                   /*~~*/
SC_DT MUX_DT (SC_UINT Selector, SC_USINT OperandCount,   /*~~*/
    SC_DT Operand0, SC_DT Operand1, ...);                       /*~~*/
SC_DATE MUX_DATE (SC_UINT Selector, SC_USINT OperandCount, /*~~*/
    SC_DATE Operand0, SC_DATE Operand1, ...);                     /*~~*/
SC_TIME MUX_TIME (SC_UINT Selector, SC_USINT OperandCount, /*~~*/
    SC_TIME Operand0, SC_TIME Operand1, ...);                     /*~~*/
SC_TOD MUX_TOD (SC_UINT Selector, SC_USINT OperandCount,   /*~~*/
    SC_TOD Operand0, SC_TOD Operand1, ...);                       /*~~*/
SC_STRING* MUX_STRING (SC_STRING* DestinationStringPointer, SC_UINT Selector, SC_USINT OperandCount,   /*~~*/
    SC_STRING* Operand0, SC_STRING* Operand1, ...);                       /*~~*/


/*>>>>> Public inline functions <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
INLINE SC_USINT SEL_USINT(SC_BOOL Selector, SC_USINT Operand0, SC_USINT Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_UINT SEL_UINT(SC_BOOL Selector, SC_UINT Operand0, SC_UINT Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_UDINT SEL_UDINT(SC_BOOL Selector, SC_UDINT Operand0, SC_UDINT Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_SINT SEL_SINT(SC_BOOL Selector, SC_SINT Operand0, SC_SINT Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_INT SEL_INT(SC_BOOL Selector, SC_INT Operand0, SC_INT Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_DINT SEL_DINT(SC_BOOL Selector, SC_DINT Operand0, SC_DINT Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_BOOL SEL_BOOL(SC_BOOL Selector, SC_BOOL Operand0, SC_BOOL Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_BYTE SEL_BYTE(SC_BOOL Selector, SC_BYTE Operand0, SC_BYTE Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_WORD SEL_WORD(SC_BOOL Selector, SC_WORD Operand0, SC_WORD Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_DWORD SEL_DWORD(SC_BOOL Selector, SC_DWORD Operand0, SC_DWORD Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_REAL SEL_REAL(SC_BOOL Selector, SC_REAL Operand0, SC_REAL Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_DT SEL_DT(SC_BOOL Selector, SC_DT Operand0, SC_DT Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_DATE SEL_DATE(SC_BOOL Selector, SC_DATE Operand0, SC_DATE Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_TIME SEL_TIME(SC_BOOL Selector, SC_TIME Operand0, SC_TIME Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

INLINE SC_TOD SEL_TOD(SC_BOOL Selector, SC_TOD Operand0, SC_TOD Operand1)
{
if(Selector)
	return Operand1;
else
	return Operand0;
}

SC_STRING* SEL_STRING(SC_STRING* DestinationStringPointer, SC_BOOL Selector, const SC_STRING* Operand0, const SC_STRING* Operand1);


#define MAX2_USINT(Operand1, Operand2) ((Operand1 > Operand2)?((SC_USINT)Operand1):((SC_USINT)Operand2))
#define MAX2_UINT(Operand1, Operand2) ((Operand1 > Operand2)?((SC_UINT)Operand1):((SC_UINT)Operand2))
#define MAX2_UDINT(Operand1, Operand2) ((Operand1 > Operand2)?((SC_UDINT)Operand1):((SC_UDINT)Operand2))
#define MAX2_SINT(Operand1, Operand2) ((Operand1 > Operand2)?((SC_SINT)Operand1):((SC_SINT)Operand2))
#define MAX2_INT(Operand1, Operand2) ((Operand1 > Operand2)?((SC_INT)Operand1):((SC_INT)Operand2))
#define MAX2_DINT(Operand1, Operand2) ((Operand1 > Operand2)?((SC_DINT)Operand1):((SC_DINT)Operand2))
#if 0
#define MAX2_BOOL (SC_BOOL Operand1, SC_BOOL Operand2)
		(Operand1 > Operand2)?((SC_BOOL)Operand1):((SC_BOOL)Operand2)
#endif
#define MAX2_BYTE(Operand1, Operand2) ((Operand1 > Operand2)?((SC_BYTE)Operand1):((SC_BYTE)Operand2))
#define MAX2_WORD(Operand1, Operand2) ((Operand1 > Operand2)?((SC_WORD)Operand1):((SC_WORD)Operand2))
#define MAX2_DWORD(Operand1, Operand2) ((Operand1 > Operand2)?((SC_DWORD)Operand1):((SC_DWORD)Operand2))
#define MAX2_REAL(Operand1, Operand2) ((Operand1 > Operand2)?((SC_REAL)Operand1):((SC_REAL)Operand2))
#define MAX2_DT(Operand1, Operand2) ((Operand1 > Operand2)?((SC_DT)Operand1):((SC_DT)Operand2))
#define MAX2_DATE(Operand1, Operand2) ((Operand1 > Operand2)?((SC_DATE)Operand1):((SC_DATE)Operand2))
#define MAX2_TIME(Operand1, Operand2) ((Operand1 > Operand2)?((SC_TIME)Operand1):((SC_TIME)Operand2))
#define MAX2_TOD(Operand1, Operand2) ((Operand1 > Operand2)?((SC_TOD)Operand1):((SC_TOD)Operand2))




#define MIN2_USINT(Operand1, Operand2) ((Operand1 < Operand2)?((SC_USINT)Operand1):((SC_USINT)Operand2))
#define MIN2_UINT(Operand1, Operand2) ((Operand1 < Operand2)?((SC_UINT)Operand1):((SC_UINT)Operand2))
#define MIN2_UDINT(Operand1, Operand2) ((Operand1 < Operand2)?((SC_UDINT)Operand1):((SC_UDINT)Operand2))
#define MIN2_SINT(Operand1, Operand2) ((Operand1 < Operand2)?((SC_SINT)Operand1):((SC_SINT)Operand2))
#define MIN2_INT(Operand1, Operand2) ((Operand1 < Operand2)?((SC_INT)Operand1):((SC_INT)Operand2))
#define MIN2_DINT(Operand1, Operand2) ((Operand1 < Operand2)?((SC_DINT)Operand1):((SC_DINT)Operand2))
#if 0
#define MIN2_BOOL (SC_BOOL Operand1, SC_BOOL Operand2)
		(Operand1 < Operand2)?((SC_BOOL)Operand1):((SC_BOOL)Operand2)
#endif
#define MIN2_BYTE(Operand1, Operand2) ((Operand1 < Operand2)?((SC_BYTE)Operand1):((SC_BYTE)Operand2))
#define MIN2_WORD(Operand1, Operand2) ((Operand1 < Operand2)?((SC_WORD)Operand1):((SC_WORD)Operand2))
#define MIN2_DWORD(Operand1, Operand2) ((Operand1 < Operand2)?((SC_DWORD)Operand1):((SC_DWORD)Operand2))
#define MIN2_REAL(Operand1, Operand2) ((Operand1 < Operand2)?((SC_REAL)Operand1):((SC_REAL)Operand2))
#define MIN2_DT(Operand1, Operand2) ((Operand1 < Operand2)?((SC_DT)Operand1):((SC_DT)Operand2))
#define MIN2_DATE(Operand1, Operand2) ((Operand1 < Operand2)?((SC_DATE)Operand1):((SC_DATE)Operand2))
#define MIN2_TIME(Operand1, Operand2) ((Operand1 < Operand2)?((SC_TIME)Operand1):((SC_TIME)Operand2))
#define MIN2_TOD(Operand1, Operand2) ((Operand1 < Operand2)?((SC_TOD)Operand1):((SC_TOD)Operand2))



INLINE SC_USINT LIMIT_USINT
    (SC_USINT Minimum, SC_USINT Operand, SC_USINT Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_UINT LIMIT_UINT
    (SC_UINT Minimum, SC_UINT Operand, SC_UINT Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_UDINT LIMIT_UDINT
    (SC_UDINT Minimum, SC_UDINT Operand, SC_UDINT Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_SINT LIMIT_SINT
    (SC_SINT Minimum, SC_SINT Operand, SC_SINT Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_INT LIMIT_INT
    (SC_INT Minimum, SC_INT Operand, SC_INT Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_DINT LIMIT_DINT
    (SC_DINT Minimum, SC_DINT Operand, SC_DINT Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_BYTE LIMIT_BYTE
    (SC_BYTE Minimum, SC_BYTE Operand, SC_BYTE Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_WORD LIMIT_WORD
    (SC_WORD Minimum, SC_WORD Operand, SC_WORD Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_DWORD LIMIT_DWORD
    (SC_DWORD Minimum, SC_DWORD Operand, SC_DWORD Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_REAL LIMIT_REAL
    (SC_REAL Minimum, SC_REAL Operand, SC_REAL Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}



INLINE SC_DT LIMIT_DT
    (SC_DT Minimum, SC_DT Operand, SC_DT Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_DATE LIMIT_DATE
    (SC_DATE Minimum, SC_DATE Operand, SC_DATE Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_TIME LIMIT_TIME
    (SC_TIME Minimum, SC_TIME Operand, SC_TIME Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_TOD LIMIT_TOD
    (SC_TOD Minimum, SC_TOD Operand, SC_TOD Maximum)
{

	if (Operand < Minimum)
		return Minimum;
	else
		{
		if (Operand > Maximum)
			return Maximum;
		else
			return Operand;
		}
}


INLINE SC_USINT MUX2_USINT(SC_UINT Selector, SC_USINT Operand0, SC_USINT Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_UINT MUX2_UINT(SC_UINT Selector, SC_UINT Operand0, SC_UINT Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_UDINT MUX2_UDINT(SC_UINT Selector, SC_UDINT Operand0, SC_UDINT Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_SINT MUX2_SINT(SC_UINT Selector, SC_SINT Operand0, SC_SINT Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_INT MUX2_INT(SC_UINT Selector, SC_INT Operand0, SC_INT Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_DINT MUX2_DINT(SC_UINT Selector, SC_DINT Operand0, SC_DINT Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

#if 0
#define MUX2_BOOL (SC_USINT Selector, SC_BOOL Operand0, SC_BOOL Operand1)
		(Selector == 0)?((SC_BOOL)Operand0):((SC_BOOL)Operand1)
#endif

INLINE SC_BYTE MUX2_BYTE(SC_UINT Selector, SC_BYTE Operand0, SC_BYTE Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_WORD MUX2_WORD(SC_UINT Selector, SC_WORD Operand0, SC_WORD Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_DWORD MUX2_DWORD(SC_UINT Selector, SC_DWORD Operand0, SC_DWORD Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_REAL MUX2_REAL(SC_UINT Selector, SC_REAL Operand0, SC_REAL Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_DT MUX2_DT(SC_UINT Selector, SC_DT Operand0, SC_DT Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_DATE MUX2_DATE(SC_UINT Selector, SC_DATE Operand0, SC_DATE Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_TIME MUX2_TIME(SC_UINT Selector, SC_TIME Operand0, SC_TIME Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

INLINE SC_TOD MUX2_TOD(SC_UINT Selector, SC_TOD Operand0, SC_TOD Operand1)
{
if(Selector==0)
	return Operand0;
else
	return Operand1;
}

SC_STRING* MUX2_STRING(SC_STRING* DestinationStringPointer, SC_UINT Selector, SC_STRING* Operand0, SC_STRING* Operand1);

#endif



/**********************************************************************/
#ifndef SCLCOMPA_H
#define SCLCOMPA_H

/* IEC 1131-3 Standard library (table 28) comparison functions */            /*~~*/
/* string comparison functions deleted 12.12.95 snd */

#endif



/**********************************************************************/
#ifndef SCLSTRNG_H
#define SCLSTRNG_H

/* IEC 1131-3 Standard library (table 29) character string functions */   /*~~*/

/*>>>>> Public function prototypes <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<~~*/
/*
SC_INT LEN                      
SC_STRING * LEFT                
SC_STRING * RIGHT               
SC_STRING * MID
SC_STRING * CONCAT_S2
SC_STRING * CONCAT_S
SC_STRING * INSERT
SC_STRING * DELETE
SC_STRING * REPLACE
SC_STRING_INDEX FIND
*/

SC_STRING* MOVE_STRING(SC_STRING* d, const SC_STRING* s); /* wird vom System verwendet (Initialisierung) 	 */
void INIT_STRING(SC_STRING* d, SC_STRING_INDEX size, SC_STRING_INDEX l, char* s);

#endif





/**********************************************************************/
#ifndef SCLTIME_H
#define SCLTIME_H

/* IEC 1131-3 Standard library (table 30) functions of time data types */   /*~~*/

/*>>>>> Public inline functions <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/

/* function inserted 08.09.98 snd */
#define ADD_TIME(Operand1, Operand2) (Operand1 + Operand2)

#define SUB_TIME(Operand1, Operand2) (Operand1 - Operand2)


#if 0	/* functions excluded 14.09.98 snd */
INLINE SC_TOD ADD_TOD_TIME (SC_TOD Operand1, SC_TIME Operand2)
INLINE SC_DT ADD_DT_TIME (SC_DT Operand1, SC_TIME Operand2)
INLINE SC_TIME SUB_TIME_TIME (SC_TIME Operand1, SC_TIME Operand2)
INLINE SC_TIME SUB_DATE_DATE (SC_DATE Operand1, SC_DATE Operand2)
INLINE SC_TOD SUB_TOD_TIME (SC_TOD Operand1, SC_TIME Operand2)
INLINE SC_TIME SUB_TOD_TOD (SC_TOD Operand1, SC_TOD Operand2)
INLINE SC_DT SUB_DT_TIME (SC_DT Operand1, SC_TIME Operand2)
INLINE SC_TIME SUB_DT_DT (SC_DT Operand1, SC_DT Operand2)
#endif


#define MUL_TIME_USINT(Operand1, Operand2) ((SC_TIME)(Operand1 * Operand2))
#define MUL_TIME_UINT(Operand1, Operand2) ((SC_TIME)(Operand1 * Operand2))
#define MUL_TIME_UDINT(Operand1, Operand2) ((SC_TIME)(Operand1 * Operand2))
#define MUL_TIME_SINT(Operand1, Operand2) ((SC_TIME)(Operand1 * Operand2))
#define MUL_TIME_INT(Operand1, Operand2) ((SC_TIME)(Operand1 * Operand2))
#define MUL_TIME_DINT(Operand1, Operand2) ((SC_TIME)(Operand1 * Operand2))
#define MUL_TIME_REAL(Operand1, Operand2) ((SC_TIME)(Operand1 * Operand2))


#if 0	/* function changed 14.09.98 snd */
INLINE SC_TIME MUL_TIME_REAL (SC_TIME Operand1, SC_REAL Operand2)
{
    SC_REAL Product;


    Product = Operand1 * Operand2;
    if (Product >= 0)
        Product += (SC_REAL) 0.5;
    else
        Product -= (SC_REAL) 0.5;
        
    return (SC_TIME) Product;                                   
}
#endif


#define DIV_TIME_USINT(Operand1, Operand2) ((SC_TIME)(Operand1 / Operand2))
#define DIV_TIME_UINT(Operand1, Operand2) ((SC_TIME)(Operand1 / Operand2))
#define DIV_TIME_UDINT(Operand1, Operand2) ((SC_TIME)(Operand1 / Operand2))
#define DIV_TIME_SINT(Operand1, Operand2) ((SC_TIME)(Operand1 / Operand2))
#define DIV_TIME_INT(Operand1, Operand2) ((SC_TIME)(Operand1 / Operand2))
#define DIV_TIME_DINT(Operand1, Operand2) ((SC_TIME)(Operand1 / Operand2))
#define DIV_TIME_REAL(Operand1, Operand2) ((SC_TIME)(Operand1 / Operand2))

#if 0	/* function changed 14.09.98 snd */
INLINE SC_TIME DIV_TIME_REAL (SC_TIME Operand1, SC_REAL Operand2)
{
    /* to remove (stupid) compiler warning use tmp variables: */
    SC_REAL t = (SC_REAL)Operand1;   
    SC_REAL c = (SC_REAL)0.5;
    t = t/Operand2 + c;

    return (SC_TIME) (t);
}
#endif

#if 0	/* function excluded 14.09.98 snd */
INLINE SC_DT CONCAT (SC_DATE Operand1, SC_TOD Operand2)
{
    return Operand1 + (Operand2 + 500) / 1000;
}
#endif

#endif





/**********************************************************************/
#ifndef SCLBISTA_H_
#define SCLBISTA_H_
/* IEC 1131-3 Standard library (table 34) bistable function blocks */   /*~~*/


typedef struct
{
   SC_BOOL      SET1;
   SC_BOOL      RESET;
   SC_BOOL      Q1;
} SR_TYP;
void SR(SR_TYP *ip);

typedef struct
{
   SC_BOOL      SET;
   SC_BOOL      RESET1;
   SC_BOOL      Q1;
} RS_TYP;
void RS(RS_TYP *);

#if(0)
typedef struct
{
   SC_BOOL      CLAIM;
   SC_BOOL      RELEASE;
   SC_BOOL      BUSY;
   SC_BOOL      X;
} SEMA_TYP;
void SEMA(SEMA_TYP *);
#endif


#endif


/**********************************************************************/
#ifndef SCLEDGE_H_
#define SCLEDGE_H_

/* IEC 1131-3 Standard library (table 35) edge detection */       /*~~*/

typedef struct
{
   SC_BOOL      CLK;
   SC_BOOL      Q;
   SC_BOOL      M; /* Additional structure element, adapt slib.asc! */
} R_TRIG_TYP;
void R_TRIG(R_TRIG_TYP *);

typedef struct
{
   SC_BOOL      CLK;
   SC_BOOL      Q;
   SC_BOOL      M; /* Additional structure element, adapt slib.asc! */
} F_TRIG_TYP;
void F_TRIG(F_TRIG_TYP *);


#endif

/*>>>>> End module interface <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/




/**********************************************************************/
#ifndef SCLCOUNT_H_
#define SCLCOUNT_H_

/* IEC 1131-3 Standard library (table 36) counter function blocks */    /*~~*/

typedef struct
{
   SC_BOOL      CU;
   SC_BOOL      RESET;
   SC_INT 	PV;
   SC_BOOL      Q;
   SC_INT 	CV;
   SC_BOOL      CU_M;   /* Additional structure element, adapt slib.asc! */
} CTU_TYP;
void CTU(CTU_TYP *);

typedef struct
{
   SC_BOOL      CD;
   SC_BOOL      LOAD;
   SC_INT 	PV;
   SC_BOOL      Q;
   SC_INT 	CV;
   SC_BOOL      CD_M;	/* Additional structure element, adapt slib.asc! */
} CTD_TYP;
void CTD(CTD_TYP *);

typedef struct
{
   SC_BOOL      CU;
   SC_BOOL      CD;
   SC_BOOL      RESET;
   SC_BOOL      LOAD;
   SC_INT 	PV;
   SC_BOOL      QU;
   SC_BOOL      QD;
   SC_INT 	CV;
   SC_BOOL      CU_M;   /* Additional structure element, adapt slib.asc! */
   SC_BOOL      CD_M;	/* Additional structure element, adapt slib.asc! */
} CTUD_TYP;
void CTUD(CTUD_TYP *);


#endif


/*>>>>> End module interface <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/


/**********************************************************************/
#ifndef SCLTIMER_H_
#define SCLTIMER_H_

/* IEC 1131-3 Standard library (table 37) timer functions */      /*~~*/

typedef struct
{
   SC_BOOL      IN;
   SC_TIME      PT;
   SC_BOOL      Q;
   SC_TIME      ET;
   SC_BOOL      IN_M;	/* Additional structure element, adapt slib.asc! */
   SC_TIME      START;	/* Additional structure element, adapt slib.asc! */
} TP_TYP;
void TP(TP_TYP *);

typedef struct
{
   SC_BOOL      IN;
   SC_TIME      PT;
   SC_BOOL      Q;
   SC_TIME      ET;
   SC_BOOL      IN_M;	/* Additional structure element, adapt slib.asc! */
   SC_TIME      START;	/* Additional structure element, adapt slib.asc! */
} TON_TYP;
void TON(TON_TYP *);


typedef struct
{
   SC_BOOL      IN;
   SC_TIME      PT;
   SC_BOOL      Q;
   SC_TIME      ET;
   SC_BOOL      IN_M;	/* Additional structure element, adapt slib.asc! */
   SC_TIME      START;	/* Additional structure element, adapt slib.asc! */
} TOF_TYP;
void TOF(TOF_TYP *);

SC_DT RTC();

#endif

/**********************************************************************/
SC_BOOL EQ_R_REAL (SC_REAL Operand1, SC_REAL Operand2);
SC_BOOL NE_R_REAL (SC_REAL Operand1, SC_REAL Operand2);

#endif		/* SLIB_H */
/*>>>>> End module interface <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*/
