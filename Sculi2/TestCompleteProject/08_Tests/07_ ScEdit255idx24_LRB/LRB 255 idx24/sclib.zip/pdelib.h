/****************************************************************************/
/*                                                                          */
/*                     Copyright 2004, Liebherr PME1                        */
/*                         ALL RIGHTS RESERVED                              */
/*                                                                          */
/****************************************************************************/
/*! \file	pdelib.h
	\brief	SoftControl library for PDE functions
	\remark	

	$Revision: 22953 $
	$Date: 2010-02-15 08:23:37 +0100 (Mo, 15 Feb 2010) $
 */


/*--------------------------------------------------------------------------*/
/* For compatibility with SoftControl C code generator names of public      */
/* manufacturer library functions are completely written in uppercase       */
/*--------------------------------------------------------------------------*/

#ifndef __PDELIB_H_
#define __PDELIB_H_

/*--------------------------------------------------------------------------*/
/* included files                                                           */
/*--------------------------------------------------------------------------*/
#include "li_types.h"

#if (CORE_STEP==3)
	#define OS_PSOS		1
#endif
#ifdef OS_PSOS
	#include "sps_cfg.h"
#else
	#include "sc_datatyps.h"
	#include "graphic.h"
#endif

/*--------------------------------------------------------------------------*/
/* general definitions                                                      */
/*--------------------------------------------------------------------------*/
/*--- Library Version String -----------------------------------------------*/
#ifdef OS_PSOS
	#ifdef RELEASE
		#if RELEASE==1
			#define PDELIB_VERSION_STRING	"PDELIB 1.015"
		#else
			#define PDELIB_VERSION_STRING	"PDELIB 1.999"
		#endif
	#else
		#define PDELIB_VERSION_STRING	"PDELIB 1.999"
	#endif

	#define SC_POINTER        			SC_UDINT
	
	#define MSG_GROUP_LIB								0x60000000		/* es werden im System 3 nur die Definitionen ben�tigt*/
	#define MSG_SUBGROUP_LIB_PDE						0x06000000		/* es werden im System 3 nur die Definitionen ben�tigt*/
	#define MSG_PRIORITY_INFO							0x00004000		/* es werden im System 3 nur die Definitionen ben�tigt*/
	#define MSG_PRIORITY_NOTICE							0x00006000		/* es werden im System 3 nur die Definitionen ben�tigt*/
	#define MSG_PRIORITY_WARNING						0x00008000		/* es werden im System 3 nur die Definitionen ben�tigt*/
	#define MSG_PRIORITY_ERROR							0x0000A000		/* es werden im System 3 nur die Definitionen ben�tigt*/
	#define MSG_PRIORITY_CRITICAL						0x0000D000		/* es werden im System 3 nur die Definitionen ben�tigt*/
	#define MSG_FLAGS_ACTIVATION						0x00000000		/* es werden im System 3 nur die Definitionen ben�tigt*/

	#define GRAPHIC_SOLID_LINE			SOLID_LINE
	#define GRAPHIC_DOTTED_LINE			DOTTED_LINE
	#define GRAPHIC_CENTER_LINE			CENTER_LINE
	#define GRAPHIC_DASHED_LINE			DASHED_LINE
	#define GRAPHIC_DASH_LONG_LINE		DASH_LONG_LINE
	#define GRAPHIC_DASH_DOT_DOT_LINE	DASH_DOT_DOT_LINE
	#define GRAPHIC_USERBIT_LINE		USERBIT_LINE
	#define GRAPHIC_SMALL_DOT_LINE		SMALL_DOT_LINE
	#define GRAPHIC_DOTTED_CONTINOUS_LINE			DOTTED_LINE
	#define GRAPHIC_LEFT_TEXT			LEFT_TEXT
	#define GRAPHIC_CENTER_TEXT			CENTER_TEXT
	#define GRAPHIC_RIGHT_TEXT			RIGHT_TEXT
	#define GRAPHIC_BOTTOM_TEXT			BOTTOM_TEXT
	#define GRAPHIC_TOP_TEXT			TOP_TEXT
	#define GRAPHIC_HORIZ_DIR			HORIZ_DIR
	#define GRAPHIC_VERT_DIR			VERT_DIR	
#else
	#ifdef RELEASE
		#if RELEASE==1
			#define PDELIB_VERSION_STRING	"2.300"
		#else
			#define PDELIB_VERSION_STRING	"2.999"
		#endif
	#else
		#define PDELIB_VERSION_STRING	"2.999"
	#endif
	#define SC_POINTER        			SC_UDINT
	#if (CORE_STEP==3)
		#undef BREAK
	#endif
#endif


/*--------------------------------------------------------------------------*/
/* structure/type definitions                                               */
/*--------------------------------------------------------------------------*/
#ifdef OS_PSOS
	typedef uint32_t msg_group_t;			/*!< type of message code group definition \ingroup message_stack  */
	typedef uint32_t msg_subgroup_t;		/*!< type of message code subgroup definition \ingroup message_stack  */
	typedef uint32_t msg_priority_t;		/*!< type of message code priority definition \ingroup message_stack  */
	typedef uint32_t msg_flags_t;			/*!< type of message code group flags definition \ingroup message_stack  */
	typedef uint32_t msg_code_t;			/*!< type of the message code \ingroup message_stack  */
	typedef uint32_t msg_add_info_t;		/*!< type of the message code additional info \ingroup message_stack  */
	typedef uint32_t msg_header_t;			/*!< type of the message code header containing machine class, group, subgroup, priority, flags and number of additional infos in one data type \ingroup message_stack  */
	typedef uint32_t schedule_ms_t;

	typedef struct sc_core_tag
		{
		void (*msg_put_general)(msg_code_t code, msg_group_t group, msg_subgroup_t subgroup, msg_priority_t priority, msg_flags_t flags, msg_add_info_t add_info_1, msg_add_info_t add_info_2);
		schedule_ms_t (*read_proz_ms)(void);
		errorcode_t (*pde_set_fun_postcycle)(long mode, errorcode_t(*fun)(char*));
		errorcode_t (*pde_set_fun_graph)(long mode, errorcode_t(*fun)(char*));
		errorcode_t (*pde_set_fun_graph_submode)(long main_mode, long sub_mode, errorcode_t(*fun)(char*));
		errorcode_t (*pde_set_fun_pde)(long main_mode, long sub_mode, errorcode_t(*fun)(char*, char*), long position);
		void (*pde_graf_set_text_justify) ( int, int );
		long (*pde_graf_insert) ( int x, int y, char* path );
		void (*pde_graf_line)(int,int,int,int);
		void (*pde_graf_set_line_style) ( int, unsigned, int );
		void (*pde_graf_outtextxy) ( int, int, char* );
		void (*pde_graf_set_active_page)( int page );
		errorcode_t (*pde_graf_set_text_font)(const char* fontName);
		const char* (*language_get_entry)(const char* section_label, uint32_t index);
		utf8_font_id_t (*language_get_best_fit_font)(const char* section_label);
		utf8_font_id_t (*core_log_get_output_encoding)(void);
		errorcode_t (*utf8_read_file_to_mem)(char** content, const char* fileName, utf8_font_id_t force_font_id);
		char* (*utf8_char_2_utf8)(char* strg, utf8_font_id_t id, uint32_t maxSize);
		char* (*utf8_char_2_utf8_copy)(char* destStrg, uint32_t maxSize, const char* srcStrg, utf8_font_id_t id);
		char* (*utf8_utf8_2_char)(char* strg, utf8_font_id_t id);
		char* (*utf8_utf8_2_char_copy)(char* destStrg, uint32_t maxSize, const char* srcStrg,utf8_font_id_t id);
		utf8_font_id_t (*utf8_get_file_identification)(FILE* fid);
		const char* (*utf8_get_file_identification_string)(utf8_font_id_t font_id);
		const char* (*utf8_get_font_name)(utf8_font_id_t fontID);
		errorcode_t (*utf8_write_file_identification)(FILE* fid, utf8_font_id_t font_id);
		errorcode_t (*utf8_write_utf8_text)(char * const strg, FILE* fid, utf8_font_id_t font_id);
		utf8_font_id_t (*utf8_get_font_id)(const char* fontName);
		int (*pde_graf_get_x)(void);
		int (*pde_graf_get_y)(void);
		time_t  (*c_time) (time_t*);
		} sc_core_t;
	extern sc_core_t* sc_core;
	
	/*! \brief	defines the different string formats used for date and time
		\ingroup	usertime
	 */
	typedef enum {
		USERTIME_FORMAT_DATE_ONLY=0,		/*!< only show date in extended ISO-8601 format \ingroup usertime */
		USERTIME_FORMAT_TIME_ONLY,			/*!< only show time in extended ISO-8601 format \ingroup usertime */
		USERTIME_FORMAT_DATE_TIME,			/*!< show date and time in extended ISO-8601 format \ingroup usertime */
		USERTIME_FORMAT_DATE_TIME_FILE,		/*!< show date and time in ISO-8601 format, but use the basic format on the time because : is not allowed in file names
											this combined notation of extended date and basic time is not allowed according to ISO-8601, but the extended format makes it more readable to our users \ingroup usertime */
		USERTIME_FORMAT_DATE_TIME_LOCAL		/*!< show loca date and time plus offset from UTC in extended ISO-8601 format \ingroup usertime */
		} usertime_string_format_t;	
#endif

typedef uint32_t pdelib_instance_mixing;							/*!< instance of block PDEMIXING */
typedef uint32_t pdelib_instance_pile;								/*!< instance of block PDEPILE */


/*!	\struct sets
	\brief	structure holding settings for stroke count detection
	\ingroup	SC_interface
 */
typedef struct Press2Count_settings_tag {
   real32_t fs;								/* sample frequency */
   uint32_t maxchange;						/* maximal change of adaptive distances */
   uint32_t mindist;						/* minimal distance between two rising edges */
   uint32_t meandist;						/* mean distance between two rising edges */
   uint32_t maxdist;						/* maximal distance between two rising edges */
   uint32_t minup;							/* minimal distance between rising and falling edge */
   uint32_t meanup;							/* mean distance between rising and falling edge */
   uint32_t minwin;							/* minimal windowlength (for second and third MA) */
   uint32_t meanwin;						/* mean windowlength (for second and third MA) */
   real32_t up;								/* actual border for UP-detection (MIN_UP<=up<=MAX_UP) */
   real32_t down;							/* actual border for DOWN-detection (MIN_DOWN<=down<=MAX_DOWN) */
   uint32_t valid_up;						/* distance between rising and falling edge of last valid stroke */
   uint32_t edge_count;						/* count of valid falling edges, reseted, if distance>=maximal distance  */
   real32_t val_up;							/* pressure value at last rising edge */
   uint32_t idx_up[3];						/* indizes of last 3 back-to-back rising edges, newest at index=0, oldest at index=2 */
   real32_t val_down;						/* pressure value at last falling edge */
   uint32_t idx_down[3];					/* indizes of last 3 back-to-back falling edges, newest at index=0, oldest at index=2 */
   uint32_t idx;							/* loop index, reseted, if distance>=maximal distance */
   sint32_t detect[2];						/* detect values of last 2 loop-runs, newest at index=0, oldest at index=1 */
   bool_t   missing_pumps;					/* true, if missing pumps where detected */
} Press2Count_settings_t;



/*--------------------------------------------------------------------------*/
/*! \struct	PDERECORD_TYP
	\brief	SC interface structure for Function Block PDErecord and C Function PDERECORD()
	\ingroup	SC_interface
	\param	PHIX angle x-direction, in �
	\param	PHIY angle y-direction, in �
	\param	DEPTH depth in cm
	\param	ACTIVECYCLE cycle is active and recording has to be done
	\param	IGNOREPHITOPLEN length [cm] on top of slot where angle is ignored because of instable grab, only considered if rising slope on ActiveCycle pin
	\param	IGNOREPHIBOTLEN length [cm] on bottom of slot where angle is ignored because of working grab, only considered if rising slope on ActiveCycle pin
 */
typedef struct { 
                SC_REAL PHIX;
                SC_REAL PHIY;
                SC_REAL DEPTH;
				SC_BOOL ACTIVECYCLE;
                SC_REAL IGNOREPHITOPLEN;
                SC_REAL IGNOREPHIBOTLEN;
			} PDERECORD_TYP;

/*--------------------------------------------------------------------------*/
/*! \struct	PDEDEVIATION_TYP
	\brief	SC interface structure for Function Block PDEdeviation and C Function PDEDEVIATION()
	\ingroup	SC_interface
	\param	DEPTH depth in cm
	\param	VALID FALSE=no deviation for this depth available
	\param	DEVIATIONX deviation x-direction, in [cm]
	\param	DEVIATIONY deviation y-direction, in [cm]
 */
typedef struct { 
                SC_REAL DEPTH;
                SC_BOOL VALID;
                SC_REAL DEVIATIONX;
                SC_REAL DEVIATIONY;
			} PDEDEVIATION_TYP;

/*--------------------------------------------------------------------------*/
/*! \struct	PDEDEVIATIONCUR_TYP
	\brief	SC interface structure for Function Block PDEdeviationCur and C Function PDEDEVIATIONCUR()
	\ingroup	SC_interface
	\param	DEPTH depth in cm
	\param	VALID FALSE=no deviation for this depth available
	\param	DEVIATIONX deviation x-direction, in [cm]
	\param	DEVIATIONY deviation y-direction, in [cm]
 */
typedef struct { 
                SC_REAL DEPTH;
                SC_BOOL VALID;
                SC_REAL DEVIATIONX;
                SC_REAL DEVIATIONY;
			} PDEDEVIATIONCUR_TYP;

/*--------------------------------------------------------------------------*/
/*! \struct	PDEDEVIATIONINFO_TYP
	\brief	SC interface structure for Function Block PDEdeviationInfo and C Function PDEDEVIATIONINFO()
	\ingroup	SC_interface
	\param	DEPTHSLOTMAX maximum depth of current slot in [cm]\n
			corresponds to variable schlitz_tiefemax
	\param	DEPTHCURCYCLE depth of current recorded cycle table in [cm]\n
			corresponds to variable tiefemax
	\param	ACTIVECYCLE we are recording at the moment\n
			corresponds to variable cycle_active
	\param	IGNORECURCYCLE this cycle shall be not used for angle/deviation calculation; was set by PDEignoreCycle\n
			corresponds to variable tab_not_used
	\param	ALLCYCLETABSUSED all internal cycle tables are used for creating the averaged deviation\n
			corresponds to variable all_tab_used
	\param	CURCYCLETAB number of currently recording cycle table\n
			corresponds to variable tab_numb
	\param	INDEXCURCYCLETAB position index in currently recording cycle table\n
			corresponds to variable tab_angle_cur_cycle_ptr
 */
typedef struct { 
	SC_REAL DEPTHSLOTMAX;
	SC_REAL DEPTHCURCYCLE;
	SC_BOOL ACTIVECYCLE;
	SC_BOOL IGNORECURCYCLE;
	SC_BOOL ALLCYCLETABSUSED;
	SC_UDINT CURCYCLETAB;
	SC_UDINT INDEXCURCYCLETAB;
	} PDEDEVIATIONINFO_TYP;

/*--------------------------------------------------------------------------*/
/*! \struct	PDECONSUMPTION_TYP
	\brief	SC interface structure for Function Block PDECONSUMPTION and C Function PDECONSUMPTION()
	\ingroup	SC_interface
	\param	V_LITER actual concrete volume
	\param	A_CM2 pile area
	\param	DX_CM reference pile height
	\param	X_CM actual absolute depth
	\param	ENABLE_1 enable / restart calculation
	\param	CONSUMPTION_1 actual consumption over pile with heigh of about DX_CM
	\param	DV_LITER calculated pump size (amount of conrete volume per pump stroke in [cm3])
	\param	DT_MS time between two pump strokes (last two strokes) in [ms]
 */
typedef struct { 
	SC_REAL V_LITER;
	SC_REAL A_CM2;
	SC_REAL DX_CM;
	SC_REAL X_CM;
	SC_BOOL ENABLE_1;
	SC_REAL CONSUMPTION_1;
	SC_REAL DV_LITER;
	SC_UINT DT_MS;
    SC_BOOL INITOK;
	} PDECONSUMPTION_TYP;
	
/*--------------------------------------------------------------------------*/
/*! \brief	SC interface structure for Function Block PDEPILE and C Function PDEPILE()
	\ingroup	SC_interface
	\param	V_LITER actual concrete volume
	\param	X_CM actual absolute depth
	\param	CONCR_HEIGHT_CM concrete insertion height
	\param	ENABLE enable/disable
	\param	V_DEPTH concrete volume per depth
	\param	VALID indicates, if valid
	\param	INITOK indicates if initialisation was valid
	\param	LAST_ENABLE value of enable at last run
	\param  MSG1 indicates first occurance of a message
	\param	id instance id
 */
typedef struct { 
	SC_REAL V_LITER;
	SC_REAL X_CM;
	SC_REAL CONCR_HEIGHT_CM;
	SC_BOOL ENABLE;
	SC_REAL V_DEPTH;
	SC_BOOL VALID;
	SC_BOOL INITOK;
	SC_BOOL LAST_ENABLE;
	SC_BOOL MSG1;
	pdelib_instance_pile id;
	SC_UDINT t1;
	SC_UDINT t2;
	SC_REAL LAST_V;
	SC_REAL LAST_INTP_V;
	} PDEPILE_TYP;


/*--------------------------------------------------------------------------*/
/*! \brief	SC interface structure for Function Block PDEMIXING and C Function PDEMIXING()
	\ingroup	SC_interface
	\param	REV_R actual revolution count
	\param	X_CM actual absolute depth
	\param	AUGER_HEIGHT_CM auger height
	\param	ENABLE enable/disable
	\param	REV revolution count
	\param	VALID indicates, if valid
	\param	INITOK indicates if initialisation was valid
	\param	LAST_ENABLE value of enable at last run
	\param  MSG1 indicates first occurance of a message
	\param	id instance id
 */
typedef struct {
	SC_REAL REV_R;
	SC_REAL X_CM;
	SC_REAL AUGER_HEIGHT_CM;
	SC_BOOL ENABLE;
	SC_REAL REV;
	SC_BOOL VALID;
	SC_BOOL INITOK;
	SC_BOOL LAST_ENABLE;
	SC_BOOL MSG1;
	pdelib_instance_mixing id;
	} PDEMIXING_TYP;


/*--------------------------------------------------------------------------*/
/*! \brief	SC interface structure for Function Block PDEHAMMER and C Function PDEHAMMER()
	\ingroup	SC_interface
	\param	BLOW true, if a blow is detected
	\param	E energy of actual blow
	\param	X_CM actual absolute depth
	\param	DEPTHSTEP_CM reference depthstep 
	\param	ENABLE enable/disable
	\param	BLOWS_DEPTH blows per depthstep
	\param	E_DEPTH energy per depthstep
	\param	VALID indicates, if valid
	\param	INITOK indicates if initialisation was valid
	\param	LAST_ENABLE value of enable at last run
	\param  MSG1 indicates first occurance of a message
 */
typedef struct { 
	SC_BOOL BLOW;
	SC_REAL E;
	SC_REAL X_CM;
	SC_REAL DEPTHSTEP_CM;
	SC_BOOL ENABLE;
	SC_REAL BLOWS_DEPTH;
	SC_REAL E_DEPTH;
	SC_BOOL VALID;
	SC_BOOL INITOK;
	SC_BOOL LAST_ENABLE;
	SC_BOOL MSG1;
	} PDEHAMMER_TYP;


/*--------------------------------------------------------------------------*/
/*! \brief	SC interface structure for Function Block PDEHAMMER5SLOTS and C Function PDEHAMMER5SLOTS()
	\ingroup	SC_interface
	\param	BLOW true, if a blow is detected
	\param	X_CM actual absolute depth
	\param	REFBLOWCOUNT number of blows within each slot
	\param	ENABLE enable/disable
	\param	SLOT5 intrusion sum within slot 5
	\param	SLOT4 intrusion sum within slot 4
	\param	SLOT3 intrusion sum within slot 3
	\param	SLOT2 intrusion sum within slot 2
	\param	SLOT1 intrusion sum within slot 1
	\param	SLOT_ACT actual intrusion sum within moving slot
	\param	BLOWCOUNT_ACT actual count of blows within moving slot
	\param	VALID indicates, if valid
	\param	INITOK indicates if initialisation was valid
	\param	FIRST_BLOW indicates first blow
	\param	LAST_ENABLE value of enable at last run
	\param	LAST_DEPTH value of depth at last blow
	\param	refblowcnt storage of number of refblowcount
	\param	blowcount absolute number of blows
	\param	moving_slot pointer for holding buffer containing intrusion values of last x blows
 */
typedef struct { 
	SC_BOOL BLOW;
	SC_REAL X_CM;
	SC_UDINT REFBLOWCOUNT;
	SC_BOOL ENABLE;
	SC_REAL SLOT5;
	SC_REAL SLOT4;
	SC_REAL SLOT3;
	SC_REAL SLOT2;
	SC_REAL SLOT1;
	SC_REAL SLOT_ACT;
	SC_UDINT BLOWCOUNT_ACT;
	SC_BOOL VALID;
	SC_BOOL INITOK;
	SC_BOOL FIRST_BLOW;
	SC_BOOL LAST_ENABLE;
	SC_REAL LAST_DEPTH;
	uint32_t refblowcnt;
	uint32_t blowcount;
	void* moving_slot;
	} PDEHAMMER5SLOTS_TYP;


/*--------------------------------------------------------------------------*/
/*! \brief	SC interface structure for Function Block PDEDATATX and C Function PDEDATATX()
	\ingroup	SC_interface
	\param	TABLE_ID synchonisation table ID
	\param	FLAG_IN synchronisation flag
	\param	DEPTH synchronisation depth
	\param	FLAG_OUT synchronisation flag
	\param	VALUE synchonisation value at depth DEPTH
 */
typedef struct { 
	SC_UDINT TABLE_ID;
	SC_BOOL FLAG_IN;
	SC_REAL DEPTH;
	SC_BOOL FLAG_OUT;
	SC_REAL VALUE;
	} PDEDATATX_TYP;


/*--------------------------------------------------------------------------*/
/*! \brief	SC interface structure for Function Block PDEDRILLPROGRESS and C Function PDEDRILLPROGRESS()
	\ingroup	SC_interface
	\param DEPTH	actual depth of auger in [cm]
	\param REVOLUTION	actual revolution count of auger [1]
	\param DEPTHRANGE	max. range of buffer [cm]
	\param DEPTHCOUNT	max. number of divisions of max. range from buffer [1]
	\param ENABLE		enable drill progress calculation
	\param DRILLPROGRESS	drill progress
	\param VALID validation flag of drill progress
	\param INITOK indicates if initialisation was valid
	\param FIRST_BLOW indicates first blow
	\param LAST_ENABLE value of enable at last run
	\param LAST_RANGE value range at last run
	\param BUFFER pointer to ringbuffer
 */
typedef struct {
	SC_REAL DEPTH;
	SC_REAL REVOLUTION;
	SC_REAL DEPTHRANGE;
	SC_UINT DEPTHCOUNT;
	SC_BOOL ENABLE;
	SC_REAL DRILLPROGRESS;
	SC_BOOL VALID;
    SC_BOOL INITOK;
	SC_BOOL LAST_ENABLE;
	SC_REAL LASTRANGE;
    SC_POINTER BUFFER;
    SC_BOOL MSG1;
    SC_BOOL MSG2;
	} PDEDRILLPROGRESS_TYP;


/*--------------------------------------------------------------------------*/
/*! \brief	SC interface structure for Function Block PDEPRESS2COUNT and C Function PDEPRESS2COUNT()
	\ingroup	SC_interface
	\param PRESSURE		actual concrete pressure [bar]
	\param MINPUMPFREQ	minimal pump frequency [strokes/min]
	\param MAXPUMPFREQ	maximal pump frequency [strokes/min]
	\param ENABLE		enable stroke detection
	\param STROKECOUNT	count of concrete pump's strokes [1]
	\param VALID		validation flag of strokecount
 */	
typedef struct {
	SC_REAL PRESSURE;
	SC_UINT MINPUMPFREQ;
	SC_UINT MAXPUMPFREQ;
	SC_BOOL ENABLE;
	SC_UDINT STROKECOUNT;
	SC_BOOL VALID;
	SC_UINT INIT_STATE;
	SC_BOOL INITOK;
	SC_UINT STATE;
	Press2Count_settings_t sets;
	void* mw[4];
	} PDEPRESS2COUNT_TYP;
		
/*--------------------------------------------------------------------------*/
/* global variables                                                         */
/*--------------------------------------------------------------------------*/
extern SC_UDINT SC_PDE_ID_HAM_BPD;
extern SC_UDINT SC_PDE_ID_HAM_EPD;
extern SC_UDINT SC_PDE_ID_MIXING1;
extern SC_UDINT SC_PDE_ID_MIXING2;
extern SC_UDINT SC_PDE_ID_MIXING3;
extern SC_UDINT SC_PDE_ID_PILE1;
extern SC_UDINT SC_PDE_ID_PILE2;
extern SC_UDINT SC_PDE_ID_PILE3;

/*--------------------------------------------------------------------------*/
/* function prototypes                                                      */
/*--------------------------------------------------------------------------*/
SC_INT PDEGR_VIBRATOR(SC_INT Mode, SC_INT SubMode, SC_INT TimePlot);
SC_INT PDEGR_SOB(SC_INT Mode, SC_INT SubMode, SC_INT TimePlot);
SC_INT PDEGR_VDW(SC_INT Mode, SC_INT SubMode, SC_INT TimePlot);
SC_INT PDEGR_KELLY(SC_INT Mode, SC_INT SubMode, SC_INT TimePlot);
SC_INT PDEGR_GRAB(SC_INT Mode, SC_INT SubMode, SC_INT TimePlot);
SC_INT PDEGR_GRABPOST(SC_INT Mode, SC_INT SubMode);
SC_INT PDEGR_PUPU(SC_INT Mode, SC_INT SubMode, SC_INT TimePlot);
SC_INT PDEGR_HAMMER(SC_INT Mode, SC_INT SubMode, SC_INT TimePlot);
SC_INT PDEGR_SOILMIX(SC_INT Mode, SC_INT SubMode, SC_INT TimePlot);
SC_INT PDEGR_EVRC(SC_INT Mode,SC_INT SubMode,SC_INT TimePlot);
SC_INT PDEGR_GSC(SC_INT Mode, SC_INT SubMode, SC_INT TimePlot);
errorcode_t pdelib_instances_init(void);
void PDECONSUMPTION(PDECONSUMPTION_TYP* ip);
void PDEPILE(PDEPILE_TYP* ip);
void PDEMIXING(PDEMIXING_TYP* ip);
void PDEHAMMER(PDEHAMMER_TYP* ip);
void PDEHAMMER5SLOTS(PDEHAMMER5SLOTS_TYP* ip);
void PDEHAMMER5SLOTS_FREE(PDEHAMMER5SLOTS_TYP* ip);
void PDEDATATX(PDEDATATX_TYP* ip);
void PDEDEVIATION(PDEDEVIATION_TYP* ip);
void PDEDEVIATIONCUR(PDEDEVIATIONCUR_TYP* ip);
void PDEDEVIATIONINFO(PDEDEVIATIONINFO_TYP* ip);
void PDEDRILLPROGRESS(PDEDRILLPROGRESS_TYP* ip);
void PDEDRILLPROGRESS_FREE(PDEDRILLPROGRESS_TYP* ip);
void PDEPRESS2COUNT(PDEPRESS2COUNT_TYP* ip);
void PDEPRESS2COUNT_FREE(PDEPRESS2COUNT_TYP* ip);
void PDERECORD(PDERECORD_TYP* ip);
SC_UDINT PDEDEBUGWRITE(void);
SC_BOOL PDEIGNORECYCLE(SC_BOOL ignore);

#ifdef OS_PSOS
#else
	graphic_pixel_t getmaxx(void);
	graphic_pixel_t getmaxy(void);
	graphic_pixel_t getx(void);
	graphic_pixel_t gety(void);
	uint32_t scan_column_min_max(char* f_name, uint32_t column, real32_t* v_min, real32_t* v_max);
	uint32_t scan_min_max(char* f_name, sint32_t* v_min, sint32_t* v_max, sint32_t norm);
	void win_unit_x(graphic_pixel_t x1, graphic_pixel_t x2, graphic_pixel_t y, real32_t mark_x, sint32_t start, sint32_t unit_x);
	void win_unit_y(graphic_pixel_t y1, graphic_pixel_t y2, graphic_pixel_t x, real32_t mark_y, sint32_t start, sint32_t unit_y);
	void win_diagram(graphic_pixel_t x1, graphic_pixel_t y1, graphic_pixel_t x2, graphic_pixel_t y2, real32_t mark_x, real32_t mark_y);
	errorcode_t insert_pcx(graphic_pixel_t x, graphic_pixel_t y, char* path);
	void line(graphic_pixel_t x1, graphic_pixel_t y1, graphic_pixel_t x2, graphic_pixel_t y2);
	void lineto(graphic_pixel_t x, graphic_pixel_t y);
	void moveto(graphic_pixel_t x, graphic_pixel_t y);
	void outtext(char* strg);
	void outtextxy(graphic_pixel_t x,graphic_pixel_t y,char* strg);
	void rectangle(graphic_pixel_t x1, graphic_pixel_t y1, graphic_pixel_t x2, graphic_pixel_t y2);
	void setactivepage(fb_page_idx_t page);
	void setlinestyle(graphic_line_style_t linestyle, graphic_line_pattern_t upattern, uint16_t thickness);
	void settextjustify(graphic_text_justify_t x,graphic_text_justify_t y);
	void split_buf_line(char* source, char* split1, char* split2);
#endif

/*--------------------------------------------------------------------------*/
/* internal function prototypes                                             */
/*--------------------------------------------------------------------------*/
#ifdef OS_PSOS
	void pdelib_register(void);
#else
	void pdelib_init(void);
#endif


#endif
