/**************************************************************************/
/*                                                                        */
/*                                                                        */
/*   Project :    LMB                                                     */
/*                                                                        */
/*   Modul   :    lmllib2.h - LWN Manufacturer-Library C-Code             */
/*                                                                        */
/*   Version :    V0.0                                                    */
/*                                                                        */
/*   Author  :    Gerhard Tockner TB-EL                                   */
/*                                                                        */
/*   History :                                                            */
/*------------------------------------------------------------------------*/
/* Ver.Nr. |  	Datum    |     Name     |     Beschreibung                */ 
/*---------|-------------|--------------|---------------------------------*/
/*  0001   | 18.01.2001  | Tockner      | created                         */
/*         |             |              |                                 */
/*         |             |              |                                 */
/*------------------------------------------------------------------------*/
/*                                                                        */
/*   (c) 2001 Liebherr - Werk Nenzing                                     */
/*                                                                        */
/**************************************************************************/
/*! \file lmllib2.h
	\brief Header Datei f�r die Schnittstelle zu Softing
 	\author Gerhard Tockner
	\version 0.0 Initial version
	\date 18.01.2001 */

	
/*
~~
~~  For compatibility with SoftControl C code generator names of public
~~  manufacturer library functions are completely written in uppercase.
~~
*/


#ifndef LMLLIB2_H
	#define LMLLIB2_H

/*--- Library Version String -----------------------------------------------*/
#define LMLLIB2_VERSION_STRING	"4.300"


/*--- LMBPage --------------------------------------------------------------*/
#include "lzs.h"
#include "sc_datatyps.h"

// Initialise the SoftControl libary lmllib2
void lmllib2_init(void);


//- Anfang Schnittstelle zur Softing Applikation -------------------------------*/

/*!	\struct AD_LML2_ASYNC_TYP
	\brief Diese Struktur ist die Schnittstelle zur Softing Oberfl�che (Asynchrone SPS Task)!
	\author Gerhard Tockner
	\version 0.0 Initial version
	\date 19.01.2001 */
typedef struct {
				} AD_LML2_ASYNC_TYP;


/*!	\struct AD_LML2_SYNC_TYP
	\brief Diese Struktur ist die Schnittstelle zur Softing Oberfl�che (Synchrone SPS Task)!
	\author Gerhard Tockner
	\version 0.0 Initial version
	\date 19.01.2001 */
typedef struct {
				// Eing�nge:
				SC_UINT BOOM_LOAD_LE_1;	
				SC_UINT BOOM_LOAD_LE_2;	
				SC_UINT BOOM_LOAD_RI_1;		
				SC_UINT BOOM_LOAD_RI_2;		
				SC_UINT BOOM_ANGL_DOW;
				SC_UINT BOOM_ANGL_TOP;
				SC_UINT LUFFJIB_LOAD_LE;
				SC_UINT LUFFJIB_LOAD_RI;
				SC_UINT LUFFJIB_ANGL_DOW;
				SC_UINT LUFFJIB_ANGL_TOP;
				SC_REAL LUFFJIB_PRESSURE;
				SC_UINT DERRICK_LOAD_LE;
				SC_UINT DERRICK_LOAD_RI;
				SC_UINT SB_LOAD_LE;
	           	SC_UINT SB_LOAD_RI;
				SC_REAL LENGTH_BAL_ZYL;
				SC_WORD LML_SYS_KEY;
				SC_BOOL US_UNITS;
				SC_BOOL BOOM_STABIL_ON;
				SC_BOOL CARRIER_ACTIVE;
				SC_UDINT SELECT_LML_ID_NR;
               	SC_BOOL ASSEMBLY_MODE;
				SC_BOOL SINGLE_SEN_SCALE;
                        
                // Ausg�nge:        
				SC_REAL BOOM_ANGLE;
				SC_REAL BOOM_ANGLE_DOWN;
				SC_REAL LUFFJIB_ANGLE;
				SC_REAL UTILIZATION;
				SC_REAL UTILIZATION_DERR;
				SC_REAL BOOM_LOAD_ACT;
				SC_REAL BOOM_LOAD_MAX;
				SC_REAL BOOM_RADIUS;
				SC_REAL BOOM_HEIGHT;
				SC_REAL BOOM_REEVING;
				SC_REAL LUFFJIB_LOAD_ACT;
				SC_REAL LUFFJIB_LOAD_MAX;
				SC_REAL LUFFJIB_RADIUS;
				SC_REAL LUFFJIB_HEIGHT;
				SC_REAL LUFFJIB_REEVING;
				SC_REAL BALLAST_LOAD_ACT;
				SC_REAL BALLAST_RADIUS;
				SC_REAL GROUND_PRESS_0;
				SC_REAL GROUND_PRESS_45;
				SC_REAL GROUND_PRESS_90;
				SC_REAL ROPE_LENGTH_W1;
				SC_REAL ROPE_LENGTH_W2;
				SC_REAL DIST_WHEKIT_IN;
				SC_REAL DIST_WHEKIT_OUT;
				SC_REAL LML_MODE;
				SC_BOOL LML_CALCULATING;		
				SC_BOOL LML_CANT_BACK;
				SC_BOOL LML_ERROR;
				SC_BOOL LML_SECOND_PAGE;
				SC_REAL MAX_ALPHA;
				SC_BOOL BC_ACTIVE;
				SC_REAL BC_ANGLE;
				SC_REAL LOAD_LOCATION;
				SC_BOOL INVALID_LML_DATA;
				SC_BOOL ACTIVE_MIDFALL;
				SC_REAL OPERATIONAL_MODE;
				SC_REAL BOOM_HEAD_TYPE;
				SC_REAL KML_HPT_SCALE;
				SC_BOOL KML_HPT_REDUND;
 				} AD_LML2_SYNC_TYP;

/*!	\struct AD_LML2_1_SYNC_TYP
	\brief Diese Struktur ist die Schnittstelle zur Softing Oberfl�che (Synchrone SPS Task)!
	\author Gerhard Tockner
	\version 0.0 Initial version
	\date 23.03.2005 */
typedef struct {
				// Eing�nge:
				SC_BOOL ERR_KML_HPT_LE_1;
				SC_BOOL ERR_KML_HPT_LE_2;
				SC_BOOL ERR_KML_HPT_RI_1;
				SC_BOOL ERR_KML_HPT_RI_2;
				SC_BOOL ERROR_KML_NDL_LE;
				SC_BOOL ERROR_KML_NDL_RI;
				SC_BOOL ERROR_KML_DER_LE;
				SC_BOOL ERROR_KML_DER_RI;
				SC_BOOL ER_KML_DER_SB_LE;
				SC_BOOL ER_KML_DER_SB_RI;
				SC_BOOL ERROR_ANGLE_HPT;
				SC_BOOL ERROR_ANGLE_NDL;

				// Ausg�nge:
				SC_BOOL ERROR_RFS1_ABOVE;
				SC_BOOL ERROR_RFS1_BELOW;
				SC_BOOL ERR_DIFF_ANG_HPT;
				SC_BOOL ERR_DIFF_ANG_NDL;
				SC_BOOL ERR_DIFF_KML_HPT;
				SC_BOOL ERR_DIFF_KML_NDL;
				SC_BOOL ERR_DIFF_KML_DER;
				SC_BOOL E_DIF_KML_DER_SB;
				SC_BOOL E_KML_HPT_RED_LE;
				SC_BOOL E_KML_HPT_RED_RI;
				
				SC_REAL FORCE_MIN_RAD_BW;
				SC_REAL MIN_RAD_BW;
				SC_REAL FORCE_MAX_RAD_BW;
				SC_REAL MAX_RAD_BW;
				SC_REAL Y_ROD;
				
				SC_BOOL LML_SYS_RUNNING;
				SC_UDINT LML_SYS_TIME;
				
				SC_BOOL VALID_TLT;
				SC_BOOL AUX_CRANE;
				} AD_LML2_1_SYNC_TYP;


/*!	\struct AD_LML2_INIT_TYP
	\brief Diese Struktur ist die Schnittstelle zur Softing Oberfl�che (Init SPS Task)!
	\author Gerhard Tockner
	\version 0.0 Initial version
	\date 19.01.2001 */
typedef struct {
				SC_BOOL US_UNITS;
				SC_UDINT SELECT_LML_ID_NR;
	} AD_LML2_INIT_TYP;


/*--- Funktionsprototypen --------------------------------------------------- */
#if __cplusplus
	 extern "C" {
#endif

/*!	\fn void AD_LML_INIT (AD_LML_INIT_TYP *ip)
	\brief Diese Funktion wird nur 1x beim Einschalten der Steuerung ausgef�hrt !
	\param ip Pointer auf eine Struktur (Softing Funktionsblock INIT Task).
	\return keiner */
void AD_LML2_INIT (AD_LML2_INIT_TYP *ip);

/*!	\fn void AD_LML2_SYNC (AD_LML_SYNC_TYP *ips)
	\brief Diese Funktion wird von der synchronen SPS Task aufgerufen !
	\param ips Pointer auf eine Struktur (Softing Funktionsblock SYNCHRONE Task).
	\return	keiner */
void AD_LML2_SYNC (AD_LML2_SYNC_TYP *ips);

/*!	\fn void AD_LML2_1_SYNC (AD_LML2_1_SYNC_TYP *ips)
	\brief Diese Funktion wird von der synchronen SPS Task aufgerufen !
	\brief Diese Funktion wurde eingef�hrt, da in der Funktion AD_LML2_SYNC()die max.Anzahl der Ein-/Ausg�nge(63) �berschritten wurde.
	\param ips1 Pointer auf eine Struktur (Softing Funktionsblock SYNCHRONE Task).
	\return	keiner */
void AD_LML2_1_SYNC (AD_LML2_1_SYNC_TYP *ips1);

/*!	\fn void AD_LML_ASYNC (AD_LML_ASYNC_TYP *ipa)
	\brief Diese Funktion wird von der asynchronen SPS Task aufgerufen !
	\param ipa Pointer auf eine Struktur (Softing Funktionsblock ASYNCHRONE Task).
	\return keiner */
void AD_LML2_ASYNC (AD_LML2_ASYNC_TYP *ipa);

#if __cplusplus
	}	/* Ende extern "C" */
#endif

//- Ende Interface zur Softing Applikation -----------------------------------

/*--- eof --------------------------------------------------------------------*/

#endif


