/****************************************************************************/
/*                                                                          */
/*                     Copyright 2004, Liebherr PME1                        */
/*                         ALL RIGHTS RESERVED                              */
/*                                                                          */
/****************************************************************************/
/*!	\file	seclib.h
	\brief	LWN manufacturer library header
	\ingroup seclib
 
	$Revision: $
	$Date: $

*/

/*
~~
~~  For compatibility with SoftControl C code generator names of public
~~  manufacturer library functions are completely written in uppercase.
~~
*/


#if !defined(__SECLIB_H)
#define __SECLIB_H

/*--------------------------------------------------------------------------*/
/* included files                                                           */
/*--------------------------------------------------------------------------*/
#include "li_types.h"
#include "sc_datatyps.h"

/*--------------------------------------------------------------------------*/
/* general definitions                                                      */
/*--------------------------------------------------------------------------*/

/*--- Library Version String -----------------------------------------------*/
#if 0
	#define SECLIB_VERSION_STRING	"1.304"		/*!< fake for LiSM */
#endif
#ifndef SECLIB_VERSION_STRING
	#define SECLIB_VERSION_STRING	1.999		/*!< default version number (is automatically quoted inside function lwnlib_init() ) */
#endif
#define QUOTEME_(x) #x
#define QUOTEME(x) QUOTEME_(x)

/*--------------------------------------------------------------------------*/
/* structure/type definitions                                               */
/*--------------------------------------------------------------------------*/

typedef struct
{	/*INPUTS*/
	SC_DINT	IN1;
	SC_DINT	IN2;
	/*OUTPUTS*/
	SC_DINT	OUT1;
	SC_DINT	OUT2;
	SC_BOOL DATAVALID;
	SC_BOOL KEYDETECTED;
	SC_BOOL KEYMATCHED;
	SC_UDINT SERIALNUMBER;
	SC_UDINT PRIORITYLEVEL;
} SECKEY_TYP;

typedef struct
{	/*INPUTS*/
	SC_DINT	IN1;
	SC_DINT	IN2;
	/*OUTPUTS*/
	SC_DINT	OUT1;
	SC_DINT	OUT2;
	SC_BOOL DATAVALID;
	SC_BOOL KEYDETECTED;
	SC_BOOL KEYMATCHED;
	SC_UDINT SERIALNUMBER;
	SC_UDINT PRIORITYLEVEL;
	SC_UDINT KEYTYPE;
} SECKEYTYPE_TYP;

typedef struct
{	/*INPUTS*/
	SC_BOOL	KEYMATCH;
	SC_BOOL	KEYREMOVE;
	SC_BOOL	KEYREMOVEALL;
	/*OUTPUTS*/
	SC_BOOL KEYWRITING;
} SECIMMO_TYP;

typedef struct
{	/*INPUTS*/
	/*OUTPUTS*/
	SC_BOOL DATAVALID;
	SC_UDINT KEYCOUNT;
	SC_UDINT KEYIDX;
} SECINFO_TYP;

typedef struct
{	/*INPUTS*/
	/*OUTPUTS*/
	SC_UINT STATUS;
	SC_BOOL SYNCHRONOUS;
	SC_UDINT D1;
	SC_UDINT D2;
	SC_UDINT D3;
	SC_UDINT D4;
	SC_UDINT D5;
	SC_UDINT D6;
	SC_UDINT D7;
	SC_UDINT D8;
	SC_UDINT D9;
	SC_UDINT D10;
	SC_UDINT D11;
	SC_UDINT D12;
	SC_UDINT D13;
	SC_UDINT D14;
} SECINFO2_TYP;

/*--------------------------------------------------------------------------*/
/* global variables                                                         */
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/* function definitions                                                     */
/*--------------------------------------------------------------------------*/

void seclib_init(void);
void SECKEY(SECKEY_TYP* ip);
void SECKEYTYPE(SECKEYTYPE_TYP* ip);
void SECIMMO(SECIMMO_TYP* ip);
void SECINFO(SECINFO_TYP* ip);
void SECINFO2(SECINFO2_TYP* ip);

#endif
