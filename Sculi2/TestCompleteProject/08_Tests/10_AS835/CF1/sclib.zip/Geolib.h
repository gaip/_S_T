/****************************************************************************/
/*                                                                          */
/*                        LIEBHERR  Litronic                                */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*                                                                          */
/*                                                                          */
/****************************************************************************/
/*                                                                          */
/*              Copyright 2001, Liebherr Werk Nenzing GmbH                  */
/*                         ALL RIGHTS RESERVED                              */
/*                                                                          */
/****************************************************************************/
/*! \file	geolib.h
	\brief	

 */



/*
~~
~~  For compatibility with SoftControl C code generator names of public
~~  manufacturer library functions are completely written in uppercase.
~~
*/


#ifndef __GEOLIB_H_
#define __GEOLIB_H_

/*--------------------------------------------------------------------------*/
/* included files                                                           */
/*--------------------------------------------------------------------------*/
#include "li_types.h"
#include "sc_datatyps.h"
#include "msg_stack.h"

/*--------------------------------------------------------------------------*/
/* general definitions (private/not exported)                               */
/*--------------------------------------------------------------------------*/

/*--- Library Version String -----------------------------------------------*/
#ifdef RELEASE
	#if RELEASE==1
		#define GEOLIB_VERSION_STRING	"2.301"
	#else
		#define GEOLIB_VERSION_STRING	"2.999 / "__DATE__
	#endif
#else
	#define GEOLIB_VERSION_STRING	"2.999 / "__DATE__
#endif


/****************************************************************************/
/* as SoftControl generated files use variables and structure elements in   */
/* capital letters and header files of VxWorks use #define, we have to      */
/* avoid collisions. So we undefine some of these here                      */
/****************************************************************************/
#undef BUFSIZE



/*--------------------------------------------------------------------------*/
/* global variables (public/exported)                                       */
/*--------------------------------------------------------------------------*/
			
/*--------------------------------------------------------------------------*/
/* global variables (private/not exported)                                  */
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/* function prototypes (private/not exported)                               */
/*--------------------------------------------------------------------------*/

void geolib_init(void);		/*! todo: why here? */
errorcode_t GL_INIT_REGISTERS(void);


/*--------------------------------------------------------------------------*/
/* function definition (puplic/exported)                                    */
/*--------------------------------------------------------------------------*/

/*--- Initialisation routines ----------------------------------------------*/
SC_UDINT GEONEWPOINT();
SC_UDINT GEONEWVECTOR();
SC_UDINT GEONEWLINE();
SC_UDINT GEONEWLINESEG();
SC_UDINT GEONEWTRIANGLE();
SC_UDINT GEONEWRECTANGLE();
SC_UDINT GEONEWCIRCLE();
SC_UDINT GEONEWCOORDSYS(SC_UDINT base_ks);

SC_UDINT GEONEWPMASS();
//SC_UDINT GEONEWCABLE();

/*--- Set value ------------------------------------------------------------*/
SC_BOOL GEOSETPOINTXY(SC_UDINT POINT, SC_REAL X, SC_REAL Y, SC_UDINT REFCOORDSYS);
SC_BOOL GEOSETPOINTRPHI(SC_UDINT POINT, SC_REAL RADIUS, SC_REAL PHI, SC_UDINT REFCOORDSYS);
SC_BOOL GEOSETPOINTXYZ(SC_UDINT POINT, SC_REAL X, SC_REAL Y, SC_REAL Z, SC_UDINT REFCOORDSYS);
SC_BOOL GEOSETVECTORXY(SC_UDINT VECTOR, SC_REAL X, SC_REAL Y, SC_UDINT REFCOORDSYS);
SC_BOOL GEOSETVECTORRPHI(SC_UDINT VECTOR, SC_REAL RADIUS, SC_REAL PHI, SC_UDINT REFCOORDSYS);
SC_BOOL GEOSETVECTORXYZ(SC_UDINT VECTOR, SC_REAL X, SC_REAL Y, SC_REAL Z, SC_UDINT REFCOORDSYS);
SC_BOOL GEOSETLINE(SC_UDINT LINE, SC_UDINT POINTONLINE, SC_UDINT DIRECTION, SC_UDINT REFCOORDSYS);
SC_BOOL GEOSETLINESEG(SC_UDINT LINESEGMENT, SC_UDINT LIMITPOINT1, SC_UDINT LIMITPOINT2, SC_UDINT REFCOORDSYS);
SC_BOOL GEOSETTRIANGLE(SC_UDINT TRIANGLE, SC_UDINT CORNERPOINT1, SC_UDINT CORNERPOINT2, SC_UDINT CORNERPOINT3, SC_UDINT REFCOORDSYS);
SC_BOOL GEOSETRECTANGLE(SC_UDINT RECTANGLE, SC_REAL XPOSITION, SC_REAL YPOSITION, SC_REAL XEDGELENGTH, SC_REAL YEDGELENGTH, SC_UDINT REFCOORDSYS);
SC_BOOL GEOSETCIRCLE(SC_UDINT CIRCLE, SC_UDINT CENTERPOINT, SC_REAL RADIUS, SC_UDINT REFCOORDSYS);
SC_BOOL GEOSETCOORDSYS(SC_UDINT COORDSYS, SC_REAL X, SC_REAL Y, SC_REAL PHI, SC_BOOL ROTATEFIRST);
SC_BOOL GEOSETPOINTMASS(SC_UDINT POINTMASS,SC_UDINT POINT,SC_REAL M,SC_UDINT REFCOORDSYS);
//SC_BOOL GEOGETCABLEFORCE(SC_UDINT CABLE, SC_UDINT CABLEFORCE1, SC_UDINT CABLEFORCE2);
//SC_BOOL GEOGETCABLEL(SC_UDINT CABLE, SC_REAL LENGTH);


/*--- Koord.transformation -------------------------------------------------*/
SC_BOOL GEOTRANSLATEXY(SC_REAL X, SC_REAL Y, SC_UDINT COORDSYS);
SC_BOOL GEOTRANSLATERPHI(SC_REAL RADIUS, SC_REAL PHI, SC_UDINT COORDSYS);
SC_BOOL GEOTRANSLATE3D(SC_REAL X, SC_REAL Y, SC_REAL Z, SC_UDINT COORDSYS);
SC_BOOL GEOROTATE(SC_REAL PHI, SC_UDINT COORDSYS);
SC_BOOL GEOROTATE3D(SC_REAL PHIZ, SC_REAL PHIY, SC_REAL PHIX, SC_UDINT COORDSYS);


/*--------------------------------------------------------------------------*/
/*--- robotic functions                                                  ---*/
/*--------------------------------------------------------------------------*/

SC_BOOL GEOCROSSPROD(SC_UDINT IdOutV, SC_UDINT IdInV1, SC_UDINT IdInV2);

//SC_BOOL GEOJACOBIAN(SC_UDINT IDVELOCITY, SC_REAL PHI1, SC_REAL PHI2, SC_REAL DPHI1, SC_REAL DPHI2, SC_REAL DPHI3, SC_REAL DESIGN1, SC_REAL DESIGN2, SC_UDINT REFCOORDSYS);
SC_BOOL GEOJACOBIAN(SC_REAL IDPHI1, SC_REAL IDPHI2, SC_REAL IDDPHI1, SC_REAL IDDPHI2, SC_REAL IDDPHI3, SC_REAL IDDESIGN1, SC_REAL IDDESIGN2, SC_UDINT IAREFCOORDSYS, SC_UDINT IAVELOCITY);


SC_REAL GEO3RPTRAFO(SC_REAL idS, SC_REAL idA1, SC_REAL idA2);
SC_REAL GEO3RPINVTRAFO(SC_REAL idANGLE1, SC_REAL idA1, SC_REAL idA2);
SC_REAL GEO4R2PTRAFO(SC_REAL idS, SC_REAL idA1, SC_REAL idA2, SC_REAL idA3, SC_REAL idN1, SC_REAL idN2);
SC_REAL GEO4R2PINVTRAFO(SC_REAL idALPHA1, SC_REAL idA1, SC_REAL idA2, SC_REAL idA3, SC_REAL idN1, SC_REAL idN2);
SC_REAL GEO3RPJACOBIAN(SC_REAL idALPHA1, SC_REAL idA1, SC_REAL idA2,SC_REAL idDs);
SC_REAL GEO3RPINVJACOBI(SC_REAL idALPHA1, SC_REAL idA1, SC_REAL idA2,SC_REAL idDalpha1);
SC_REAL GEO4R2PJACOBIAN(SC_REAL idALPHA1, SC_REAL idA1, SC_REAL idA2, SC_REAL idA3, SC_REAL idN1, SC_REAL idN2, SC_REAL idDS);
SC_REAL GEO4R2PINVJACOBI(SC_REAL idALPHA1, SC_REAL idA1, SC_REAL idA2, SC_REAL idA3, SC_REAL idN1, SC_REAL idN2, SC_REAL idDALPHA1);


/*--- Set structures -----------------------------------------------------*/

/*! \struct	GEOSETCABLE_TYP
	\brief	SC interface structure for Function Block GeoSetCable and C Function GEOGETSETCABLE()
	\ingroup	SC_interface_get
*/
/*
typedef struct {
					SC_UDINT IDCABLE;
					SC_UDINT IDCIRCLE1;
					SC_UDINT IDCIRCLE2;
					SC_UDINT IDPOINTMASS;
					SC_REAL PULLEYMASS;
					SC_UDINT IDMAFORCE;
					SC_REAL CABLEWEIGHT;
					SC_UDINT CRANETYPE;
					SC_UDINT IDREFCOORDSYS;
					SC_UDINT VALIDCBLNOT;
					SC_BOOL INITOK;
					SC_POINTER MODEL;
					SC_UDINT PROZ_TIME_OFFSET;
					SC_REAL ITERATIONS;     // SC_UDINT
				} GEOSETCABLE_TYP;
				
void GEOSETCABLE(GEOSETCABLE_TYP* ip);
*/

/*--- Get structures ------------------------------------------------------------*/

SC_REAL GEOGETDISTANCE(SC_UDINT GEOOBJ1, SC_UDINT GEOOBJ2);

/*! \struct	GEOGETXDISTANCE_TYP
	\brief	SC interface structure for Function Block GeoGetXDistance and C Function GEOGETXDISTANCE()
	\ingroup	SC_interface_get
	\param	GEOOBJ1 pointer to any geometrical object, distance from ...
	\param	GEOOBJ2 pointer to any geometrical object, distance to ...
	\param	DISTANCE absolute distance between the geometrical objects, negative numbers show insideness
	\param	NUMINTERSECTIONS number of intersection points
	\param	INTERSECTPOINT1 pointer to "point" object, 1st intersection point graphical object
	\param	INTERSECTPOINT2 pointer to "point" object, 2nd intersection point graphical object
	\param	DISTANCEVECTOR pointer to "vector" object, direction of distance as a vector
 */
typedef struct {	SC_UDINT GEOOBJ1;
					SC_UDINT GEOOBJ2;
					SC_UDINT INTERSECTPOINT1;
					SC_UDINT INTERSECTPOINT2;
					SC_UDINT DISTANCEVECTOR;
					SC_REAL DISTANCE;
					SC_DINT NUMINTERSECTIONS;
					SC_BOOL PARALLEL;
				} GEOGETXDISTANCE_TYP;
void GEOGETXDISTANCE(GEOGETXDISTANCE_TYP* ip);

/*! \struct	GEOGETPOINT_TYP
	\brief	SC interface structure for Function Block GeoGetPoint and C Function GEOGETPOINT()
	\ingroup	SC_interface_get
 */
typedef struct {	SC_UDINT POINT;
					SC_REAL X;
					SC_REAL Y;
					SC_REAL RADIUS;
					SC_REAL PHI;
					SC_UDINT REFCOORDSYS;
				} GEOGETPOINT_TYP;
void GEOGETPOINT(GEOGETPOINT_TYP* ip);

/*! \struct	GEOGETVECTOR_TYP
	\brief	SC interface structure for Function Block GeoGetVector and C Function GEOGETVECTOR()
	\ingroup	SC_interface_get
 */
typedef struct {	SC_UDINT VECTOR;
					SC_REAL X;
					SC_REAL Y;
					SC_REAL RADIUS;
					SC_REAL PHI;
					SC_UDINT REFCOORDSYS;
				} GEOGETVECTOR_TYP;				
void GEOGETVECTOR(GEOGETVECTOR_TYP* ip);

/*! \struct	GEOGETPOINTXYZ_TYP
	\brief	SC interface structure for Function Block GeoGetPointXYZ and C Function GEOGETPOINTXYZ()
	\ingroup	SC_interface_get
 */
typedef struct {	SC_UDINT POINT;
					SC_REAL X;
					SC_REAL Y;
					SC_REAL Z;
					SC_UDINT REFCOORDSYS;
				} GEOGETPOINTXYZ_TYP;
void GEOGETPOINTXYZ(GEOGETPOINTXYZ_TYP* ip);

/*! \struct	GEOGETVECTORXYZ_TYP
	\brief	SC interface structure for Function Block GeoGetVectorXYZ and C Function GEOGETVECTORXYZ()
	\ingroup	SC_interface_get
 */
typedef struct {	SC_UDINT VECTOR;
					SC_REAL X;
					SC_REAL Y;
					SC_REAL Z;
					SC_UDINT REFCOORDSYS;
				} GEOGETVECTORXYZ_TYP;								
void GEOGETVECTORXYZ(GEOGETVECTORXYZ_TYP* ip);

/*! \struct	GEOGETCIRCLE_TYP
	\brief	SC interface structure for Function Block GeoGetVector and C Function GEOGETCIRCLE()
	\ingroup	SC_interface_get
 */
typedef struct
{
					SC_UDINT CIRCLE;
					SC_UDINT POINT;
					SC_REAL RADIUS;
} GEOGETCIRCLE_TYP;				
void GEOGETCIRCLE(GEOGETCIRCLE_TYP* ip);

/*! \struct	GEOGETPOINTMASS_TYP
	\brief	SC interface structure for Function Block GeoGetPointMass and C Function GEOGETPOINTMASS()
	\ingroup	SC_interface_get
 */
typedef struct {	SC_UDINT POINTMASS;
					SC_UDINT POINT;
					SC_REAL MASS;
				} GEOGETPOINTMASS_TYP;
void GEOGETPOINTMASS(GEOGETPOINTMASS_TYP* ip);

/*! \struct	GEOGETCBLPAR_TYP
	\brief	SC interface structure for Function Block GeoGetCableForce and C Function GEOGETCABLEFORCE()
	\ingroup	SC_interface_get
 */
 /*	
typedef struct {
					SC_UDINT CABLE;
					SC_REAL A;
					SC_REAL X1;
					SC_REAL X2;
					SC_REAL Q;
				} GEOGETCBLPAR_TYP;
void GEOGETCBLPAR(GEOGETCBLPAR_TYP* ip);
*/

/*! \struct	GEOGETCABLEFORCE_TYP
	\brief	SC interface structure for Function Block GeoGetCableForce and C Function GEOGETCABLEFORCE()
	\ingroup	SC_interface_get
 */
 /*
typedef struct
{
		SC_UDINT CABLE;
		SC_UDINT CABLEFORCE1;
		SC_UDINT CABLEFORCE2;
} GEOGETCABLEFORCE_TYP;
void GEOGETCABLEFORCE(GEOGETCABLEFORCE_TYP* ip);
*/
/*! \struct	GEOGETCABLEL_TYP
	\brief	SC interface structure for Function Block GeoGetCableForce and C Function GEOGETCABLEFORCE()
	\ingroup	SC_interface_get
 */
 /*
typedef struct
{
		SC_UDINT CABLE;
		SC_REAL LENGTH;
} GEOGETCABLEL_TYP;
void GEOGETCABLEL(GEOGETCABLEL_TYP* ip);
*/

/*! \struct	GEOGETSPEED_TYP
	\brief	SC interface structure for Function Block GeoGetSpeed
	\ingroup	SC_interface_get
 */	
typedef struct {
					SC_REAL SCALARVALUE;
					SC_UDINT BUFFERLENGTH;			
					SC_REAL SPEED;
					SC_BOOL INITSTEP;
					SC_UDINT BUFFER;
					} GEOGETSPEED_TYP;
void GEOGETSPEED(GEOGETSPEED_TYP* ip);








/*--- robotic functions ----------------------------------------------------*/


/*! \struct	GEOinvJACOBIAN_TYP
	\brief	SC interface structure for Function Block GEOINVJACOBIAN
	\ingroup	SC_interface_get
 */	
typedef struct {
					SC_REAL IDPHI1;
					SC_REAL IDPHI2;
					SC_UDINT IAVELOCITY;
					SC_REAL IDDESIGN1;
					SC_REAL IDDESIGN2;
					SC_REAL QDDPHI1;
					SC_REAL QDDPHI2;
					SC_REAL QDDPHI3;
				} GEOINVJACOBIAN_TYP;
void GEOINVJACOBIAN(GEOINVJACOBIAN_TYP* ip);

/*! \struct	GEOINTERSECTOR_TYP
	\brief	SC interface structure for Function Block GEOI
	\ingroup	SC_interface_get
 */	
typedef struct {
					SC_BOOL IXENABLE;
					SC_REAL IDALPHA0;
					SC_REAL IDALPHA1;
					SC_REAL IDBETA0;
					SC_REAL IDBETA1;
					SC_REAL QDALPHASTAR0;
					SC_REAL QDALPHASTAR1;
					SC_UINT  QWERROR;
				} GEOINTERSECTION_TYP;
void GEOINTERSECTION(GEOINTERSECTION_TYP* ip);


/*! \struct	GEO2ARMROBOT_TYP
	\brief	SC interface structure for Function Block Geo2ArmRobot and C Function GEO2ARMROBOT()
	\ingroup	SC_interface_robot
	\param	GEOOBJBASE graphical object point, base-connection to 1st arm
	\param	GEOOBJELBOW graphical object point, elbow-connection between 1st and 2nd arm
	\param	GEOOBJHEAD graphical object point, head-connection to 2nd arm
	\param	DIRECTION vector to define direction and speed of movement, length between -100 and +100 (percent)
	\param	MAXANGLESPEED1 maximum angle speed on base
	\param	MAXANGLESPEED2 maximum angle speed on elbow
	\param	ANGLESPEED1 maximum angle acceleration on elbow
	\param	ANGLESPEED2 angle speed on elbow
 */
typedef struct {	SC_DINT GEOOBJBASE;
					SC_UDINT GEOOBJELBOW;
					SC_UDINT GEOOBJHEAD;
					SC_UDINT DIRECTION;
					SC_REAL MAXANGLESPEED1;
					SC_REAL MAXANGLESPEED2;
					SC_REAL ANGLESPEED1;
					SC_REAL ANGLESPEED2;
				} GEO2ARMROBOT_TYP;
void GEO2ARMROBOT(GEO2ARMROBOT_TYP* ip);

/*! \struct	GEOLIMITACCEL_TYP
	\brief	SC interface structure to reduce angle speed by maximum angle acceleration
	\ingroup	SC_interface_robot
	\param	ANGLESPEED1 current angle speed on pivot 1
	\param	ANGLESPEED2 current angle speed on pivot 2
	\param	MAXANGLESPEED1 maximum angle speed on pivot 1
	\param	MAXANGLESPEED2 maximum angle speed on pivot 2
	\param	MAXRISETIME1 integration time [s] from 0% to 100% angle speed, on pivot 1
	\param	MAXRISETIME2 integration time [s] from 0% to 100% angle speed, on pivot 2
	\param	LIMITANGLESPEED1 limited angle speed on pivot 1
	\param	LIMITANGLESPEED2 limited angle speed on pivot 2
	\param	ANGLEACCEL1 angle acceleration on pivot 1
	\param	ANGLEACCEL2 angle acceleration on pivot 2
	\param	REDUCTION1 reduction factor on pivot 1
	\param	REDUCTION2 reduction factor on pivot 2
	\param	PREVIOUSTIME time [ms] on last run
	\param	PREVIOUSSPEED1 angle speed of pivot 1 on previous run
	\param	PREVIOUSSPEED2 angle speed of pivot 1 on previous run
 */
typedef struct {	SC_REAL ANGLESPEED1;
					SC_REAL ANGLESPEED2;
					SC_REAL MAXANGLESPEED1;
					SC_REAL MAXANGLESPEED2;
					SC_REAL MAXRISETIME1;
					SC_REAL MAXRISETIME2;
					SC_REAL LIMITANGLESPEED1;
					SC_REAL LIMITANGLESPEED2;
					SC_REAL ANGLEACCEL1;
					SC_REAL ANGLEACCEL2;
					SC_REAL REDUCTION1;
					SC_REAL REDUCTION2;
					SC_TIME	PREVIOUSTIME;
					SC_REAL	PREVIOUSSPEED1;
					SC_REAL	PREVIOUSSPEED2;
				} GEOLIMITACCEL_TYP;
void GEOLIMITACCEL(GEOLIMITACCEL_TYP* ip);

/*! \struct	GEOBRAKEMAX_TYP
	\brief	SC interface structure to check future angle speed if we brake at maximum
	\ingroup	SC_interface_robot
	\param	ANGLESPEED1 current angle speed on pivot 1
	\param	ANGLESPEED2 current angle speed on pivot 2
	\param	MAXANGLESPEED1 maximum angle speed on pivot 1
	\param	MAXANGLESPEED2 maximum angle speed on pivot 2
	\param	MAXRISETIME1 integration time [s] from 0% to 100% angle speed, on pivot 1
	\param	MAXRISETIME2 integration time [s] from 0% to 100% angle speed, on pivot 2
	\param	TIMESTEP brake duration time in [ms]
	\param	NEXTANGLESPEED1 limited angle speed on pivot 1
	\param	NEXTANGLESPEED2 limited angle speed on pivot 2
	\param	ANGLEACCEL1 angle acceleration on pivot 1
	\param	ANGLEACCEL2 angle acceleration on pivot 2
	\param	REDUCTION1 reduction factor on pivot 1
	\param	REDUCTION2 reduction factor on pivot 2
 */
typedef struct {	SC_REAL ANGLESPEED1;
					SC_REAL ANGLESPEED2;
					SC_REAL MAXANGLESPEED1;
					SC_REAL MAXANGLESPEED2;
					SC_REAL MAXRISETIME1;
					SC_REAL MAXRISETIME2;
					SC_TIME	TIMESTEP;
					SC_REAL NEXTANGLESPEED1;
					SC_REAL NEXTANGLESPEED2;
					SC_REAL ANGLEACCEL1;
					SC_REAL ANGLEACCEL2;
					SC_REAL REDUCTION1;
					SC_REAL REDUCTION2;
					SC_TIME	PREVIOUSTIME;
					SC_REAL	PREVIOUSSPEED1;
					SC_REAL	PREVIOUSSPEED2;
				} GEOBRAKEMAX_TYP;
void GEOBRAKEMAX(GEOBRAKEMAX_TYP* ip);

/*! \struct	GEOSPEEDONARM2_TYP
	\brief	SC interface structure for Function Block GeoSpeedOnArm2 and C Function GEOSPEEDONARM2()
	\ingroup	SC_interface_robot
	\param	GEOOBJBASE graphical object point, base-connection to 1st arm
	\param	GEOOBJELBOW graphical object point, elbow-connection between 1st and 2nd arm
	\param	GEOOBJHEAD graphical object point, head-connection to 2nd arm
	\param	DIRECTIONHEAD vector to define direction and speed of movement, length between -100 and +100 (percent)
	\param	DIRECTIONARM vector to define direction and speed of movement, length between -100 and +100 (percent)
 */
typedef struct {	SC_DINT GEOOBJBASE;
					SC_UDINT GEOOBJELBOW;
					SC_UDINT GEOOBJHEAD;
					SC_UDINT GEOOBJONARM2;
					SC_UDINT DIRECTIONHEAD;
					SC_UDINT DIRECTIONONARM2;
					SC_UDINT REFCOORDSYS;
				} GEOSPEEDONARM2_TYP;
void GEOSPEEDONARM2(GEOSPEEDONARM2_TYP* ip);

/*--- additional utility functions -----------------------------------------*/
SC_BOOL GEOCOPYOBJECT(SC_UDINT GEOOBJSOURCE, SC_UDINT GEOOBJTARGET);

/*! \struct	GEOANGLESPEED_TYP
	\brief	SC interface structure for Function Block GeoAngleSpeed and C Function GEOANGLESPEED()
	\ingroup	SC_interface_utility
	\param	ANGLE from sensor
	\param	BUFSIZE number of elements used for averaging, from 1 to 10
	\param	DELTAOMEGAMAX maximum allowed difference between 2 elements, as Angle per second. If difference is above maximum, this difference value is ignored
	\param	OMEGA smoothed angle speed [�/s]
	\param	A1 Angle signal delayed by 1 run
	\param	A2 Angle signal delayed by 2 runs
	\param	A3 Angle signal delayed by 3 runs
	\param	A4 Angle signal delayed by 4 runs
	\param	A5 Angle signal delayed by 5 runs
	\param	A6 Angle signal delayed by 6 runs
	\param	A7 Angle signal delayed by 7 runs
	\param	A8 Angle signal delayed by 8 runs
	\param	A9 Angle signal delayed by 9 runs
	\param	A10 Angle signal delayed by 10 runs
	\param	OLDTIME	time on last run
 */
typedef struct {
					SC_REAL  ANGLE;
					SC_UINT  BUFSIZE;
					SC_REAL	DELTAOMEGAMAX;
					SC_REAL	OMEGA;
					SC_REAL	A1;
					SC_REAL	A2;
					SC_REAL	A3;
					SC_REAL	A4;
					SC_REAL	A5;
					SC_REAL	A6;
					SC_REAL	A7;
					SC_REAL	A8;
					SC_REAL	A9;
					SC_REAL	A10;
					SC_TIME OLDTIME;
} GEOANGLESPEED_TYP;
				
void GEOANGLESPEED(GEOANGLESPEED_TYP* ip);


/*--- eof ------------------------------------------------------------------*/
#endif
