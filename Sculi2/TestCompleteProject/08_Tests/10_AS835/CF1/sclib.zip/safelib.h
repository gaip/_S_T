/****************************************************************************/
/*                                                                          */
/*                     Copyright 2006, Liebherr PME1                        */
/*                         ALL RIGHTS RESERVED                              */
/*                                                                          */
/****************************************************************************/
/*!	\file	safelib.h
	\brief	header for safety library
	\ingroup safelib
 
	$Author: $
	$Revision: $
	$Date: $

	$Log: $
*/

/*
~~
~~  For compatibility with SoftControl C code generator names of public
~~  manufacturer library functions are completely written in uppercase.
~~
*/

#if !defined(__SAFELIB_H)
#define __SAFELIB_H

/*--------------------------------------------------------------------------*/
/* included files                                                           */
/*--------------------------------------------------------------------------*/
#include "li_types.h"
#include "sc_datatyps.h"

/*--------------------------------------------------------------------------*/
/* general definitions                                                      */
/*--------------------------------------------------------------------------*/

/*--- Library Version String -----------------------------------------------*/
#ifdef RELEASE
 #if RELEASE==1
  #define SAFELIB_VERSION_STRING	"1.300"
 #else
  #define SAFELIB_VERSION_STRING	"1.999"
 #endif
#else
 #define SAFELIB_VERSION_STRING	"1.999"
#endif

/*--------------------------------------------------------------------------*/
/* structure/type definitions                                               */
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/* global variables                                                         */
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/* function prototypes                                                      */
/*--------------------------------------------------------------------------*/
void safelib_init(void);

SC_UDINT SAFETYCHECK(SC_UDINT INPUTVECTOR);

#endif	//#if !defined(__SAFELIB_H)
