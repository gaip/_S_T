/****************************************************************************/
/*                                                                          */
/*                     Copyright 2004, Liebherr PME1                        */
/*                         ALL RIGHTS RESERVED                              */
/*                                                                          */
/****************************************************************************/
/*!	\file	lwnlib.h
	\brief	LWN manufacturer library header
	\ingroup lwnlib
*/

/*
~~
~~  For compatibility with SoftControl C code generator names of public
~~  manufacturer library functions are completely written in uppercase.
~~
*/


#if !defined(__LWNLIB_H)
#define __LWNLIB_H

/*--------------------------------------------------------------------------*/
/* included files                                                           */
/*--------------------------------------------------------------------------*/
#include "li_types.h"
#include "sc_datatyps.h"
#include "database.h"

/*--------------------------------------------------------------------------*/
/* general definitions                                                      */
/*--------------------------------------------------------------------------*/
#ifdef OS_WIN32
	#ifdef IN
		#undef IN
	#endif
	#ifdef OUT
		#undef OUT
	#endif
#endif

/*--- Library Version String -----------------------------------------------*/
#if 0
	#define LWNLIB_VERSION_STRING	"4.311"		/*!< needed fake for LiSM */
#endif
#ifndef LWNLIB_VERSION_STRING
	#define LWNLIB_VERSION_STRING	4.999		/*!< default version number (is automatically quoted inside function lwnlib_init() ) */
#endif
#define QUOTEME_(x) #x
#define QUOTEME(x) QUOTEME_(x)

/*--------------------------------------------------------------------------*/
/* structure/type definitions                                               */
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/* global variables                                                         */
/*--------------------------------------------------------------------------*/

/* message priorities */
extern SC_UINT SC_MSG_UNAWARE;
extern SC_UINT SC_MSG_DEBUG;
extern SC_UINT SC_MSG_INFO;
extern SC_UINT SC_MSG_NOTICE;
extern SC_UINT SC_MSG_WARNING;
extern SC_UINT SC_MSG_ERROR;
extern SC_UINT SC_MSG_SYSTEM;
extern SC_UINT SC_MSG_CRITICAL;

/* message groups  */
extern SC_UDINT SC_MSG_UNDEF;
extern SC_UDINT SC_MSG_OS;
extern SC_UDINT SC_MSG_DRV;
extern SC_UDINT SC_MSG_INN;
extern SC_UDINT SC_MSG_OUT;
extern SC_UDINT SC_MSG_SCR;
extern SC_UDINT SC_MSG_LIB;
extern SC_UDINT SC_MSG_CAN;
extern SC_UDINT SC_MSG_APP;
extern SC_UDINT SC_MSG_LID;
extern SC_UDINT SC_MSG_REM;   //only for the reasons of compatibility, as some application did define this, but nobody really used it
extern SC_UDINT SC_MSG_USER;

/* message subgroups for group "applicat" */
extern SC_UDINT SC_MSG_APP_UNDEF;
extern SC_UDINT SC_MSG_APP_SENSOR;
extern SC_UDINT SC_MSG_APP_ACTOR;
extern SC_UDINT SC_MSG_APP_SAFETY;
extern SC_UDINT SC_MSG_APP_DRIVE;
extern SC_UDINT SC_MSG_APP_MACHINE;
extern SC_UDINT SC_MSG_APP_ENGINE;
extern SC_UDINT SC_MSG_APP_SERVICE;

/* message subgroups for group "user" */
extern SC_UDINT SC_MSG_USER_UNDEF;
extern SC_UDINT SC_MSG_USER_LHM;
extern SC_UDINT SC_MSG_USER_HS;
extern SC_UDINT SC_MSG_USER_MARITIM;
extern SC_UDINT SC_MSG_USER_LRS;

/* message subgroups for group "undefined" */
extern SC_UDINT SC_MSG_UNDEF_UNDEF;

/* data recorder */
extern SC_UINT SC_REC_DATA_MEAN;
extern SC_UINT SC_REC_DATA_VAR;
extern SC_UINT SC_REC_DATA_MIN;
extern SC_UINT SC_REC_DATA_MAX;

/* lidat */
extern SC_UDINT SC_MSG_LID_UNDEF;
extern SC_UDINT SC_MSG_LID_VALUE;
extern SC_UDINT SC_MSG_LID_SUM;
extern SC_UDINT SC_MSG_LID_EVENT;
extern SC_UDINT SC_MSG_LID_COMM;

extern float SC_PI;

/*--------------------------------------------------------------------------*/
/* function prototypes                                                      */
/*--------------------------------------------------------------------------*/

void lwnlib_init(void);

/*--- FB Integrator --------------------------------------------------------*/
typedef struct { 
                   SC_BOOL ENABLE;
                   SC_REAL IN;
                   SC_REAL UP;
                   SC_REAL DN;
                   SC_REAL OUT;
                   SC_TIME OLDTIME;
                   SC_TIME ACTTIME;
                   SC_BOOL INITOK;
                   SC_BOOL ACCELERATE;
                   SC_REAL DY;    
                   SC_REAL VAL1;
                   SC_REAL VAL2; 
                                          } INTEGRATOR_TYP;


void INTEGRATOR (INTEGRATOR_TYP *);

/*--- FB IntegratorLimit -------------------------------------------------*/

typedef struct { 
                   SC_BOOL ENABLE;
                   SC_REAL IN;
                   SC_REAL UP;
                   SC_REAL DN;
         SC_BOOL ENLIMIT;
         SC_REAL HILIMIT;
         SC_REAL LOLIMIT; 
                   SC_REAL OUT;
                   SC_TIME OLDTIME;
                   SC_TIME ACTTIME;
                   SC_BOOL INITOK;
                   SC_BOOL ACCELERATE;
                   SC_REAL DY;    
                   SC_REAL VAL1;
                   SC_REAL VAL2; 
                                          } INTEGRATORLIMIT_TYP;


void INTEGRATORLIMIT (INTEGRATORLIMIT_TYP *);


/*--- FB PowerStage ------------------------------------------------------*/

typedef struct {
                   SC_BOOL ENABLE;
                   SC_REAL IN;
                   SC_REAL MININ;
                   SC_REAL MAXIN;
                   SC_UINT MINOUT;
                   SC_UINT MAXOUT;
                   SC_UINT OUT;
                   SC_BOOL OUTOFRANGE;
                                          } POWERSTAGE_TYP;

void POWERSTAGE (POWERSTAGE_TYP *);


/*--- FB WndComp ---------------------------------------------------------*/

typedef struct {
                   SC_REAL IN;
                   SC_REAL LOLIM;
                   SC_REAL HILIM;
                   SC_REAL HYST;
                   SC_BOOL WND;
                   SC_BOOL LO;
                   SC_BOOL HI;
                                          } WNDCOMP_TYP;

void WNDCOMP (WNDCOMP_TYP *);



/*--- FB ScaleAI ---------------------------------------------------------*/

typedef struct {
                   SC_UINT IN;
                   SC_REAL SCALE;
                   SC_REAL OUT;
                   SC_BOOL SHORT;
                   SC_BOOL BREAK;
                                          } SCALEAI_TYP;

void SCALEAI (SCALEAI_TYP *);


/*--- FB ScaleAIEXT ---------------------------------------------------------*/

typedef struct {
                   SC_UINT IN;
                   SC_REAL SCALE;
                   SC_REAL OUT;
                   SC_BOOL SHORT;
                   SC_BOOL BREAK;
				   SC_BOOL WARN_LOW;
                                          } SCALEAIEXT_TYP;

void SCALEAIEXT (SCALEAIEXT_TYP *);

/*--- FB ScaleAIfail ---------------------------------------------------------*/

typedef struct {
					SC_UINT IWIN;
					SC_REAL IDSCALE;
					SC_TIME IDSAFETIME;
					SC_REAL QDOUT;
					SC_BOOL QXSHORT;
					SC_BOOL QXBREAK;
					SC_BOOL QXWARN_LOW;
					SC_BOOL QXFAILURE;
					SC_BOOL INTERN_FLAG_AREA_WARN_LOW;
					SC_BOOL INTERN_FLAG_AREA_FAILURE;
					SC_TIME INTERN_T_START_AREA_WARN_LOW;
					SC_TIME INTERN_T_START_AREA_FAILURE;
										} SCALEAIFAIL_TYP;

void SCALEAIFAIL (SCALEAIFAIL_TYP *);

/*--- FB ScaleAIJump -----------------------------------------------------*/

typedef struct {
                   SC_UINT IN;
                   SC_REAL SCALE;
                   SC_REAL RATEMAX;
                   SC_REAL OUT;
                   SC_BOOL SHORT;
                   SC_BOOL BREAK;
                   SC_BOOL JUMP;
                   SC_REAL RATE;

                   SC_TIME OLDTIME;
                   SC_REAL OUT_N_0; 
                   SC_REAL OUT_N_1; 
				   SC_REAL MaxOutDiff;
                   SC_BOOL JUMPPOS;
                   SC_BOOL JUMPNEG;
                                          } SCALEAIJUMP_TYP;

void SCALEAIJUMP (SCALEAIJUMP_TYP *);


/*--- FB TabGetY ---------------------------------------------------------*/
/* in VxWorks ERROR is a preprocessor definition for return codes */
#ifdef ERROR
#undef ERROR
#endif

typedef struct {
                   SC_UINT CODE;
                   SC_REAL X;
                   SC_REAL YDEFAULT;
                   SC_REAL Y;
                   SC_UINT  ERROR;
                                          } TABGETY_TYP;

void TABGETY (TABGETY_TYP *);

/*--- FB TabGetCode ------------------------------------------------------*/
/*! \struct	TABGETCODE_TYP
	\brief	get table code to be used in TabGetY
	\param	PARAMETER0	meaning of output table in the Excel Worksheet
 */
typedef struct {
				SC_USINT PARAMETER7;
				SC_USINT PARAMETER6;
				SC_USINT PARAMETER5;
				SC_USINT PARAMETER4;
				SC_USINT PARAMETER3;
				SC_USINT PARAMETER2;
				SC_USINT PARAMETER1;
				SC_USINT PARAMETER0;
				SC_UINT CODE;
				SC_BOOL ERROR;
				SC_REAL MINVALUEINPUT;
				SC_REAL MAXVALUEINPUT;
				SC_REAL MINVALUEOUTPUT;
				SC_REAL MAXVALUEOUTPUT;
				SC_BOOL	INITOK;
				SC_USINT PARAMETER7OLD;
				SC_USINT PARAMETER6OLD;
				SC_USINT PARAMETER5OLD;
				SC_USINT PARAMETER4OLD;
				SC_USINT PARAMETER3OLD;
				SC_USINT PARAMETER2OLD;
				SC_USINT PARAMETER1OLD;
				SC_USINT PARAMETER0OLD;
				SC_UINT CODEBACKUP;
				SC_BOOL ERRORBACKUP;
				SC_REAL MININPUTBACKUP;
				SC_REAL MAXINPUTBACKUP;
				SC_REAL MINOUTPUTBACKUP;
				SC_REAL MAXOUTPUTBACKUP;
				} TABGETCODE_TYP;

void TABGETCODE(TABGETCODE_TYP *);

/*--- FB SampleNHold ----------------------------------------------------*/

typedef struct {
                   SC_BOOL SAMPLE;
                   SC_REAL IN;
                   SC_REAL OUT;
                                          } SAMPLENHOLD_TYP;

void SAMPLENHOLD (SAMPLENHOLD_TYP *);


/*--- FB Limitation -----------------------------------------------------*/

typedef struct {
                   SC_REAL IN;
                   SC_REAL ACTUAL;
                   SC_REAL ADJUSTPOS;
                   SC_REAL ADJUSTNEG;
                   SC_REAL OUT;
                   SC_REAL LRADJUSTPOS;
                   SC_REAL LRADJUSTNEG;
                                          } LIMITATION_TYP;

void LIMITATION (LIMITATION_TYP *);



/*--- FB Count2Freq ----------------------------------------------------*/

typedef struct {
                   SC_DINT COUNT;
                   SC_TIME GATE;
                   SC_REAL FREQ;
                   SC_TIME OLDTIME;
                   SC_DINT OLDCOUNT;
                   SC_BOOL INITOK; 
                                          } COUNT2FREQ_TYP;

void COUNT2FREQ (COUNT2FREQ_TYP *);

/*--- FB Count2FreqFilt -----------------------------------------------*/

#define MAX_C2F_BUF  20

typedef struct {
                   SC_DINT COUNT;
                   SC_TIME GATE;
                   SC_REAL FREQ;
                   SC_TIME OLDTIME;
                   SC_DINT OLDCOUNT;
                   SC_BOOL INITOK; 
                   SC_TIME ACTTIME;
                   SC_TIME DIFFTIME;
                   SC_DINT DIFFCOUNT;
                   SC_BOOL COUNTBAD;
                   SC_DINT DCOUNT[MAX_C2F_BUF+1];
                   SC_TIME DTIME[MAX_C2F_BUF+1];
                   SC_INT  INDEX;
                   SC_INT  INDEX1;
                   SC_DINT DCNT;
                   SC_TIME DT;} COUNT2FREQFILT_TYP;

void COUNT2FREQFILT (COUNT2FREQFILT_TYP *);


/*--- FB CountSave ----------------------------------------------------*/

typedef struct {
                   SC_DINT CNTIN;
                   SC_BOOL SET;
                   SC_DINT SETVAL;
                   SC_DINT *CNTSAVE;
                   SC_DINT CNTSAVEOUT;
                   SC_BOOL INITOK;
                   SC_DINT OFFSET; 
                                          } COUNTSAVE_TYP;

void COUNTSAVE (COUNTSAVE_TYP *);

/*--- FB Word2BitMask -------------------------------------------------*/

typedef struct {
                   SC_WORD A_WORD;
                   SC_BOOL BIT0;
                   SC_BOOL BIT1;
                   SC_BOOL BIT2;
                   SC_BOOL BIT3;
                   SC_BOOL BIT4;
                   SC_BOOL BIT5;
                   SC_BOOL BIT6;
                   SC_BOOL BIT7;
                   SC_BOOL BIT8;
                   SC_BOOL BIT9;
                   SC_BOOL BIT10;
                   SC_BOOL BIT11;
                   SC_BOOL BIT12;
                   SC_BOOL BIT13;
                   SC_BOOL BIT14;
                   SC_BOOL BIT15;
                                          } WORD2BITMASK_TYP;

void WORD2BITMASK (WORD2BITMASK_TYP *);



/*--- FUN BitMask2Word --------------------------------------------------*/

SC_WORD BITMASK2WORD(SC_BOOL BIT0 ,SC_BOOL BIT1 ,SC_BOOL BIT2 ,SC_BOOL BIT3,
                     SC_BOOL BIT4 ,SC_BOOL BIT5 ,SC_BOOL BIT6 ,SC_BOOL BIT7,
                     SC_BOOL BIT8 ,SC_BOOL BIT9 ,SC_BOOL BIT10,SC_BOOL BIT11,
                     SC_BOOL BIT12,SC_BOOL BIT13,SC_BOOL BIT14,SC_BOOL BIT15);

/*--- FUN SigMax4 -------------------------------------------------------*/

SC_SINT  SIGMAX4_SINT  (SC_SINT P1, SC_SINT P2, SC_SINT P3, SC_SINT P4);
SC_INT   SIGMAX4_INT   (SC_INT P1, SC_INT P2, SC_INT P3, SC_INT P4);
SC_DINT  SIGMAX4_DINT  (SC_DINT P1, SC_DINT P2, SC_DINT P3, SC_DINT P4);
SC_REAL  SIGMAX4_REAL  (SC_REAL P1, SC_REAL P2, SC_REAL P3, SC_REAL P4);
 

/*--- FUN SigMin4 -------------------------------------------------------*/

SC_SINT  SIGMIN4_SINT  (SC_SINT P1, SC_SINT P2, SC_SINT P3, SC_SINT P4);
SC_INT   SIGMIN4_INT   (SC_INT P1, SC_INT P2, SC_INT P3, SC_INT P4);
SC_DINT  SIGMIN4_DINT  (SC_DINT P1, SC_DINT P2, SC_DINT P3, SC_DINT P4);
SC_REAL  SIGMIN4_REAL  (SC_REAL P1, SC_REAL P2, SC_REAL P3, SC_REAL P4);
 
/*--- FUN VisValueState -------------------------------------------------*/

SC_BYTE VISVALUESTATE ( SC_BOOL Activ, SC_BOOL Blinking, SC_BOOL Invalid );

/*--- FUN VisObjectState ------------------------------------------------*/

SC_BYTE VISOBJECTSTATE ( SC_BOOL Activ, SC_BOOL Blinking, SC_BOOL Symbol );

/*--- FUN VisObjectState1 ------------------------------------------------*/

SC_BYTE VISOBJECTSTATE1 ( SC_BOOL Activ, SC_BOOL Blinking, SC_UINT SymbolNr );


/*--- FUN READ TIME --------------------------------------------------------*/

SC_TIME  READ_REAL_MS  (void);
SC_TIME  READ_PROZ_MS  (void);


/*--- FB CorrValue_Bool ----------------------------------------------------*/
typedef struct {
                   SC_BOOL *C_VAL;
                   SC_BOOL BASE; 
                   SC_BOOL MIN;
                   SC_BOOL MAX;
                                          } CORRVALUE_BOOL_TYP;

void CORRVALUE_BOOL (CORRVALUE_BOOL_TYP *);

/*--- FB CorrValue_SInt ----------------------------------------------------*/
typedef struct {
                   SC_SINT *C_VAL;
                   SC_SINT BASE; 
                   SC_SINT MIN;
                   SC_SINT MAX;
                                          } CORRVALUE_SINT_TYP;

void CORRVALUE_SINT (CORRVALUE_SINT_TYP *);

/*--- FB CorrValue_USInt ----------------------------------------------------*/
typedef struct {
                   SC_USINT *C_VAL;
                   SC_USINT BASE; 
                   SC_USINT MIN;
                   SC_USINT MAX;
                                          } CORRVALUE_USINT_TYP;

void CORRVALUE_USINT (CORRVALUE_USINT_TYP *);

/*--- FB CorrValue_Byte ----------------------------------------------------*/
typedef struct {
                   SC_BYTE *C_VAL;
                   SC_BYTE BASE; 
                   SC_BYTE MIN;
                   SC_BYTE MAX;
                                          } CORRVALUE_BYTE_TYP;

void CORRVALUE_BYTE (CORRVALUE_BYTE_TYP *);

/*--- FB CorrValue_Int ----------------------------------------------------*/
typedef struct {
                   SC_INT *C_VAL;
                   SC_INT BASE; 
                   SC_INT MIN;
                   SC_INT MAX;
                                          } CORRVALUE_INT_TYP;

void CORRVALUE_INT (CORRVALUE_INT_TYP *);

/*--- FB CorrValue_UInt ----------------------------------------------------*/
typedef struct {
                   SC_UINT *C_VAL;
                   SC_UINT BASE; 
                   SC_UINT MIN;
                   SC_UINT MAX;
                                          } CORRVALUE_UINT_TYP;

void CORRVALUE_UINT (CORRVALUE_UINT_TYP *);

/*--- FB CorrValue_Word ----------------------------------------------------*/
typedef struct {
                   SC_WORD *C_VAL;
                   SC_WORD BASE; 
                   SC_WORD MIN;
                   SC_WORD MAX;
                                          } CORRVALUE_WORD_TYP;

void CORRVALUE_WORD (CORRVALUE_WORD_TYP *);

/*--- FB CorrValue_DInt ----------------------------------------------------*/
typedef struct {
                   SC_DINT *C_VAL;
                   SC_DINT BASE; 
                   SC_DINT MIN;
                   SC_DINT MAX;
                                          } CORRVALUE_DINT_TYP;

void CORRVALUE_DINT (CORRVALUE_DINT_TYP *);

/*--- FB CorrValue_UDInt ----------------------------------------------------*/
typedef struct {
                   SC_UDINT *C_VAL;
                   SC_UDINT BASE; 
                   SC_UDINT MIN;
                   SC_UDINT MAX;
                                          } CORRVALUE_UDINT_TYP;

void CORRVALUE_UDINT (CORRVALUE_UDINT_TYP *);

/*--- FB CorrValue_DWord ----------------------------------------------------*/
typedef struct {
                   SC_DWORD *C_VAL;
                   SC_DWORD BASE; 
                   SC_DWORD MIN;
                   SC_DWORD MAX;
                                          } CORRVALUE_DWORD_TYP;

void CORRVALUE_DWORD (CORRVALUE_DWORD_TYP *);

/*--- FB CorrValue_Real ----------------------------------------------------*/
typedef struct {
                   SC_REAL *C_VAL;
                   SC_REAL BASE; 
                   SC_REAL MIN;
                   SC_REAL MAX;
                                          } CORRVALUE_REAL_TYP;

void CORRVALUE_REAL (CORRVALUE_REAL_TYP *);

/*--- FB CorrValue_Time ----------------------------------------------------*/
typedef struct {
                   SC_TIME *C_VAL;
                   SC_TIME BASE; 
                   SC_TIME MIN;
                   SC_TIME MAX;
                                          } CORRVALUE_TIME_TYP;

void CORRVALUE_TIME (CORRVALUE_TIME_TYP *);

/*--- FB CorrValue_Date ----------------------------------------------------*/
typedef struct {
                   SC_DATE *C_VAL;
                   SC_DATE BASE; 
                   SC_DATE MIN;
                   SC_DATE MAX;
                                          } CORRVALUE_DATE_TYP;

void CORRVALUE_DATE (CORRVALUE_DATE_TYP *);

/*--- FB CorrValue_TOD ----------------------------------------------------*/
typedef struct {
                   SC_TOD *C_VAL;
                   SC_TOD BASE; 
                   SC_TOD MIN;
                   SC_TOD MAX;
                                          } CORRVALUE_TOD_TYP;

void CORRVALUE_TOD (CORRVALUE_TOD_TYP *);

/*--- FB CorrValue_DT ----------------------------------------------------*/
typedef struct {
                   SC_DT *C_VAL;
                   SC_DT BASE; 
                   SC_DT MIN;
                   SC_DT MAX;
                                          } CORRVALUE_DT_TYP;

void CORRVALUE_DT (CORRVALUE_DT_TYP *);


/*--- FB Data Logger State -------------------------------------------------*/
typedef struct {
                                SC_BOOL READY;
                                SC_DINT SIZE;
                                SC_DINT FREE;
                                SC_UINT ERROR;
                                } RECSTATE_TYP;
                                
void RECSTATE (RECSTATE_TYP *);

/*--- FB Data Logger State ID ----------------------------------------------*/
typedef struct {
			                    SC_UINT TRIGGERID;
                                SC_BOOL READY;
                                SC_DINT SIZE;
                                SC_DINT FREE;
                                SC_UDINT ERROR;
                                } RECSTATEID_TYP;
                                
void RECSTATEID (RECSTATEID_TYP *);

/*--- FB Printer State -----------------------------------------------------*/
typedef struct {
                                SC_BOOL READY;
                                SC_UINT ERROR;
                                SC_BOOL PRINTING;
                                SC_BOOL INTERRUPT;
                                } RECPRINTSTATE_TYP;
                                
void RECPRINTSTATE (RECPRINTSTATE_TYP *);

/*--- FB Data Logger Size ID ----------------------------------------------*/
typedef struct {
			                    SC_UINT TRIGGERID;
                                SC_BOOL VALID_SIZE;
                                SC_DINT SIZE;
                                } RECSIZEID_TYP;
                                
void RECSIZEID (RECSIZEID_TYP *);

/*--- FB Trigger datalogger ------------------------------------------------*/
typedef struct {
                   SC_UINT TRIGGERID;
                   SC_BOOL FIRE;
                                          } RECFIRE_TYP;

void RECFIRE (RECFIRE_TYP *);

/*--- FB Trigger already fired ---------------------------------------------*/
typedef struct {
                   SC_UINT TRIGGERID;
                   SC_BOOL FIRED;
                                          } RECFIRED_TYP;
void RECFIRED(RECFIRED_TYP* ip);

/*--- FB define trigger ----------------------------------------------------*/
typedef struct {
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECDEFINETRIGGER_TYP;

void RECDEFINETRIGGER(RECDEFINETRIGGER_TYP *);

/*--- FB define trigger ----------------------------------------------------*/
typedef struct {
                   SC_STRINGDEF(20) NAME;
                   SC_STRINGDEF(20) PATH;
                   SC_UINT TRIGGERID;
                                          } RECDEFTRIGGER_TYP;

void RECDEFTRIGGER(RECDEFTRIGGER_TYP *);


/*--- FB Add Recorder Data BOOL --------------------------------------------*/
typedef struct {
                   SC_BOOL* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECDATA_BOOL_TYP;

void RECDATA_BOOL (RECDATA_BOOL_TYP *);

/*--- FB Add Recorder Data Report BOOL --------------------------------------------*/
typedef struct {
                   SC_BOOL* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                   SC_UINT COMPUTING;
                                          } RECDATA_BOOL_COM_TYP;

void RECDATA_BOOL_COM (RECDATA_BOOL_COM_TYP *);

/*--- FB Add Recorder Data UInt --------------------------------------------*/
typedef struct {
                   SC_UINT* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECDATA_UINT_TYP;

void RECDATA_UINT (RECDATA_UINT_TYP *);

/*--- FB Add Recorder Data UInt --------------------------------------------*/
typedef struct {
                   SC_UINT* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                   SC_UINT COMPUTING;
                                          } RECDATA_UINT_COM_TYP;

void RECDATA_UINT_COM (RECDATA_UINT_COM_TYP *);

/*--- FB Add Recorder Data Int --------------------------------------------*/
typedef struct {
                   SC_INT* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECDATA_INT_TYP;

void RECDATA_INT (RECDATA_INT_TYP *);

/*--- FB Add Recorder Data Int --------------------------------------------*/
typedef struct {
                   SC_INT* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                   SC_UINT COMPUTING;
                                          } RECDATA_INT_COM_TYP;

void RECDATA_INT_COM (RECDATA_INT_COM_TYP *);

/*--- FB Add Recorder Data DInt --------------------------------------------*/
typedef struct {
                   SC_DINT* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECDATA_DINT_TYP;

void RECDATA_DINT (RECDATA_DINT_TYP *);

/*--- FB Add Recorder Data DInt --------------------------------------------*/
typedef struct {
                   SC_DINT* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                   SC_UINT COMPUTING;
                                          } RECDATA_DINT_COM_TYP;

void RECDATA_DINT_COM (RECDATA_DINT_COM_TYP *);

/*--- FB Add Recorder Data Real --------------------------------------------*/
typedef struct {
                   SC_REAL* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                   SC_UINT PRECISION;
                                          } RECDATA_REAL_TYP;

void RECDATA_REAL (RECDATA_REAL_TYP *);

/*--- FB Add Recorder Data Real Computed -----------------------------------*/
typedef struct {
                   SC_REAL* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                   SC_UINT PRECISION;
                   SC_UINT COMPUTING;
                   
                                          } RECDATA_REAL_COM_TYP;

void RECDATA_REAL_COM (RECDATA_REAL_COM_TYP *);

/*--- FB Add Recorder Data Date --------------------------------------------*/
typedef struct {
                   SC_DT* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECDATA_DATE_TYP;

void RECDATA_DATE (RECDATA_DATE_TYP *);

/*--- FB Add Recorder Data Tod ---------------------------------------------*/
typedef struct {
                   SC_DT* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECDATA_TOD_TYP;

void RECDATA_TOD (RECDATA_TOD_TYP *);

/*--- FB Add Recorder Data String ------------------------------------------*/
typedef struct {
                   SC_STRING* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECDATA_STRING_TYP;

void RECDATA_STRING (RECDATA_STRING_TYP *);

/*--- FB Add Recorder Header Bool ------------------------------------------*/
typedef struct {
                   SC_BOOL* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECHEADER_BOOL_TYP;

void RECHEADER_BOOL (RECHEADER_BOOL_TYP *);

/*--- FB Add Recorder Header UInt ------------------------------------------*/
typedef struct {
                   SC_UINT* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECHEADER_UINT_TYP;

void RECHEADER_UINT (RECHEADER_UINT_TYP *);

/*--- FB Add Recorder Header Real ------------------------------------------*/
typedef struct {
                   SC_REAL* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                   SC_UINT PRECISION;
                                          } RECHEADER_REAL_TYP;

void RECHEADER_REAL (RECHEADER_REAL_TYP *);

/*--- FB Add Recorder Header Date ------------------------------------------*/
typedef struct {
                   SC_DT* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECHEADER_DATE_TYP;

void RECHEADER_DATE (RECHEADER_DATE_TYP *);

/*--- FB Add Recorder Header TOD -------------------------------------------*/
typedef struct {
                   SC_DT* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECHEADER_TOD_TYP;

void RECHEADER_TOD (RECHEADER_TOD_TYP *);

/*--- FB Add Recorder Header String ----------------------------------------*/
typedef struct {
                   SC_STRING* DATA;
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECHEADER_STRING_TYP;

void RECHEADER_STRING (RECHEADER_STRING_TYP *);

/*--- FB Start/Stop Data Cycle ---------------------------------------------*/
typedef struct {
                   SC_UINT TRIGGERID;
                   SC_BOOL START;
                   SC_BOOL STOP;
                   SC_BOOL ACTIVE;
                   SC_BOOL READY;
                                          } RECSTARTSTOP_TYP;

void RECSTARTSTOP (RECSTARTSTOP_TYP *);

/*--- FB Number Cycles -----------------------------------------------------*/
typedef struct {
                   SC_UINT TRIGGERID;
                   SC_UINT NUMBER;
                   SC_BOOL READY;
                                          } RECNUMBER_TYP;

void RECNUMBER (RECNUMBER_TYP *);

/*--- FB set options -------------------------------------------------------*/
typedef struct {
                   SC_UINT TRIGGERID;
                   SC_UDINT OPTIONS;
                   SC_UDINT ERROR;
                                          } RECOPT_TYP;

void RECOPT (RECOPT_TYP *);

/*--- FB set secure data aquisition ----------------------------------------*/
typedef struct {
                   SC_UINT TRIGGERID;
                   SC_UDINT OPTIONS;
                   SC_UDINT ERROR;
                                          } RECSECUREDATA_TYP;

void RECSECUREDATA (RECSECUREDATA_TYP *);

/*--- FB set secure data aquisition ----------------------------------------*/
typedef struct {
                   SC_UINT TRIGGERID;
                   SC_UDINT MIN;
                   SC_UDINT MAX;
                   SC_UDINT ERROR;
                                          } RECROTATION_TYP;

void RECROTATION (RECROTATION_TYP *);


/*--- FB Print Header ------------------------------------------------------*/
typedef struct {
                   SC_UINT TRIGGERID;
                   SC_UINT NUMBER;
                   SC_BOOL ACTIVE;
                   SC_BOOL READY;
                                          } RECPRINTHEADER_TYP;

void RECPRINTHEADER (RECPRINTHEADER_TYP *);

/*--- FB Print actual Header -----------------------------------------------*/
typedef struct {
                   SC_UINT TRIGGERID;
                   SC_BOOL ACTIVE;
                                          } RECPRINTACTHEAD_TYP;

void RECPRINTACTHEAD (RECPRINTACTHEAD_TYP *);

/*--- Function Real Time Clock ---------------------------------------------*/
SC_DT REALTIME(void);

/*--- FB ModemGSM ----------------------------------------------------------*/
typedef struct {
                   SC_UINT PINCODE;
                   SC_BOOL ACTIVE;
                   SC_BOOL CONNECTED;
                   SC_BOOL PINOK;
                   SC_BOOL ONLINE;
                                        } MODEMGSM_TYP;

void MODEMGSM (MODEMGSM_TYP *);

/*--- FB (de)activate usage of module --------------------------------------*/
typedef struct {
                   SC_WORD LINE;
                   SC_WORD MODULENR;
                   SC_BOOL SETACTIVE;
                   SC_BOOL SYSTEMCRITICAL;
                   SC_BOOL TIMEOUT;
                   SC_BOOL ISACTIVE;
                                        } MODULESTATE_TYP;

void MODULESTATE (MODULESTATE_TYP *);

/*--- FB Message set default subgroup for group "user" ---------------------*/
SC_BOOL MSGUSERSUBGROUP(SC_UDINT subgroup);

/*--- FB Message UDINT/UDINT (detect rising slope) -------------------------*/
typedef struct {
                   SC_UDINT NUMBER;
                   SC_BOOL ACTIVE;
                   SC_UINT MSGPRIORITY;
                   SC_UDINT PARA_UDINT_1;
                   SC_UDINT PARA_UDINT_2;
                   SC_BOOL IN_M;                /* internal value to detect rising slope */
                                        } MSGUDINTUDINT_TYP;

void MSGUDINTUDINT (MSGUDINTUDINT_TYP *);

/*--- FB Message, number DWORD, UDINT/UDINT (detect rising slope) -------------------------*/
typedef struct {
                   SC_DWORD NUMBER;
                   SC_BOOL ACTIVE;
                   SC_UINT MSGPRIORITY;
                   SC_UDINT MSGSUBGROUP;
                   SC_UDINT PARA_UDINT_1;
                   SC_UDINT PARA_UDINT_2;
                   SC_BOOL IN_M;                /* internal value to detect rising slope */
                                        } MSGDWUDINTUDINT_TYP;

void MSGDWUDINTUDINT (MSGDWUDINTUDINT_TYP *);

/*--- FB Message Stacked, numbers DWORD, 2x UDINT, 2x Real  (detect rising slope) -------------------------*/
typedef struct {
                   SC_BOOL ACTIVE_RISING;
                   SC_BOOL ACTIVE_FALLING;
                   SC_UDINT MSGGROUPMAIN;
                   SC_UDINT MSGSUBGROUPMAIN;
                   SC_DWORD NUMBERMAIN;
                   SC_UINT MSGPRIORITYMAIN;
                   SC_UDINT PARAUDINT1MAIN;
                   SC_UDINT PARAUDINT2MAIN;
                   SC_UDINT MSGGROUPSTKD;
                   SC_UDINT MSGSUBGROUPSTKD;
                   SC_DWORD NUMBERSTKD;
                   SC_UINT MSGPRIORITYSTKD;
                   SC_REAL PARAREAL1STKD;
                   SC_REAL PARAREAL2STKD;
                   SC_BOOL IN_M_RISING;                /* internal value to detect rising slope for rising message */
                   SC_BOOL IN_M_FALLING;                /* internal value to detect rising slope for falling message */
                                      } MSGSTKD2UD2RE_TYP;

void MSGSTKD2UD2RE (MSGSTKD2UD2RE_TYP *);


/*--- FB Message Stacked, numbers DWORD, 2x UDINT, 2x UDINT  (detect rising slope) -------------------------*/
typedef struct {
                   SC_BOOL ACTIVE_RISING;
                   SC_BOOL ACTIVE_FALLING;
                   SC_UDINT MSGGROUPMAIN;
                   SC_UDINT MSGSUBGROUPMAIN;
                   SC_DWORD NUMBERMAIN;
                   SC_UINT MSGPRIORITYMAIN;
                   SC_UDINT PARAUDINT1MAIN;
                   SC_UDINT PARAUDINT2MAIN;
                   SC_UDINT MSGGROUPSTKD;
                   SC_UDINT MSGSUBGROUPSTKD;
                   SC_DWORD NUMBERSTKD;
                   SC_UINT MSGPRIORITYSTKD;
                   SC_UDINT PARAUDINT1STKD;
                   SC_UDINT PARAUDINT2STKD;
                   SC_BOOL IN_M_RISING;                /* internal value to detect rising slope for rising message */
                   SC_BOOL IN_M_FALLING;                /* internal value to detect rising slope for falling message */
                                        } MSGSTKD2UD2UD_TYP;

void MSGSTKD2UD2UD (MSGSTKD2UD2UD_TYP *);

/*--- FB Message , group and subgroup selectable, rising/falling trigger selectable, additional infos 2x UDINT -------------------------*/
typedef struct {
                   SC_BOOL ACTIVE_RISING;
                   SC_BOOL ACTIVE_FALLING;
                   SC_UDINT MSGGROUP;
                   SC_UDINT MSGSUBGROUP;
                   SC_DWORD NUMBER;
                   SC_UINT MSGPRIORITY;
                   SC_UDINT PARAUDINT1;
                   SC_UDINT PARAUDINT2;
                   SC_BOOL IN_M_RISING;                /* internal value to detect rising slope for rising message */
                   SC_BOOL IN_M_FALLING;                /* internal value to detect rising slope for falling message */
                                        } MSGGRPEDGEPUT2UD_TYP;

void MSGGRPEDGEPUT2UD (MSGGRPEDGEPUT2UD_TYP *);

/*--- FB Message UDINT/REAL (detect rising slope) --------------------------*/
typedef struct {
                   SC_UDINT NUMBER;
                   SC_BOOL ACTIVE;
                   SC_UINT MSGPRIORITY;
                   SC_UDINT PARA_UDINT_1;
                   SC_REAL PARA_REAL_2;
                   SC_BOOL IN_M;                /* internal value to detect rising slope */
                                        } MSGUDINTREAL_TYP;

void MSGUDINTREAL (MSGUDINTREAL_TYP *);

/*--- FB Message, number DWORD, UDINT/REAL (detect rising slope) --------------------------*/
typedef struct {
                   SC_DWORD NUMBER;
                   SC_BOOL ACTIVE;
                   SC_UINT MSGPRIORITY;
                   SC_UDINT MSGSUBGROUP;
                   SC_UDINT PARA_UDINT_1;
                   SC_REAL PARA_REAL_2;
                   SC_BOOL IN_M;                /* internal value to detect rising slope */
                                        } MSGDWUDINTREAL_TYP;

void MSGDWUDINTREAL (MSGDWUDINTREAL_TYP *);

/*--- FB Message REAL/UDINT (detect rising slope) --------------------------*/
typedef struct {
                   SC_UDINT NUMBER;
                   SC_BOOL ACTIVE;
                   SC_UINT MSGPRIORITY;
                   SC_REAL PARA_REAL_1;
                   SC_UDINT PARA_UDINT_2;
                   SC_BOOL IN_M;                /* internal value to detect rising slope */
                                        } MSGREALUDINT_TYP;

void MSGREALUDINT (MSGREALUDINT_TYP *);

/*--- FB Message, number DWORD, REAL/UDINT (detect rising slope) --------------------------*/
typedef struct {
                   SC_DWORD NUMBER;
                   SC_BOOL ACTIVE;
                   SC_UINT MSGPRIORITY;
                   SC_UDINT MSGSUBGROUP;
                   SC_REAL PARA_REAL_1;
                   SC_UDINT PARA_UDINT_2;
                   SC_BOOL IN_M;                /* internal value to detect rising slope */
                                        } MSGDWREALUDINT_TYP;

void MSGDWREALUDINT (MSGDWREALUDINT_TYP *);

/*--- FB Message REAL/REAL (detect rising slope) ---------------------------*/
typedef struct {
                   SC_UDINT NUMBER;
                   SC_BOOL ACTIVE;
                   SC_UINT MSGPRIORITY;
                   SC_REAL PARA_REAL_1;
                   SC_REAL PARA_REAL_2;
                   SC_BOOL IN_M;                /* internal value to detect rising slope */
                                        } MSGREALREAL_TYP;

void MSGREALREAL (MSGREALREAL_TYP *);

/*--- FB Message, number DWORD, REAL/REAL (detect rising slope) ---------------------------*/
typedef struct {
                   SC_DWORD NUMBER;
                   SC_BOOL ACTIVE;
                   SC_UINT MSGPRIORITY;
                   SC_UDINT MSGSUBGROUP;
                   SC_REAL PARA_REAL_1;
                   SC_REAL PARA_REAL_2;
                   SC_BOOL IN_M;                /* internal value to detect rising slope */
                                        } MSGDWREALREAL_TYP;

void MSGDWREALREAL (MSGDWREALREAL_TYP *);

/*--- FB Message INT/INT/INT/INT (detect rising slope) ---------------------*/
typedef struct {
                   SC_UDINT NUMBER;
                   SC_BOOL ACTIVE;
                   SC_UINT MSGPRIORITY;
                   SC_INT PARA_INT_1;
                   SC_INT PARA_INT_2;
                   SC_INT PARA_INT_3;
                   SC_INT PARA_INT_4;
                   SC_BOOL IN_M;                /* internal value to detect rising slope */
                                        } MSG4INT_TYP;

void MSG4INT (MSG4INT_TYP *);

/*--- FB Message, number DWORD, INT/INT/INT/INT (detect rising slope) ---------------------*/
typedef struct {
                   SC_DWORD NUMBER;
                   SC_BOOL ACTIVE;
                   SC_UINT MSGPRIORITY;
                   SC_UDINT MSGSUBGROUP;
                   SC_INT PARA_INT_1;
                   SC_INT PARA_INT_2;
                   SC_INT PARA_INT_3;
                   SC_INT PARA_INT_4;
                   SC_BOOL IN_M;                /* internal value to detect rising slope */
                                        } MSGDW4INT_TYP;

void MSGDW4INT (MSGDW4INT_TYP *);


/*--- FB VisKeyboard -------------------------------------------------*/

typedef struct {
                   SC_WORD *SYSKEY; 
                   SC_BOOL BIT0;
                   SC_BOOL BIT1;
                   SC_BOOL BIT2;
                   SC_BOOL BIT3;
                   SC_BOOL BIT4;
                   SC_BOOL BIT5;
                   SC_BOOL BIT6;
                   SC_BOOL BIT7;
                   SC_BOOL BIT8;
                   SC_BOOL BIT9;
                   SC_BOOL BIT10;
                   SC_BOOL BIT11;
                   SC_BOOL BIT12;
                   SC_BOOL BIT13;
                   SC_BOOL BIT14;
                   SC_BOOL BIT15;
                   SC_BYTE ASCII;
                   SC_UINT NUMBER;
                   SC_WORD CLEARMASK;
                                          } VISKEYBOARD_TYP;

void VISKEYBOARD (VISKEYBOARD_TYP *);


/*--- FB identify trigger --------------------------------------------------*/
typedef struct {
                   SC_STRINGDEF(20) NAME;
                   SC_UINT TRIGGERID;
                                          } RECIDENTTRIGGER_TYP;

void RECIDENTIFYTRIGGER(RECIDENTTRIGGER_TYP *);
void RECIDENTTRIGGER(RECIDENTTRIGGER_TYP *);

/*--- FB print data automatically ------------------------------------------*/
typedef struct {
                   SC_UINT TRIGGERID;
                                          } RECPRINTDATAAUTO_TYP;

void RECPRINTDATAAUTO (RECPRINTDATAAUTO_TYP *);

/*--- FB Address of Bool ---------------------------------------------------*/
typedef struct {
                   SC_BOOL* DATA;
                   SC_UDINT ADRESS;
                                          } ADRESSOFBOOL_TYP;

void ADRESSOFBOOL (ADRESSOFBOOL_TYP *);

/*--- FB Address of Byte ---------------------------------------------------*/
typedef struct {
                   SC_BYTE* DATA;
                   SC_UDINT ADRESS;
                                          } ADRESSOFBYTE_TYP;

void ADRESSOFBYTE (ADRESSOFBYTE_TYP *);

/*--- FB Address of UInt ---------------------------------------------------*/
typedef struct {
                   SC_UINT* DATA;
                   SC_UDINT ADRESS;
                                          } ADRESSOFUINT_TYP;

void ADRESSOFUINT (ADRESSOFUINT_TYP *);

/*--- FB Address of DInt ---------------------------------------------------*/
typedef struct {
                   SC_DINT* DATA;
                   SC_UDINT ADRESS;
                                          } ADRESSOFDINT_TYP;

void ADRESSOFDINT (ADRESSOFDINT_TYP *);

/*--- FB Address of Int ----------------------------------------------------*/
typedef struct {
                   SC_INT* DATA;
                   SC_UDINT ADRESS;
                                          } ADRESSOFINT_TYP;

void ADRESSOFINT (ADRESSOFINT_TYP *);

/*--- FB Address of Real ---------------------------------------------------*/
typedef struct {
                   SC_REAL* DATA;
                   SC_UDINT ADRESS;
                                          } ADRESSOFREAL_TYP;

void ADRESSOFREAL (ADRESSOFREAL_TYP *);

/*--- FB Address of String -------------------------------------------------*/
typedef struct {
                   SC_STRING* DATA;
                   SC_UDINT ADRESS;
                                          } ADRESSOFSTRING_TYP;

void ADRESSOFSTRING (ADRESSOFSTRING_TYP *);

/*--- FB PowerStageOpnEnd ------------------------------------------------*/
typedef struct {
                   SC_BOOL ENABLE;
                   SC_REAL IN;
                   SC_REAL MININ;
                   SC_REAL MAXIN;
                   SC_REAL LIMITIN;
                   SC_UINT MINOUT;
                   SC_UINT MAXOUT;
                   SC_UINT OUT;
                   SC_BOOL OUTOFRANGE;
                                          } POWERSTAGEOPNEND_TYP;

void POWERSTAGEOPNEND (POWERSTAGEOPNEND_TYP *);


/*--- FilterTP4 (Tiefpa�filter 4.Ordnung) --------------------------------*/
/* IIR Bessel-filter of 4nd order (2 filter with order 2 cascaded) */
/* 1. Filter */
#define	A01	0.3535f
#define	A11	0.7071f
#define	A21	0.3535f
#define	B11	0.3614f
#define	B21	0.0527f

/* 2. Filter */
#define	A02	0.4623f
#define	A12	0.9245f
#define	A22	0.4623f
#define	B12	0.5649f
#define	B22	0.2841f

typedef struct { 
                   SC_REAL IN;
                   SC_REAL FREQCUTOFF;
                   SC_REAL OUT;
                   SC_TIME OLDTIME;
                   SC_TIME ACTTIME;
                   SC_TIME DIFFTIME;
                   SC_INT  STATE;
                   
                   SC_REAL IN_T1;
                   SC_REAL IN_T2;
                   SC_REAL OUT_T1;
                   SC_REAL OUT_T2;
                   SC_REAL Y;
                   SC_REAL Y_T1;
                   SC_REAL Y_T2;

                   SC_REAL A0_1; 
                   SC_REAL A1_1; 
                   SC_REAL A2_1; 
                   SC_REAL B0_1; 
                   SC_REAL B1_1; 
                   SC_REAL B2_1; 

                   SC_REAL A0_2; 
                   SC_REAL A1_2; 
                   SC_REAL A2_2; 
                   SC_REAL B0_2; 
                   SC_REAL B1_2; 
                   SC_REAL B2_2; 
                                          } FILTERTP4_TYP;


void FILTERTP4 (FILTERTP4_TYP *);


/*--- KAMMFILTER (comb filter); -----------------------------------------*/
typedef struct { 
				/*input*/				
				SC_BOOL IXFILTERTYPE;
				SC_REAL IDSUPPFREQ_REF;
				SC_REAL IDINPUT_SIG;
				SC_BOOL IXRESET;
				SC_REAL IDRESET_VALUE;
				/*output*/
				SC_REAL QDSUPPFREQ_ACT;
				SC_REAL QDOUTPUT_SIG;
				SC_BOOL QXBLOCK_VALID;
				/*intern*/
				SC_INT INTERN_STATE;
				SC_TIME INTERN_ACTTIME;
				SC_TIME INTERN_OLDTIME;
				SC_BOOL INTERN_FILTYPE;
				SC_REAL INTERN_SUPPFREQ_REF;
				SC_REAL INTERN_SUPPFREQ_ACT;
				SC_REAL INTERN_SAMPLETIME;
				SC_UINT INTERN_FIL_LEN;
				void * mw_vp;
											} KAMMFILTER_TYP;

void KAMMFILTER (KAMMFILTER_TYP *);


/*--- Input/Output MSF -----------------------------------------------------*/
/* membershib function types*/ 
#define	ID_MSF_RAMP_RIGHT	1
#define	ID_MSF_RAMP_LEFT	2
#define	ID_MSF_TRIANGLE		3
#define	ID_MSF_TRAPEZE		4

SC_REAL MSFINPUT(SC_REAL IN, SC_UINT TYPE, SC_REAL MIN1, SC_REAL MAX1, SC_REAL MIN2, SC_REAL MAX2);
SC_REAL MSFOUTPUT(SC_REAL IN, SC_UINT TYPE, SC_REAL MIN1, SC_REAL MAX1, SC_REAL MIN2, SC_REAL MAX2);

/*--- max composition ------------------------------------------------------*/
SC_REAL MAXCOMPOSITION(SC_REAL IN1, SC_REAL IN2);

/*--- FUN linear interpolation ---------------------------------------------*/
SC_REAL LINEARINTERPOL ( SC_REAL X1, SC_REAL Y1, SC_REAL X2, SC_REAL Y2, SC_REAL X, SC_REAL MINOUT, SC_REAL MAXOUT );

/*--- FB 2nd order ploynom interpolation ---------------------------------------------*/
typedef struct {
                   SC_REAL X; 
                   SC_REAL X1; 
                   SC_REAL Y1;
                   SC_REAL X2;
                   SC_REAL Y2;
                   SC_REAL X3;
                   SC_REAL Y3;
                   SC_REAL OUT;
                   SC_BOOL INVALIDPOINTS;
                   } POLY2_TYP;
void POLY2 (POLY2_TYP *);

/*--- FB 2nd order bezier interpolation ---------------------------------------------*/
typedef struct {
                   SC_REAL X; 
                   SC_REAL X1; 
                   SC_REAL Y1;
                   SC_REAL X2;
                   SC_REAL Y2;
                   SC_REAL X3;
                   SC_REAL Y3;
                   SC_REAL OUT;
                   SC_BOOL INVALIDPOINTS;
                   } BEZIER2_TYP;
void BEZIER2 (BEZIER2_TYP *);

/*--- FB ScaleAI_5V --------------------------------------------------------*/
typedef struct {
                   SC_UINT IN;
                   SC_REAL SCALE;
                   SC_BOOL SHORTBREAKDETECT;
                   SC_REAL OUT;
                   SC_BOOL SHORT;
                   SC_BOOL BREAK;
                   } SCALEAI_5V_TYP;

void SCALEAI_5V (SCALEAI_5V_TYP *);

/*--- FB ScaleAIEXT_5V --------------------------------------------------------*/
typedef struct {
                   SC_UINT IN;
                   SC_REAL SCALE;
                   SC_BOOL SHORTBREAKDETECT;
                   SC_REAL OUT;
                   SC_BOOL ERR_LOW;
                   SC_BOOL ERR_HIGH;
                   SC_BOOL WARN_LOW;
                   SC_BOOL WARN_HIGH;
                   } SCALEAIEXT_5V_TYP;

void SCALEAIEXT_5V (SCALEAIEXT_5V_TYP *);

/*--- FB ScaleAI_Digital ---------------------------------------------------*/
typedef struct {
                   SC_UINT IN;
                   SC_REAL THRESHOLDUPPER;
                   SC_REAL THRESHOLDLOWER;
                   SC_BOOL OUT;
                   } SCALEDI_TYP;

void SCALEDI (SCALEDI_TYP *);

/*--- FB OA16_Feedback -----------------------------------------------------*/
typedef struct {
	SC_UINT FEEDBACKVALUE;
	SC_BOOL CURRENTBELOWBAND;
	SC_BOOL CURRENTINBAND;
	SC_BOOL CURRENTABOVEBAND;
	SC_BOOL CURRENTERROR;
	SC_BOOL CURRENTOVERLOAD;
	SC_BOOL OUTPUTVOLTAGE;
	} OA16_FEEDBACK_TYP;

void OA16_FEEDBACK (OA16_FEEDBACK_TYP *);
	
/*--- FB OD04_Feedback -----------------------------------------------------*/
typedef struct {
	SC_UINT FEEDBACKVALUE;
	SC_BOOL CHANNELERROR;
	SC_BOOL CURRENTOVERLOAD;
	SC_BOOL VOLTAGEIN;
	SC_BOOL VOLTAGEOUT;
	} OD04_FEEDBACK_TYP;

void OD04_FEEDBACK (OD04_FEEDBACK_TYP *);


/*--- FB Byte2BitMask -------------------------------------------------*/

typedef struct {
                   SC_BYTE A_BYTE;
                   SC_BOOL BIT0;
                   SC_BOOL BIT1;
                   SC_BOOL BIT2;
                   SC_BOOL BIT3;
                   SC_BOOL BIT4;
                   SC_BOOL BIT5;
                   SC_BOOL BIT6;
                   SC_BOOL BIT7;
                                          } BYTE2BITMASK_TYP;

void BYTE2BITMASK (BYTE2BITMASK_TYP *);



/*--- FUN BitMask2Byte --------------------------------------------------*/

SC_BYTE BITMASK2BYTE(SC_BOOL BIT0 ,SC_BOOL BIT1 ,SC_BOOL BIT2 ,SC_BOOL BIT3,
                     SC_BOOL BIT4 ,SC_BOOL BIT5 ,SC_BOOL BIT6 ,SC_BOOL BIT7);

/*--- FB GetMessageState ------------------------------------------------*/

/*! \struct	GETMESSAGESTATE_TYP
	\brief	SC interface structure for Function Block GetMessageState and C Function GETMESSAGESTATE()
	\ingroup	SC_interface
	\param	CLIENTNAME
	\param	MAXINDEX
	\param	MININDEX
	\param	NUMACKNOWLEDGED
	\param	NUMDEACTIVE
	\param	NUMCURRENT
	\param	client_id internally cached client id
	\param	clientname_backup backup of the client name, so we only not need to get the client ID if the client name did change
 */
typedef struct {
					SC_STRINGDEF(20) CLIENTNAME;
					SC_UDINT MAXINDEX;
					SC_UDINT MININDEX;
					SC_UDINT NUMACKNOWLEDGED;
					SC_UDINT NUMDEACTIVE;
					SC_UDINT NUMCURRENT;
					SC_DINT client_id;
					char clientname_backup[21];
				} GETMESSAGESTATE_TYP;
void GETMESSAGESTATE(GETMESSAGESTATE_TYP* ip);

/*--- FB GetMessageInfo -------------------------------------------------*/

/*! \struct	GETMESSAGEINFO_TYP
	\brief	SC interface structure for Function Block GetMessageInfo and C Function GETMESSAGEINFO()
	\ingroup	SC_interface
	\param	CLIENTNAME
	\param	INDEX
	\param	AVAILABLE
	\param	NUMBER
	\param	GROUP
	\param	SUBGROUP
	\param	ACKNOWLEDGE
	\param	ACTIVE
	\param	client_id internally cached client id
	\param	clientname_backup backup of the client name, so we only not need to get the client ID if the client name did change
 */
typedef struct {
					SC_STRINGDEF(20) CLIENTNAME;
					SC_UDINT INDEX;
					SC_BOOL AVAILABLE;
					SC_UDINT NUMBER;
					SC_UDINT GROUP;
					SC_UDINT SUBGROUP;
					SC_UINT MSGPRIORITY;
					SC_BOOL ACKNOWLEDGE;
					SC_BOOL ACTIVE;
					SC_DINT client_id;
					char clientname_backup[21];
				} GETMESSAGEINFO_TYP;
void GETMESSAGEINFO(GETMESSAGEINFO_TYP* ip);

/*--- FB SetMessageAck --------------------------------------------------*/

/*! \struct	SETMESSAGEACK_TYP
	\brief	SC interface structure for Function Block SetMessageAck and C Function SETMESSAGEACK()
	\ingroup	SC_interface
	\param	CLIENTNAME
	\param	INDEX
	\param	client_id internally cached client id
	\param	clientname_backup backup of the client name, so we only not need to get the client ID if the client name did change
 */
typedef struct {
					SC_STRINGDEF(20) CLIENTNAME;
					SC_UDINT INDEX;
					SC_DINT client_id;
					char clientname_backup[21];
				} SETMESSAGEACK_TYP;
void SETMESSAGEACK(SETMESSAGEACK_TYP* ip);

/*--- FB MultiMessageAck ------------------------------------------------*/

/*! \struct	MULTIMESSAGEACK_TYP
	\brief	SC interface structure for Function Block MultiMessageAck and C Function MULTIMESSAGEACK()
	\remark	the action is not handled immediately, but send as a job to the outer core
	\ingroup	SC_interface
	\param	ACTIVE execute the acknowledge job
	\param	CLIENTNAME Description name of client
	\param	INDEXMAX maximum index of message to be acknowledged
	\param	INDEXMIN minimum index of message to be acknowledged
	\param	client_id internally cached client id
	\param	clientname_backup backup of the client name, so we only not need to get the client ID if the client name did change
 */
typedef struct {
					SC_BOOL ACTIVE;
					SC_STRINGDEF(20) CLIENTNAME;
					SC_UDINT INDEXMAX;
					SC_UDINT INDEXMIN;
					SC_DINT client_id;
					char clientname_backup[21];
				} MULTIMESSAGEACK_TYP;
void MULTIMESSAGEACK(MULTIMESSAGEACK_TYP* ip);

/*--- FB FindMessage -------------------------------------------------------*/

/*! \struct	FINDMESSAGE_TYP
	\brief	SC interface structure for Function Block FindMessage and C Function FINDMESSAGE()
	\ingroup	SC_interface
	\param	CLIENTNAME Description name of client we want to get info of
	\param	MSGCODEMIN minimum message code
	\param	MSGCODEMAX minimum message code
	\param	GROUP the group of the message
	\param	SUBGROUP the subgroup of the message
	\param	ACKNOWLEDGE if this message index is acknowledged
	\param	ACTIVE if this message is active (not reset)
	\param	INDEXMIN minimum index of found messages
	\param	INDEXMAX maximum index of found messages
	\param	NUMBERFOUND number of found messages
	\param	client_id internally cached client id
	\param	clientname_backup backup of the client name, so we only not need to get the client ID if the client name did change
 */
typedef struct {
					SC_STRINGDEF(20) CLIENTNAME;
					SC_UDINT MSGCODEMIN;
					SC_UDINT MSGCODEMAX;
					SC_UDINT GROUP;
					SC_UDINT SUBGROUP;
					SC_BOOL ACKNOWLEDGE;
					SC_BOOL ACTIVE;
					SC_UDINT INDEXMIN;
					SC_UDINT INDEXMAX;
					SC_UDINT NUMBERFOUND;
					SC_DINT client_id;
					char clientname_backup[21];
				} FINDMESSAGE_TYP;
void FINDMESSAGE(FINDMESSAGE_TYP* ip);

/*--- FB PowerSourcestate --------------------------------------------------*/
typedef struct {
	SC_BOOL PWR_DIGIN0;
	SC_BOOL PWR_DIGIN1;
	SC_BOOL PWR_DIGIN2;
	} POWERSOURCESTATE_TYP;
void POWERSOURCESTATE (POWERSOURCESTATE_TYP *ip);

/*--- FB GPScoordinate -----------------------------------------------------*/

/*! \struct	GPSCOORDINATE_TYP
	\brief	SC interface structure for Function Block GPScoordinate and C Function GPSCOORDINATE()
	\ingroup	SC_interface
	\param	POSITIONVALID this is TRUE if all data sets of this call have been read at least once
	\param	LASTUPDATED the timestamp of the oldest parameter delivered by this function\n
			this timestamp is based on the C-time of the system clock and not of the GPS data
	\param	LATITUDE position of a GPS coordinate in micro degrees\n
			positive is north, negative is south
	\param	LONGITUDE position of a GPS coordinate in micro degrees\n
			positive is east, negative is west
	\param	ALTITUDE position of a GPS coordinate in mm
 */
typedef struct {
	SC_BOOL POSITIONVALID;
	SC_DT LASTUPDATED;
	SC_DINT LATITUDE;
	SC_DINT LONGITUDE;
	SC_DINT ALTITUDE;
	} GPSCOORDINATE_TYP;
void GPSCOORDINATE (GPSCOORDINATE_TYP *ip);

/*--- FB DaylightSavingSet ----------------------------------------------------*/
typedef struct {
                   SC_BOOL STATE; 
	} DAYLIGHTSAVESET_TYP;

void DAYLIGHTSAVESET (DAYLIGHTSAVESET_TYP *);

/*--- FB DaylightSavingGet ----------------------------------------------------*/
typedef struct {
                   SC_BOOL STATE; 
	} DAYLIGHTSAVEGET_TYP;

void DAYLIGHTSAVEGET (DAYLIGHTSAVEGET_TYP *);

/*--- FB TimeZoneSet ----------------------------------------------------*/
typedef struct {
		SC_DINT TIMEZONE; 
	} TIMEZONESET_TYP;

void TIMEZONESET(TIMEZONESET_TYP *);

/*--- FB TimeZoneGet ----------------------------------------------------*/
typedef struct {
		SC_DINT TIMEZONE; 
	} TIMEZONEGET_TYP;

void TIMEZONEGET(TIMEZONEGET_TYP *);

/*--- FB AccessControl --------------------------------------------------*/

/*! \struct	GETOPERATORINFO_TYP
	\brief	SC interface structure for Function Block GetOperatorInfo and C Function GETOPERATORINFO()
	\ingroup	SC_interface
	\param	GRANTED shows TRUE if access is granted
	\param	PRIORITYLEVEL system wide priority access level
	\param	IDENTIFICATION identification number or name, depending on the access control device
 */
typedef struct {
		SC_BOOL GRANTED; 
		SC_UDINT PRIORITYLEVEL; 
		SC_STRING* IDENTIFICATION; 
	} GETOPERATORINFO_TYP;

void GETOPERATORINFO(GETOPERATORINFO_TYP *);

/*! \struct	DATETIMEDETAILED_TYP
	\brief	SC interface structure for Function Block DateTimeDetailed and C Function DATETIMEDETAILED()
	\ingroup	SC_interface
	\param	DATETIME the ANSI C time information in seconds since 1970 to be converted
	\param	YEAR year including the century information; the minimum year is 1970
	\param	MONTH month
	\param	DAY day
	\param	HOUR hour
	\param	MINUTE minute
	\param	SECOND second
 */
typedef struct {
		SC_DT DATETIME;
		SC_UINT YEAR;
		SC_UINT MONTH;
		SC_UINT DAY;
		SC_UINT HOUR;
		SC_UINT MINUTE;
		SC_UINT SECOND;
	} DATETIMEDETAILED_TYP;

void DATETIMEDETAILED(DATETIMEDETAILED_TYP *);

/*--- FB common Message UDINT/UDINT (detect rising slope) ------------------*/
typedef struct {
                   SC_UDINT CODE;
                   SC_BOOL ACTIVE;
                   SC_UDINT MSGGROUP;
                   SC_UDINT MSGSUBGROUP;
                   SC_UINT MSGPRIORITY;
                   SC_UDINT ADDINFO1;
                   SC_UDINT ADDINFO2;
                   SC_BOOL IN_M;                /* internal value to detect rising slope */
                                        } MSGPUT_TYP;

void MSGPUT (MSGPUT_TYP *);

/*--- FB LUT_2D ----------------------------------------------------------*/
/* in VxWorks ERROR is a preprocessor definition for return codes */
#ifdef ERROR
#undef ERROR
#endif

typedef struct
{
	SC_UDINT TABLEID;
	SC_REAL X;
	SC_REAL Y;
	SC_BOOL LIMIT;
	SC_UDINT  ERROR;
	database_lut_instance_id_t instance_id;
} LUT_2D_TYP;

void LUT_2D (LUT_2D_TYP *);

/*--- FB LUT_3D ----------------------------------------------------------*/
/* in VxWorks ERROR is a preprocessor definition for return codes */
#ifdef ERROR
#undef ERROR
#endif

typedef struct
{
	SC_UDINT TABLEID;
	SC_REAL X;
	SC_REAL Y;
	SC_REAL Z;
	SC_BOOL LIMIT;
	SC_UDINT  ERROR;
	database_lut_instance_id_t instance_id;
} LUT_3D_TYP;

void LUT_3D (LUT_3D_TYP *);


/*--- FB LUT_4D ----------------------------------------------------------*/
/* in VxWorks ERROR is a preprocessor definition for return codes */
#ifdef ERROR
#undef ERROR
#endif

typedef struct
{
	SC_UDINT TABLEID;
	SC_REAL X;
	SC_REAL Y;
	SC_REAL Z;
	SC_REAL W;
	SC_BOOL LIMIT;
	SC_UDINT  ERROR;
	database_lut_instance_id_t instance_id;
} LUT_4D_TYP;

void LUT_4D (LUT_4D_TYP *);


/*--- FB LUT_5D ----------------------------------------------------------*/
/* in VxWorks ERROR is a preprocessor definition for return codes */
#ifdef ERROR
#undef ERROR
#endif

typedef struct
{
	SC_UDINT TABLEID;
	SC_REAL X;
	SC_REAL Y;
	SC_REAL Z;
	SC_REAL U;
	SC_REAL W;
	SC_BOOL LIMIT;
	SC_UDINT  ERROR;
	database_lut_instance_id_t instance_id;
} LUT_5D_TYP;

void LUT_5D (LUT_5D_TYP *);


/*--- FB REMOTEACCESSSET ----------------------------------------------------------*/
typedef struct {
		SC_BOOL STATE; 
	} REMOTEACCESSSET_TYP;

void REMOTEACCESSSET(REMOTEACCESSSET_TYP *ip);

/*--- FB REMOTEACCESSGET ----------------------------------------------------------*/
typedef struct {
		SC_BOOL STATE; 
	} REMOTEACCESSGET_TYP;

void REMOTEACCESSGET (REMOTEACCESSGET_TYP *ip);

/*--- DatabaseScript -----------------------------------------------------*/
/* in VxWorks ERROR is a preprocessor definition for return codes */
#ifdef ERROR
#undef ERROR
#endif

typedef struct
{
	SC_UDINT INDEX;
	SC_BOOL ENABLE;
	SC_BOOL PENDING;
	SC_BOOL FAIL;
	SC_UDINT  ERROR;
	SC_BOOL IN_M;                /* internal value to detect rising slope */
} DATABASESCRIPT_TYP;

void DATABASESCRIPT (DATABASESCRIPT_TYP *);

/*--- eof ------------------------------------------------------------------*/
#endif	//__LWNLIB_H

